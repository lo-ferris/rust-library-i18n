//! IEEE 754 浮点符合性测试
//!
//! 要了解 IEEE 754 对编程语言的要求，必须了解 IEEE 754 的要求取决于整个编程环境，而不是完全取决于任何一个组件。
//! 这意味着硬件、语言甚至库都被视为编程环境中符合浮点支持的一部分。
//!
//! 因此，编程语言的职责是：
//!   1. 提供对硬件提供支持的硬件的访问
//!   2. 提供满足标准剩余要求的操作
//!   3. 提供编写能够满足这些需求的附加软件的能力
//!
//! 这可以通过语言认为合适的任何组合来实现。然而，声称一种语言支持 IEEE 754 是在暗示它已经满足了要求 1 和 2，而没有将最低要求提交给库
//! 这是因为对 IEEE 754 的支持被定义为完全支持至少一种指定的浮点类型，如算术和交换格式，以及到外部字符序列和整数类型的指定类型转换。
//!
//!
//! 出于我们的目的，"交换格式" => f32、f64 "算术格式" => f32、f64 和任何 "软浮点数" "外部字符序列" => 来自任何浮点数 "整数格式" => {i,u}{8,16,32,64,128} 的 str
//!
//! 这些测试都不是针对 Rust 自己的实现的。它们只是针对标准的测试。这就是为什么他们接受各种各样的输入或似乎重复其他测试的原因。
//! 在添加、删除或重新组织这些测试时，请仔细考虑这一点。它们在这里是为了清楚标准要求哪些测试以及可以更改哪些测试。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
use ::core::str::FromStr;

// 许多测试的 IEEE 754 适用于特定的位模式。
// 但是，这些通常不适用于 NaN。
macro_rules! assert_biteq {
    ($lhs:expr, $rhs:expr) => {
        assert_eq!($lhs.to_bits(), $rhs.to_bits())
    };
}

// ToString 使用默认的 fmt::Display impl 没有特别的顾虑，并绕过格式结构体的其他部分，这使得它非常适合这里的测试。
//
#[allow(unused_macros)]
macro_rules! roundtrip {
    ($f:expr => $t:ty) => {
        ($f).to_string().parse::<$t>().unwrap()
    };
}

macro_rules! assert_floats_roundtrip {
    ($f:ident) => {
        assert_biteq!(f32::$f, roundtrip!(f32::$f => f32));
        assert_biteq!(f64::$f, roundtrip!(f64::$f => f64));
    };
    ($f:expr) => {
        assert_biteq!($f as f32, roundtrip!($f => f32));
        assert_biteq!($f as f64, roundtrip!($f => f64));
    }
}

macro_rules! assert_floats_bitne {
    ($lhs:ident, $rhs:ident) => {
        assert_ne!(f32::$lhs.to_bits(), f32::$rhs.to_bits());
        assert_ne!(f64::$lhs.to_bits(), f64::$rhs.to_bits());
    };
    ($lhs:expr, $rhs:expr) => {
        assert_ne!(f32::to_bits($lhs), f32::to_bits($rhs));
        assert_ne!(f64::to_bits($lhs), f64::to_bits($rhs));
    };
}

// 我们必须保留所有数字上的符号。这包括零。
// -0 和 0 通常是 == 的，所以测试位相等。
#[test]
fn preserve_signed_zero() {
    assert_floats_roundtrip!(-0.0);
    assert_floats_roundtrip!(0.0);
    assert_floats_bitne!(0.0, -0.0);
}

#[test]
fn preserve_signed_infinity() {
    assert_floats_roundtrip!(INFINITY);
    assert_floats_roundtrip!(NEG_INFINITY);
    assert_floats_bitne!(INFINITY, NEG_INFINITY);
}

#[test]
fn infinity_to_str() {
    assert!(match f32::INFINITY.to_string().to_lowercase().as_str() {
        "+infinity" | "infinity" => true,
        "+inf" | "inf" => true,
        _ => false,
    });
    assert!(
        match f64::INFINITY.to_string().to_lowercase().as_str() {
            "+infinity" | "infinity" => true,
            "+inf" | "inf" => true,
            _ => false,
        },
        "Infinity must write to a string as some casing of inf or infinity, with an optional +."
    );
}

#[test]
fn neg_infinity_to_str() {
    assert!(match f32::NEG_INFINITY.to_string().to_lowercase().as_str() {
        "-infinity" | "-inf" => true,
        _ => false,
    });
    assert!(
        match f64::NEG_INFINITY.to_string().to_lowercase().as_str() {
            "-infinity" | "-inf" => true,
            _ => false,
        },
        "Negative Infinity must write to a string as some casing of -inf or -infinity"
    )
}

#[test]
fn nan_to_str() {
    assert!(
        match f32::NAN.to_string().to_lowercase().as_str() {
            "nan" | "+nan" | "-nan" => true,
            _ => false,
        },
        "NaNs must write to a string as some casing of nan."
    )
}

// "+"?("inf"|"infinity") 在任何情况下 => 无穷大
#[test]
fn infinity_from_str() {
    assert_biteq!(f32::INFINITY, f32::from_str("infinity").unwrap());
    assert_biteq!(f32::INFINITY, f32::from_str("inf").unwrap());
    assert_biteq!(f32::INFINITY, f32::from_str("+infinity").unwrap());
    assert_biteq!(f32::INFINITY, f32::from_str("+inf").unwrap());
    // 是的。这意味着欢迎您来到我无限扭曲的心灵
    assert_biteq!(f32::INFINITY, f32::from_str("+iNfInItY").unwrap());
}

// "-inf"|"-infinity" 在任何情况下 => 负无穷大
#[test]
fn neg_infinity_from_str() {
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-infinity").unwrap());
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-inf").unwrap());
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-INF").unwrap());
    assert_biteq!(f32::NEG_INFINITY, f32::from_str("-INFinity").unwrap());
}

// ("+"|"-"")?"s"?"nan" 在任何情况下 => qNaN
#[test]
fn qnan_from_str() {
    assert!("nan".parse::<f32>().unwrap().is_nan());
    assert!("-nan".parse::<f32>().unwrap().is_nan());
    assert!("+nan".parse::<f32>().unwrap().is_nan());
    assert!("+NAN".parse::<f32>().unwrap().is_nan());
    assert!("-NaN".parse::<f32>().unwrap().is_nan());
}
