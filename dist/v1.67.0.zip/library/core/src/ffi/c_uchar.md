等效于 C 的 `unsigned char` 类型。

此类型将始终为 [`u8`]，但出于完整性考虑将其包括在内。它定义为与 C [`char`] 大小相同的无符号整数。

[`char`]: c_char
