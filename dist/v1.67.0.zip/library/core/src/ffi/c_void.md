当用作 [指针][pointer] 时，等效于 C 的 `void` 类型。

本质上，`*const c_void` 等效于 C 的 `const void*`，而 `*mut c_void` 等效于 C 的 `void*`。
也就是说，这与 C 的 `void` 返回类型 (即 Rust 的 `()` 类型) 不同。

要在 FFI 中对指向不透明类型的指针进行建模，直到 `extern type` 稳定为止，建议在空字节数组周围使用 newtype 包装器。

有关详细信息，请参见 [Nomicon]。

如果他们想支持低至 1.1.0 的旧 Rust 编译器，则可以使用 `std::os::raw::c_void`。
Rust 1.30.0 之后，此定义将其重导出。
有关更多信息，请阅读 [RFC 2521]。

[Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
[RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
