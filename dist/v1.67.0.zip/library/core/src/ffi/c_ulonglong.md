等效于 C 的 `unsigned long long` 类型。

此类型几乎总是 [`u64`]，但在某些系统上可能有所不同。C 标准从技术上仅要求此类型是 [`long long`] 大小的无符号整数，尽管实际上，没有系统会具有不是 `u64` 的 `long long`，因为大多数系统都没有标准化的 [`u128`] 类型。

[`long long`]: c_longlong
