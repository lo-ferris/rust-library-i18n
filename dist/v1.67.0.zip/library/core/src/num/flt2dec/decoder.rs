//! 将浮点值解码为单独的部分和错误范围。

use crate::num::dec2flt::float::RawFloat;
use crate::num::FpCategory;

/// 解码后的无符号有限值，例如：
///
/// - 原始值等于 `mant * 2^exp`。
///
/// - 从 `(mant - minus)*2^exp` 到 `(mant + plus)* 2^exp` 的任何数字都将四舍五入为原始值。
/// 仅当 `inclusive` 为 `true` 时，范围才包括在内。
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// 缩放的尾数。
    pub mant: u64,
    /// 较低的误差范围。
    pub minus: u64,
    /// 上限误差范围。
    pub plus: u64,
    /// 以 2 为底的共享指数。
    pub exp: i16,
    /// 如果错误范围包含在内，则为 true。
    ///
    /// 在 IEEE 754 中，当原始尾数为偶数时，这是正确的。
    pub inclusive: bool,
}

/// 解码后的无符号值。
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// 无穷大，正数或负数。
    Infinite,
    /// 零，正数或负数。
    Zero,
    /// 具有进一步解码字段的有限数字。
    Finite(Decoded),
}

/// 可以被解码的浮点类型。
pub trait DecodableFloat: RawFloat + Copy {
    /// 最小正归一化值。
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// 从给定的浮点数返回一个符号 (当为负数时为 true) 和 `FullDecoded` 值。
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // neighbors: (mant - 2, exp) -- (mant, exp) -- (mant + 2, exp) Float::integer_decode 始终保留指数，因此尾数针对正常以下进行缩放。
            //
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // neighbors: (maxmant, exp - 1) -- (minnormmant, exp) -- (minnormmant + 1, exp) 其中 maxmant = minnormmant * 2 - 1
                //
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // neighbors: (mant - 1, exp) -- (mant, exp) -- (mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}
