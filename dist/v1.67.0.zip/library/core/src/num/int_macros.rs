macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $BITS_MINUS_ONE:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr,
     $bound_condition:expr) => {
        /// 该整数类型可以表示的最小值
        #[doc = concat!("(&minus;2<sup>", $BITS_MINUS_ONE, "</sup>", $bound_condition, ")")]
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// 该整数类型可以表示的最大值
        #[doc = concat!("(2<sup>", $BITS_MINUS_ONE, "</sup> &minus; 1", $bound_condition, ")")]
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// 此整数类型的大小 (以位为单位)。
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "int_bits_const", since = "1.53.0")]
        pub const BITS: u32 = $BITS;

        /// 将给定基数的字符串切片转换为整数。
        ///
        /// 该字符串应为可选的 `+` 或 `-` 符号，后跟数字。
        /// 前导和尾随空格表示错误。
        /// 根据 `radix`，数字是这些字符的子集：
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// 如果 `radix` 不在 2 到 36 之间，则此函数 panics。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// 返回 `self` 二进制表示形式中的位数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.count_ones(), 1);
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// 返回 `self` 二进制表示形式中的零数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// 返回 `self` 二进制表示形式中前导零的数目。
        ///
        /// 根据您对值的处理方式，您可能还对 [`ilog2`] 函数感兴趣，它返回一致的数字，即使类型变宽。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[doc = concat!("[`ilog2`]: ", stringify!($SelfT), "::ilog2")]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// 返回 `self` 二进制表示形式中的尾随零数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// 返回 `self` 二进制表示形式中前导数字。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        ///
        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// 返回 `self` 二进制表示形式中的尾随数字。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        ///
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// 将位左移指定的量 `n`，将截断的位包装到结果整数的末尾。
        ///
        ///
        /// 请注意，此操作与 `<<` 移位运算符不同！
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]
        ///
        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// 将位右移指定的量 `n`，将截断的位包装到结果整数的开头。
        ///
        ///
        /// 请注意，此操作与 `>>` 移位运算符不同！
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]
        ///
        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// 反转整数的字节顺序。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        ///
        /// let m = n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// 反转整数中的位顺序。
        /// 最低有效位变为最高有效位，第二最低有效位变为第二最高有效位，依此类推。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// let m = n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "reverse_bits", since = "1.37.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// 将整数从大端字节序转换为目标的字节序。
        ///
        /// 在大端节序序上，这是个禁忌。在小端字节序上，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "big") {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[must_use]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// 将整数从小端字节序转换为目标的字节序。
        ///
        /// 在小端字节序上，这是个禁忌。在大字节序中，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "little") {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[must_use]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// 将 `self` 从目标的字节序转换为大字节序。
        ///
        /// 在大端节序序上，这是个禁忌。在小端字节序上，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "big") {
        ///     assert_eq!(n.to_be(), n)
        /// } else {
        ///     assert_eq!(n.to_be(), n.swap_bytes())
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_be(self) -> Self { // 还是不是？
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// 将 `self` 从目标的字节序转换为 Little Endian。
        ///
        /// 在小端字节序上，这是个禁忌。在大字节序中，字节被交换。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        ///
        /// if cfg!(target_endian = "little") {
        ///     assert_eq!(n.to_le(), n)
        /// } else {
        ///     assert_eq!(n.to_le(), n.swap_bytes())
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// 检查整数加法。
        /// 计算 `self + rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未经检查的整数加法。
        /// 假设不会发生溢出，则计算 `self + rhs`。
        ///
        /// # Safety
        ///
        /// 当以下情况时，这导致未定义的行为
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`,")]
        /// 即当 [`checked_add`] 将返回 `None` 时。
        ///
        #[doc = concat!("[`checked_add`]: ", stringify!($SelfT), "::checked_add")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        #[cfg_attr(miri, track_caller)] // 即使没有 panic，这也有助于 Miri 回溯
        pub const unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_add` 的安全保证。
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// 用无符号整数检查加法。
        /// 计算 `self + rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_add_unsigned(2), Some(3));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add_unsigned(3), None);")]
        /// ```
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add_unsigned(self, rhs: $UnsignedT) -> Option<Self> {
            let (a, b) = self.overflowing_add_unsigned(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 检查整数减法。
        /// 计算 `self - rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未经检查的整数减法。
        /// 假设不会发生溢出，则计算 `self - rhs`。
        ///
        /// # Safety
        ///
        /// 当以下情况时，这导致未定义的行为
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`,")]
        /// 即当 [`checked_sub`] 将返回 `None` 时。
        ///
        #[doc = concat!("[`checked_sub`]: ", stringify!($SelfT), "::checked_sub")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        #[cfg_attr(miri, track_caller)] // 即使没有 panic，这也有助于 Miri 回溯
        pub const unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_sub` 的安全保证。
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// 用无符号整数检查减法。
        /// 计算 `self - rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub_unsigned(2), Some(-1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub_unsigned(3), None);")]
        /// ```
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub_unsigned(self, rhs: $UnsignedT) -> Option<Self> {
            let (a, b) = self.overflowing_sub_unsigned(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 检查整数乘法。
        /// 计算 `self * rhs`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未经检查的整数乘法。
        /// 假设不会发生溢出，则计算 `self * rhs`。
        ///
        /// # Safety
        ///
        /// 当以下情况时，这导致未定义的行为
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`,")]
        /// 即当 [`checked_mul`] 将返回 `None` 时。
        ///
        #[doc = concat!("[`checked_mul`]: ", stringify!($SelfT), "::checked_mul")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        #[cfg_attr(miri, track_caller)] // 即使没有 panic，这也有助于 Miri 回溯
        pub const unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_mul` 的安全保证。
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// 检查整数除法。
        /// 计算 `self / rhs`，如果 `rhs == 0` 或除法导致溢出，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_div", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || ((self == Self::MIN) && (rhs == -1))) {
                None
            } else {
                // SAFETY: 上面已经检查了 div 的零和 INT_MIN 的值
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// 检查欧几里得除法。
        /// 计算 `self.div_euclid(rhs)`，如果 `rhs == 0` 或除法导致溢出，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            // 使用 `&` 有助于 LLVM 看到它是在除法中进行的相同检查。
            if unlikely!(rhs == 0 || ((self == Self::MIN) & (rhs == -1))) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// 检查整数余数。
        /// 计算 `self % rhs`，如果 `rhs == 0` 或除法导致溢出，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_div", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || ((self == Self::MIN) && (rhs == -1))) {
                None
            } else {
                // SAFETY: 上面已经检查了 div 的零和 INT_MIN 的值
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// 检查欧几里得的余数。
        /// 计算 `self.rem_euclid(rhs)`，如果 `rhs == 0` 或除法导致溢出，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            // 使用 `&` 有助于 LLVM 看到它是在除法中进行的相同检查。
            if unlikely!(rhs == 0 || ((self == Self::MIN) & (rhs == -1))) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// 检查否定。计算 `-self`，如果为 `self == MIN`，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 检查左移。
        /// 计算 `self << rhs`，如果 `rhs` 大于或等于 `self` 中的位数，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未检查的左移。
        /// 计算 `self << rhs`，假设 `rhs` 小于 `self` 中的位数。
        ///
        /// # Safety
        ///
        /// 如果 `rhs` 大于或等于 `self` 中的位数，则会导致未定义的行为，即
        ///
        /// 当 [`checked_shl`] 返回 `None` 时。
        ///
        #[doc = concat!("[`checked_shl`]: ", stringify!($SelfT), "::checked_shl")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        #[cfg_attr(miri, track_caller)] // 即使没有 panic，这也有助于 Miri 回溯
        pub const unsafe fn unchecked_shl(self, rhs: u32) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_shl` 的安全保证。
            //
            // 任何合法的移位量都可以在自身类型中无损地表示。
            unsafe { intrinsics::unchecked_shl(self, rhs.try_into().ok().unwrap_unchecked()) }
        }

        /// 检查右移。
        /// 计算 `self >> rhs`，如果 `rhs` 大于或等于 `self` 中的位数，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未检查右移。
        /// 计算 `self >> rhs`，假设 `rhs` 小于 `self` 中的位数。
        ///
        /// # Safety
        ///
        /// 如果 `rhs` 大于或等于 `self` 中的位数，则会导致未定义的行为，即
        ///
        /// 当 [`checked_shr`] 返回 `None` 时。
        ///
        #[doc = concat!("[`checked_shr`]: ", stringify!($SelfT), "::checked_shr")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "85122",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_unstable(feature = "const_inherent_unchecked_arith", issue = "85122")]
        #[inline(always)]
        #[cfg_attr(miri, track_caller)] // 即使没有 panic，这也有助于 Miri 回溯
        pub const unsafe fn unchecked_shr(self, rhs: u32) -> Self {
            // SAFETY: 调用者必须遵守 `unchecked_shr` 的安全保证。
            //
            // 任何合法的移位量都可以在自身类型中无损地表示。
            unsafe { intrinsics::unchecked_shr(self, rhs.try_into().ok().unwrap_unchecked()) }
        }

        /// 检查的绝对值。
        /// 计算 `self.abs()`，如果为 `self == MIN`，则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// 检查取幂。
        /// 计算 `self.pow(exp)`，如果发生溢出则返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            acc.checked_mul(base)
        }

        /// 饱和整数加法。
        /// 计算 `self + rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// 使用无符号整数进行饱和加法。
        /// 计算 `self + rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".saturating_add_unsigned(2), 3);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add_unsigned(100), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add_unsigned(self, rhs: $UnsignedT) -> Self {
            // 溢出只能发生在上限，我们不能在这里使用 `unwrap_or`，因为它不是 `const`
            //
            match self.checked_add_unsigned(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// 饱和整数减法。
        /// 计算 `self - rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// 使用无符号整数进行饱和减法。
        /// 计算 `self - rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub_unsigned(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub_unsigned(100), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub_unsigned(self, rhs: $UnsignedT) -> Self {
            // 溢出只能发生在下限，我们不能在这里使用 `unwrap_or`，因为它不是 `const`
            //
            match self.checked_sub_unsigned(rhs) {
                Some(x) => x,
                None => Self::MIN,
            }
        }

        /// 饱和整数求反。
        /// 计算 `-self`，如果 `self == MIN` 则返回 `MAX` 而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// 饱和绝对值。
        /// 计算 `self.abs()`，如果 `self == MIN` 则返回 `MAX` 而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// 饱和整数乘法。
        /// 计算 `self * rhs`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// 饱和整数除法。
        /// 计算 `self / rhs`，在数值边界处饱和而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".saturating_div(2), 2);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_div(-1), ", stringify!($SelfT), "::MIN + 1);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_div(-1), ", stringify!($SelfT), "::MAX);")]
        ///
        /// ```
        ///
        /// ```should_panic
        #[doc = concat!("let _ = 1", stringify!($SelfT), ".saturating_div(0);")]
        ///
        /// ```
        #[stable(feature = "saturating_div", since = "1.58.0")]
        #[rustc_const_stable(feature = "saturating_div", since = "1.58.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_div(self, rhs: Self) -> Self {
            match self.overflowing_div(rhs) {
                (result, false) => result,
                (_result, true) => Self::MAX, // MIN/-1 是唯一可能的饱和溢出
            }
        }

        /// 饱和整数幂。
        /// 计算 `self.pow(exp)`，在数字范围内饱和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// 包装 (modular) 添加。
        /// 计算 `self + rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// 用无符号整数包装 (modular) 加法。
        /// 计算 `self + rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add_unsigned(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add_unsigned(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_add_unsigned(self, rhs: $UnsignedT) -> Self {
            self.wrapping_add(rhs as Self)
        }

        /// 包装 (modular) 减法。
        /// 计算 `self - rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// 用无符号整数包装 (modular) 减法。
        /// 计算 `self - rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub_unsigned(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub_unsigned(", stringify!($UnsignedT), "::MAX), -1);")]
        /// ```
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_sub_unsigned(self, rhs: $UnsignedT) -> Self {
            self.wrapping_sub(rhs as Self)
        }

        /// 包装 (modular) 乘法。
        /// 计算 `self * rhs`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// 包装 (modular) 分区。计算 `self / rhs`，在类型的边界处回绕。
        ///
        /// 可能发生这种换行的唯一情况是将 `MIN / -1` 除以有符号类型 (其中 `MIN` 是该类型的负最小值)。这等效于 `-MIN`，它是一个太大的正值，无法在类型中表示。
        /// 在这种情况下，此函数将返回 `MIN` 本身。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// 包装欧几里得除法。
        /// 计算 `self.div_euclid(rhs)`，在类型的边界处回绕。
        ///
        /// 包装只会在 `MIN / -1` 上的带符号类型 (其中 `MIN` 是该类型的负最小值) 上发生。
        /// 这等效于 `-MIN`，它是一个太大的正值，无法在类型中表示。
        /// 在这种情况下，此方法将返回 `MIN` 本身。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// 包装 (modular) 余数。计算 `self % rhs`，在类型的边界处回绕。
        ///
        /// 这种折回实际上在数学上从来没有发生过。实现工件会导致 `x % y` 对于带符号类型的 `MIN / -1` 无效 (其中 `MIN` 为负最小值)。
        ///
        /// 在这种情况下，此函数返回 `0`。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// 包装欧几里得的余数。计算 `self.rem_euclid(rhs)`，在类型的边界处回绕。
        ///
        /// 包装只会在 `MIN % -1` 上的带符号类型 (其中 `MIN` 是该类型的负最小值) 上发生。
        /// 在这种情况下，此方法返回 0。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// 包装 (modular) 取反。计算 `-self`，在类型的边界处回绕。
        ///
        /// 可能发生这种换行的唯一情况是对有符号类型的 `MIN` 求反 (其中 `MIN` 是该类型的负最小值) ; 否则，可能会发生这种换行。这是一个太大的正值，无法在类型中表示。
        /// 在这种情况下，此函数将返回 `MIN` 本身。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn wrapping_neg(self) -> Self {
            (0 as $SelfT).wrapping_sub(self)
        }

        /// 无 Panic - 按位左移； 产生 `self << mask(rhs)`，其中 `mask` 删除 `rhs` 的所有高位，这些高位将导致移位超过该类型的位宽。
        ///
        /// 注意，这与左旋不同； 环绕左移的 RHS 限于该类型的范围，而不是从 LHS 移出的位返回到另一端。
        ///
        /// 所有原始整数类型都实现了 [`rotate_left`](Self::rotate_left) 函数，而您可能想要的是 [`rotate_left`](Self::rotate_left) 函数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        #[rustc_allow_const_fn_unstable(const_inherent_unchecked_arith)]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: 通过类型的位大小进行掩蔽可确保我们不会越界
            //
            unsafe {
                self.unchecked_shl(rhs & ($BITS - 1))
            }
        }

        /// 无 Panic - 按位右移； 产生 `self >> mask(rhs)`，其中 `mask` 删除 `rhs` 的所有高位，这些高位将导致移位超过该类型的位宽。
        ///
        /// 注意，这与右旋转不同。换行右移的 RHS 限于类型的范围，而不是从 LHS 移出的位返回到另一端。
        ///
        /// 所有原始整数类型都实现了 [`rotate_right`](Self::rotate_right) 函数，而您可能想要的是 [`rotate_right`](Self::rotate_right) 函数。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        #[rustc_allow_const_fn_unstable(const_inherent_unchecked_arith)]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: 通过类型的位大小进行掩蔽可确保我们不会越界
            //
            unsafe {
                self.unchecked_shr(rhs & ($BITS - 1))
            }
        }

        /// 包装 (modular) 绝对值。计算 `self.abs()`，在类型的边界处回绕。
        ///
        /// 可能发生这种换行的唯一情况是，当类型取负的最小值的绝对值时； 这是一个太大的正值，无法在类型中表示。
        /// 在这种情况下，此函数将返回 `MIN` 本身。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        ///
        ///
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// 计算 `self` 的绝对值，而不会引起任何包装或 panic。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        ///
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// 包装 (modular) 指数。
        /// 计算 `self.pow(exp)`，在类型的边界处回绕。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            acc.wrapping_mul(base)
        }

        /// 计算 `self` + `rhs`
        ///
        /// 返回一个加法元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// 计算 `self + rhs + carry` 没有溢出的能力。
        ///
        /// 执行 "有符号三元加法"，它接受一个额外的位来添加，并且可能返回一个额外的溢出位。
        /// 这个有符号函数只用于最高阶数据，有符号溢出结果表明大整数是否溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(bigint_helper_methods)]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".carrying_add(2, false), (7, false));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".carrying_add(2, true), (8, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(1, false), (", stringify!($SelfT), "::MIN, true));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(0, true), (", stringify!($SelfT), "::MIN, true));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(1, true), (", stringify!($SelfT), "::MIN + 1, true));")]
        #[doc = concat!("assert_eq!(",
            stringify!($SelfT), "::MAX.carrying_add(", stringify!($SelfT), "::MAX, true), ",
            "(-1, true));"
        )]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.carrying_add(-1, true), (", stringify!($SelfT), "::MIN, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".carrying_add(", stringify!($SelfT), "::MAX, true), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        ///
        /// If `carry` is false, this method is equivalent to [`overflowing_add`](Self::overflowing_add):
        ///
        /// ```
        /// #![feature(bigint_helper_methods)]
        #[doc = concat!("assert_eq!(5_", stringify!($SelfT), ".carrying_add(2, false), 5_", stringify!($SelfT), ".overflowing_add(2));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.carrying_add(1, false), ", stringify!($SelfT), "::MAX.overflowing_add(1));")]
        /// ```
        #[unstable(feature = "bigint_helper_methods", issue = "85532")]
        #[rustc_const_unstable(feature = "const_bigint_helper_methods", issue = "85532")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn carrying_add(self, rhs: Self, carry: bool) -> (Self, bool) {
            // note: 从长远来看，这应该通过函数内部来完成。
            // note: 不需要中间溢出 (https://github.com/rust-lang/rust/issues/85532#issuecomment-1032214946)。
            let (a, b) = self.overflowing_add(rhs);
            let (c, d) = a.overflowing_add(carry as $SelfT);
            (c, b != d)
        }

        /// 使用无符号 `rhs` 计算 `self` + `rhs`
        ///
        /// 返回一个加法元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".overflowing_add_unsigned(2), (3, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_add_unsigned(", stringify!($UnsignedT), "::MAX), (", stringify!($SelfT), "::MAX, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).overflowing_add_unsigned(3), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        ///
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add_unsigned(self, rhs: $UnsignedT) -> (Self, bool) {
            let rhs = rhs as Self;
            let (res, overflowed) = self.overflowing_add(rhs);
            (res, overflowed ^ (rhs < 0))
        }

        /// 计算 `self`-`rhs`
        ///
        /// 返回一个减法的元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// 计算 `self - rhs - borrow` 没有溢出的能力。
        ///
        /// 执行 "有符号三元减法"，它需要一个额外的位来减去，并且可能返回一个额外的溢出位。
        /// 这个有符号函数只用于最高阶数据，有符号溢出结果表明大整数是否溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(bigint_helper_methods)]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".borrowing_sub(2, false), (3, false));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".borrowing_sub(2, true), (2, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".borrowing_sub(1, false), (-1, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".borrowing_sub(1, true), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.borrowing_sub(1, true), (", stringify!($SelfT), "::MAX - 1, true));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.borrowing_sub(-1, false), (", stringify!($SelfT), "::MIN, true));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.borrowing_sub(-1, true), (", stringify!($SelfT), "::MAX, false));")]
        /// ```
        #[unstable(feature = "bigint_helper_methods", issue = "85532")]
        #[rustc_const_unstable(feature = "const_bigint_helper_methods", issue = "85532")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn borrowing_sub(self, rhs: Self, borrow: bool) -> (Self, bool) {
            // note: 从长远来看，这应该通过函数内部来完成。
            // note: 不需要中间溢出 (https://github.com/rust-lang/rust/issues/85532#issuecomment-1032214946)。
            let (a, b) = self.overflowing_sub(rhs);
            let (c, d) = a.overflowing_sub(borrow as $SelfT);
            (c, b != d)
        }

        /// 使用无符号 `rhs` 计算 `self`-`rhs`
        ///
        /// 返回一个减法的元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".overflowing_sub_unsigned(2), (-1, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).overflowing_sub_unsigned(", stringify!($UnsignedT), "::MAX), (", stringify!($SelfT), "::MIN, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).overflowing_sub_unsigned(3), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        ///
        #[stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[rustc_const_stable(feature = "mixed_integer_ops", since = "1.66.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub_unsigned(self, rhs: $UnsignedT) -> (Self, bool) {
            let rhs = rhs as Self;
            let (res, overflowed) = self.overflowing_sub(rhs);
            (res, overflowed ^ (rhs < 0))
        }

        /// 计算 `self` 和 `rhs` 的乘法。
        ///
        /// 返回乘法的元组以及一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回包装的值。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, true));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` 除以 `rhs` 时计算除数。
        ///
        /// 返回除数的元组以及指示是否将发生算术溢出的布尔值。
        /// 如果将发生溢出，则返回 self。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            // 使用 `&` 有助于 LLVM 看到它是在除法中进行的相同检查。
            if unlikely!((self == Self::MIN) & (rhs == -1)) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// 计算欧几里得除法 `self.div_euclid(rhs)` 的商。
        ///
        /// 返回除数的元组以及指示是否将发生算术溢出的布尔值。
        /// 如果将发生溢出，则返回 `self`。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            // 使用 `&` 有助于 LLVM 看到它是在除法中进行的相同检查。
            if unlikely!((self == Self::MIN) & (rhs == -1)) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `self` 除以 `rhs` 时计算余数。
        ///
        /// 返回除法运算后的余数元组和一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回 0。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(rhs == -1) {
                (0, self == Self::MIN)
            } else {
                (self % rhs, false)
            }
        }


        /// 溢出的欧几里得余数。计算 `self.rem_euclid(rhs)`。
        ///
        /// 返回除法运算后的余数元组和一个布尔值，该布尔值指示是否会发生算术溢出。
        /// 如果将发生溢出，则返回 0。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0，则此函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(rhs == -1) {
                (0, self == Self::MIN)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// 否定 self，如果等于最小值，则溢出。
        ///
        /// 返回否定形式 self 的元组以及一个布尔值，该布尔值指示是否发生了溢出。
        /// 如果 `self` 是最小值 (例如，对于类型 `i32` 的值，则为 `i32::MIN`)，则将再次返回该最小值，并且将发生溢出时返回 `true`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// 将 self 左移 `rhs` 位。
        ///
        /// 返回 self 的移位版本的元组以及一个布尔值，该布尔值指示 shift 值是否大于或等于位数。
        /// 如果移位值太大，则将值屏蔽 (N-1)，其中 N 是位数，然后使用该值执行移位。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// 将 self 右移 `rhs` 位。
        ///
        /// 返回 self 的移位版本的元组以及一个布尔值，该布尔值指示 shift 值是否大于或等于位数。
        /// 如果移位值太大，则将值屏蔽 (N-1)，其中 N 是位数，然后使用该值执行移位。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// 计算 `self` 的绝对值。
        ///
        /// 返回 self 的绝对版本的元组以及一个布尔值，该布尔值指示是否发生了溢出。
        /// 如果 self 是最小值
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// 然后将再次返回最小值，并在发生溢出时返回 true。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// 通过平方运算，将自己提升到 `exp` 的功效。
        ///
        /// 返回一个指数的元组以及一个 bool，指示是否发生了溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, true));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // 暂存空间，用于存储 overflowing_mul 的结果。
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// 通过平方运算，将自己提升到 `exp` 的功效。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        ///
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // 由于 `exp != 0`，最终 exp 必须为 1。
            // 分开处理指数的最后一位，因为在此之后对底数进行平方是不必要的，并且可能导致不必要的溢出。
            //
            //
            acc * base
        }

        /// 计算 `self` 的欧几里得除以 `rhs` 的商。
        ///
        /// 这将计算整数 `q`，使得 `self = q * rhs + r`、`r = self.rem_euclid(rhs)` 和 `0 <= r < abs(rhs)`。
        ///
        ///
        /// 换句话说，结果是 `self / rhs` 舍入为整数 `q`，使得 `self >= q * rhs`。
        /// 如果为 `self > 0`，则等于舍入为零 (Rust 中的默认值) ；
        /// 如果为 `self < 0`，则等于朝 +/- 无限取整。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0 或除法导致溢出，则该函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// let b = 4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); // 7 >= 4 * 1
        /// assert_eq!(a.div_euclid(-b), -1); // 7 >= -4 * -1
        /// assert_eq!((-a).div_euclid(b), -2); // -7 >= 4 * -2
        /// assert_eq!((-a).div_euclid(-b), 2); // -7 >= -4 * 2
        /// ```
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// 计算 `self (mod rhs)` 的最小非负余数。
        ///
        /// 就像通过欧几里得除法算法一样 - 给定 `r = self.rem_euclid(rhs)`，`self = rhs * self.div_euclid(rhs) + r` 和 `0 <= r < abs(rhs)`。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为 0 或除法导致溢出，则该函数将为 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// let b = 4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                // 语义等同于 `if rhs < 0 { r - rhs } else { r + rhs }`。
                // 如果 `rhs` 不是 `Self::MIN`，那么 `r + abs(rhs)` 不会溢出，显然是等价的，因为 `r` 是 negative。
                // 否则，`rhs` 是 `Self::MIN`，然后我们有 `r.wrapping_add(Self::MIN.wrapping_abs())`，它计算为 `r.wrapping_add(Self::MIN)`，相当于 `r - Self::MIN`，这就是我们想要的 (并且不会溢出 negative `r`)。
                //
                //
                //
                //
                //
                r.wrapping_add(rhs.wrapping_abs())
            } else {
                r
            }
        }

        /// 计算 `self` 和 `rhs` 的商，将结果四舍五入到负无穷大。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为零，这个函数将会 panic。
        ///
        /// ## 溢出行为
        ///
        /// 溢出时，如果启用溢出检查 (默认在调试模式下)，此函数将 panic，如果禁用溢出检查 (默认在，生产模式，下)，则返回。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("let a: ", stringify!($SelfT)," = 8;")]
        /// let b = 3;
        ///
        /// assert_eq!(a.div_floor(b), 2);
        /// assert_eq!(a.div_floor(-b), -3);
        /// assert_eq!((-a).div_floor(b), -3);
        /// assert_eq!((-a).div_floor(-b), 2);
        /// ```
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_floor(self, rhs: Self) -> Self {
            let d = self / rhs;
            let r = self % rhs;
            if (r > 0 && rhs < 0) || (r < 0 && rhs > 0) {
                d - 1
            } else {
                d
            }
        }

        /// 计算 `self` 和 `rhs` 的商，将结果四舍五入到正无穷大。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为零，这个函数将会 panic。
        ///
        /// ## 溢出行为
        ///
        /// 溢出时，如果启用溢出检查 (默认在调试模式下)，此函数将 panic，如果禁用溢出检查 (默认在，生产模式，下)，则返回。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("let a: ", stringify!($SelfT)," = 8;")]
        /// let b = 3;
        ///
        /// assert_eq!(a.div_ceil(b), 3);
        /// assert_eq!(a.div_ceil(-b), -2);
        /// assert_eq!((-a).div_ceil(b), -2);
        /// assert_eq!((-a).div_ceil(-b), 3);
        /// ```
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_ceil(self, rhs: Self) -> Self {
            let d = self / rhs;
            let r = self % rhs;
            if (r > 0 && rhs > 0) || (r < 0 && rhs < 0) {
                d + 1
            } else {
                d
            }
        }

        /// 如果 `rhs` 为正数，则计算大于或等于 `self` 的最小值，即 `rhs` 的倍数。
        /// 如果 `rhs` 为负数，则计算小于或等于 `rhs` 倍数的 `self` 的最大值。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 为零，这个函数将会 panic。
        ///
        /// ## 溢出行为
        ///
        /// 溢出时，如果启用溢出检查 (默认在调试模式下)，此函数将 panic，如果禁用溢出检查 (默认在，生产模式，下)，则返回。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("assert_eq!(16_", stringify!($SelfT), ".next_multiple_of(8), 16);")]
        #[doc = concat!("assert_eq!(23_", stringify!($SelfT), ".next_multiple_of(8), 24);")]
        #[doc = concat!("assert_eq!(16_", stringify!($SelfT), ".next_multiple_of(-8), 16);")]
        #[doc = concat!("assert_eq!(23_", stringify!($SelfT), ".next_multiple_of(-8), 16);")]
        #[doc = concat!("assert_eq!((-16_", stringify!($SelfT), ").next_multiple_of(8), -16);")]
        #[doc = concat!("assert_eq!((-23_", stringify!($SelfT), ").next_multiple_of(8), -16);")]
        #[doc = concat!("assert_eq!((-16_", stringify!($SelfT), ").next_multiple_of(-8), -16);")]
        #[doc = concat!("assert_eq!((-23_", stringify!($SelfT), ").next_multiple_of(-8), -24);")]
        /// ```
        ///
        ///
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_multiple_of(self, rhs: Self) -> Self {
            // 否则，当 self == T::MIN 时计算 `r` 时，将导致失败。
            if rhs == -1 {
                return self;
            }

            let r = self % rhs;
            let m = if (r > 0 && rhs < 0) || (r < 0 && rhs > 0) {
                r + rhs
            } else {
                r
            };

            if m == 0 {
                self
            } else {
                self + (rhs - m)
            }
        }

        /// 如果 `rhs` 为正数，则计算大于或等于 `self` 的最小值，即 `rhs` 的倍数。
        ///
        /// 如果 `rhs` 为负数，则计算小于或等于 `rhs` 倍数的 `self` 的最大值。
        /// 如果 `rhs` 为零，则返回 `None`，否则操作会导致溢出。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(int_roundings)]
        #[doc = concat!("assert_eq!(16_", stringify!($SelfT), ".checked_next_multiple_of(8), Some(16));")]
        #[doc = concat!("assert_eq!(23_", stringify!($SelfT), ".checked_next_multiple_of(8), Some(24));")]
        #[doc = concat!("assert_eq!(16_", stringify!($SelfT), ".checked_next_multiple_of(-8), Some(16));")]
        #[doc = concat!("assert_eq!(23_", stringify!($SelfT), ".checked_next_multiple_of(-8), Some(16));")]
        #[doc = concat!("assert_eq!((-16_", stringify!($SelfT), ").checked_next_multiple_of(8), Some(-16));")]
        #[doc = concat!("assert_eq!((-23_", stringify!($SelfT), ").checked_next_multiple_of(8), Some(-16));")]
        #[doc = concat!("assert_eq!((-16_", stringify!($SelfT), ").checked_next_multiple_of(-8), Some(-16));")]
        #[doc = concat!("assert_eq!((-23_", stringify!($SelfT), ").checked_next_multiple_of(-8), Some(-24));")]
        #[doc = concat!("assert_eq!(1_", stringify!($SelfT), ".checked_next_multiple_of(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_multiple_of(2), None);")]
        /// ```
        ///
        #[unstable(feature = "int_roundings", issue = "88581")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_next_multiple_of(self, rhs: Self) -> Option<Self> {
            // 否则，当 self == T::MIN 时计算 `r` 时，将导致失败。
            if rhs == -1 {
                return Some(self);
            }

            let r = try_opt!(self.checked_rem(rhs));
            let m = if (r > 0 && rhs < 0) || (r < 0 && rhs > 0) {
                // r + rhs 不能溢出，因为它们的符号相反
                r + rhs
            } else {
                r
            };

            if m == 0 {
                Some(self)
            } else {
                // rhs - m 不能溢出，因为 m 与 rhs 具有相同的符号
                self.checked_add(rhs - m)
            }
        }

        /// 返回数字相对于任意底数的对数，向下取整。
        ///
        /// 由于实现细节，此方法可能未优化；
        /// `ilog2` 可以更有效地产生以 2 为底的结果，而 `ilog10` 可以更有效地产生以 10 为底的结果。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `self` 小于或等于 0，或者 `base` 小于 2，这个函数将会 panic。
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".ilog(5), 1);")]
        /// ```
        ///
        ///
        #[stable(feature = "int_log", since = "1.67.0")]
        #[rustc_const_stable(feature = "int_log", since = "1.67.0")]
        #[rustc_allow_const_fn_unstable(const_option)]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[track_caller]
        pub const fn ilog(self, base: Self) -> u32 {
            assert!(base >= 2, "base of integer logarithm must be at least 2");
            self.checked_ilog(base).expect("argument of integer logarithm must be positive")
        }

        /// 返回数字的以 2 为底的对数，向下取整。
        ///
        /// # Panics
        ///
        /// 如果 `self` 小于或等于 0，这个函数将会 panic。
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".ilog2(), 1);")]
        /// ```
        #[stable(feature = "int_log", since = "1.67.0")]
        #[rustc_const_stable(feature = "int_log", since = "1.67.0")]
        #[rustc_allow_const_fn_unstable(const_option)]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[track_caller]
        pub const fn ilog2(self) -> u32 {
            self.checked_ilog2().expect("argument of integer logarithm must be positive")
        }

        /// 返回数字的以 10 为底的对数，向下取整。
        ///
        /// # Panics
        ///
        /// 如果 `self` 小于或等于 0，这个函数将会 panic。
        ///
        /// # Example
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".ilog10(), 1);")]
        /// ```
        #[stable(feature = "int_log", since = "1.67.0")]
        #[rustc_const_stable(feature = "int_log", since = "1.67.0")]
        #[rustc_allow_const_fn_unstable(const_option)]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[track_caller]
        pub const fn ilog10(self) -> u32 {
            self.checked_ilog10().expect("argument of integer logarithm must be positive")
        }

        /// 返回数字相对于任意底数的对数，向下取整。
        ///
        /// 如果数字为负数或零，或者基数不至少为 2，则返回 `None`。
        ///
        /// 由于实现细节，此方法可能未优化；
        /// `checked_ilog2` 可以更有效地产生以 2 为底的结果，而 `checked_ilog10` 可以更有效地产生以 10 为底的结果。
        ///
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_ilog(5), Some(1));")]
        /// ```
        ///
        #[stable(feature = "int_log", since = "1.67.0")]
        #[rustc_const_stable(feature = "int_log", since = "1.67.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_ilog(self, base: Self) -> Option<u32> {
            if self <= 0 || base <= 1 {
                None
            } else {
                let mut n = 0;
                let mut r = self;

                // 128 位宽整数的优化。
                if Self::BITS == 128 {
                    let b = Self::ilog2(self) / (Self::ilog2(base) + 1);
                    n += b;
                    r /= base.pow(b as u32);
                }

                while r >= base {
                    r /= base;
                    n += 1;
                }
                Some(n)
            }
        }

        /// 返回数字的以 2 为底的对数，向下取整。
        ///
        /// 如果数字为负数或零，则返回 `None`。
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_ilog2(), Some(1));")]
        /// ```
        #[stable(feature = "int_log", since = "1.67.0")]
        #[rustc_const_stable(feature = "int_log", since = "1.67.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_ilog2(self) -> Option<u32> {
            if self <= 0 {
                None
            } else {
                // SAFETY: 我们刚刚检查过这个数字是正数
                let log = (Self::BITS - 1) - unsafe { intrinsics::ctlz_nonzero(self) as u32 };
                Some(log)
            }
        }

        /// 返回数字的以 10 为底的对数，向下取整。
        ///
        /// 如果数字为负数或零，则返回 `None`。
        ///
        /// # Example
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".checked_ilog10(), Some(1));")]
        /// ```
        #[stable(feature = "int_log", since = "1.67.0")]
        #[rustc_const_stable(feature = "int_log", since = "1.67.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_ilog10(self) -> Option<u32> {
            if self > 0 {
                Some(int_log10::$ActualT(self as $ActualT))
            } else {
                None
            }
        }

        /// 计算 `self` 的绝对值。
        ///
        /// # 溢出行为
        ///
        /// 的绝对值
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// 不能表示为
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// 并尝试计算它会导致溢出。
        /// 这意味着在这种情况下，处于调试模式的代码将触发 panic，并且优化后的代码将返回
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// 没有 panic。
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // 请注意，上面的 #[rustc_inherit_overflow_checks] 和 #[inline] 意味着减法的溢出语义取决于我们正在调用的 crate。
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// 计算 `self` 和 `other` 之间的绝对差。
        ///
        /// 这个函数总是通过返回一个无符号整数来返回没有溢出或 panics 的正确答案。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".abs_diff(80), 20", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".abs_diff(110), 10", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").abs_diff(80), 180", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").abs_diff(-120), 20", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.abs_diff(", stringify!($SelfT), "::MAX), ", stringify!($UnsignedT), "::MAX);")]
        /// ```
        #[stable(feature = "int_abs_diff", since = "1.60.0")]
        #[rustc_const_stable(feature = "int_abs_diff", since = "1.60.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn abs_diff(self, other: Self) -> $UnsignedT {
            if self < other {
                // 使用 `x as U` 将非负 x 从有符号转换为无符号保持不变，但负 x 转换为值 x + 2^N。
                // 因此，如果 `s` 和 `o` 分别是二进制变量，分别表示 `self` 和 `other` 是否为负，则我们正在计算数学值：
                //
                //
                //    (other + o*2^N) - (self + s*2^N)    mod  2^N other - self + (o-s)*2^N            mod  2^N other - self                        mod  2^N
                //
                // 最后，取 `other - self` 的数学值的 mod 2^N 不会改变它，因为它已经在 [0, 2^N) 范围内。
                //
                //
                //
                //
                //
                //
                (other as $UnsignedT).wrapping_sub(self as $UnsignedT)
            } else {
                (self as $UnsignedT).wrapping_sub(other as $UnsignedT)
            }
        }

        /// 返回一个表示 `self` 的符号的数字。
        ///
        ///  - `0` 如果数字为零
        ///  - `1` 如果数字是正数
        ///  - `-1` 如果数字是负数
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline(always)]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// 如果 `self` 为正数，则返回 `true`; 如果数字为零或负数，则返回 `false`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[must_use]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline(always)]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// 如果 `self` 为负，则返回 `true`; 如果数字为零或正，则返回 `false`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[must_use]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline(always)]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// 以大端 (网络) 字节顺序将这个整数的内存表示形式作为字节数组返回。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// 以小端字节顺序将这个整数的内存表示形式返回为字节数组。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// 将此整数的内存表示作为本机字节顺序的字节数组返回。
        ///
        /// 由于使用了目标平台的原生字节序，因此，可移植代码应酌情使用 [`to_be_bytes`] 或 [`to_le_bytes`]。
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        ///
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes,
        ///     if cfg!(target_endian = "big") {
        #[doc = concat!("        ", $be_bytes)]
        ///     } else {
        #[doc = concat!("        ", $le_bytes)]
        ///     }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: const 之所以听起来不错，是因为整数是普通的旧数据类型，因此我们始终可以将它们转换为字节数组
        //
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: 整数是普通的旧数据类型，因此我们始终可以将它们转换为字节数组
            //
            unsafe { mem::transmute(self) }
        }

        /// 从其表示形式以 big endian 的字节数组形式创建一个整数值。
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// 从切片而不是数组开始时，可以使用容易出错的转换 API：
        ///
        /// ```
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        ///     *input = rest;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// 从它的表示形式以 little endian 的字节数组形式创建一个整数值。
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// 从切片而不是数组开始时，可以使用容易出错的转换 API：
        ///
        /// ```
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        ///     *input = rest;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// 从其内存表示形式创建一个整数值，以原生字节序表示为字节数组。
        ///
        /// 由于使用了目标平台的原生字节序，因此可移植代码可能希望酌情使用 [`from_be_bytes`] 或 [`from_le_bytes`]。
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } else {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// 从切片而不是数组开始时，可以使用容易出错的转换 API：
        ///
        /// ```
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        ///     *input = rest;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[must_use]
        // SAFETY: const 之所以听起来不错，是因为整数是普通的旧数据类型，因此我们可以随时将其转换为整数
        //
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: 整数是普通的旧数据类型，因此我们可以随时将其转换为整数
            unsafe { mem::transmute(bytes) }
        }

        /// 新代码应优先使用
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        ///
        /// 返回此整数类型可以表示的最小值。
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[deprecated(since = "TBD", note = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// 新代码应优先使用
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        ///
        /// 返回此整数类型可以表示的最大值。
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[deprecated(since = "TBD", note = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}
