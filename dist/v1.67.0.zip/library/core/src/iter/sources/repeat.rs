use crate::iter::{FusedIterator, TrustedLen};

/// 创建一个新的迭代器，该迭代器不断重复单个元素。
///
/// `repeat()` 函数一次又一次地重复单个值。
///
/// 无限迭代器 (如 `repeat()`) 通常与适配器 (如 [`Iterator::take()`]) 一起使用，以使其具有有限性。
///
/// 如果所需的迭代器元素类型未实现 `Clone`，或者不想将重复的元素保留在内存中，则可以改用 [`repeat_with()`] 函数。
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// use std::iter;
///
/// // 第四个 4ever：
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // 是的，还是四个
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// 用 [`Iterator::take()`] 进行有限化：
///
/// ```
/// use std::iter;
///
/// // 最后一个例子太多了。我们只有四个四。
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... 现在我们完成了
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "iter_repeat")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// 一个无限重复元素的迭代器。
///
/// 该 `struct` 由 [`repeat()`] 函数创建。有关更多信息，请参见其文档。
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        // 推进单个元素的无限迭代器是不可行的。
        let _ = n;
        Ok(())
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let _ = n;
        Some(self.element.clone())
    }

    fn last(self) -> Option<A> {
        loop {}
    }

    fn count(self) -> usize {
        loop {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }

    #[inline]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        // 推进单个元素的无限迭代器是不可行的。
        let _ = n;
        Ok(())
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        let _ = n;
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}
