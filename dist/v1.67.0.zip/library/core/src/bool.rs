//! impl bool {}

use crate::marker::Destruct;

impl bool {
    /// 如果 `bool` 是 [`true`](../std/keyword.true.html)，则返回 `Some(t)`，否则返回 `None`。
    ///
    /// 传递给 `then_some` 的参数被热切地评估; 如果要传递函数调用的结果，建议使用 [`then`]，它是惰性求值的。
    ///
    ///
    /// [`then`]: bool::then
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(false.then_some(0), None);
    /// assert_eq!(true.then_some(0), Some(0));
    /// ```
    ///
    /// ```
    /// let mut a = 0;
    /// let mut function_with_side_effects = || { a += 1; };
    ///
    /// true.then_some(function_with_side_effects());
    /// false.then_some(function_with_side_effects());
    ///
    /// // `a` 增加了两次，因为传递给 `then_some` 的值被急切地评估。
    /////
    /// assert_eq!(a, 2);
    /// ```
    ///
    ///
    #[stable(feature = "bool_to_option", since = "1.62.0")]
    #[rustc_const_unstable(feature = "const_bool_to_option", issue = "91917")]
    #[inline]
    pub const fn then_some<T>(self, t: T) -> Option<T>
    where
        T: ~const Destruct,
    {
        if self { Some(t) } else { None }
    }

    /// 如果 `bool` 是 [`true`](../std/keyword.true.html)，则返回 `Some(f())`，否则返回 `None`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(false.then(|| 0), None);
    /// assert_eq!(true.then(|| 0), Some(0));
    /// ```
    ///
    /// ```
    /// let mut a = 0;
    ///
    /// true.then(|| { a += 1; });
    /// false.then(|| { a += 1; });
    ///
    /// // `a` 增加一次，因为闭包被 `then` 懒惰地评估。
    /////
    /// assert_eq!(a, 1);
    /// ```
    #[stable(feature = "lazy_bool_to_option", since = "1.50.0")]
    #[rustc_const_unstable(feature = "const_bool_to_option", issue = "91917")]
    #[inline]
    pub const fn then<T, F>(self, f: F) -> Option<T>
    where
        F: ~const FnOnce() -> T,
        F: ~const Destruct,
    {
        if self { Some(f()) } else { None }
    }
}
