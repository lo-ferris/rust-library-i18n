//! `Result` 类型的错误处理。
//!
//! [`Result<T, E>`][`Result`] 是用于返回和传播错误的类型。
//! 它是一个带有变体的枚举，[`Ok(T)`]，表示成功并包含一个值，而 [`Err(E)`] 表示错误并包含一个错误值。
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! 只要预期到错误并且可以恢复，函数就返回 [`Result`]。在 `std` crate 中，[`Result`] 最主要用于 [I/O](../../std/io/index.html)。
//!
//! 返回 [`Result`] 的简单函数可以像这样定义和使用：
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {v:?}"),
//!     Err(e) => println!("error parsing header: {e:?}"),
//! }
//! ```
//!
//! 在简单情况下，在 [`Result`] 上进行模式匹配非常简单明了，但是 [`Result`] 附带了一些方便的方法，使使用它更加简洁。
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` 和 `is_err` 方法按照他们说的做。
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` 消耗 `Result` 并产生另一个。
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // 使用 `and_then` 继续计算。
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // 使用 `or_else` 处理该错误。
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // 消费结果并用 `unwrap` 返回内容。
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # 必须使用结果
//!
//! 使用返回值指示错误的一个常见问题是，很容易忽略返回值，从而无法处理错误。
//! [`Result`] 与 `#[must_use]` 属性一起注解，当忽略 Result 值时会导致编译器发出警告。
//! 这使得 [`Result`] 对于可能遇到错误但不会返回有用值的函数特别有用。
//!
//! 考虑 [`Write`] trait 为 I/O 类型定义的 [`write_all`] 方法：
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] 的实际定义使用了 [`io::Result`]，它只是 <code>[Result]<T, [io::Error]></code> 的同义词。*
//!
//! 该方法不会产生值，但是写入可能会失败。处理错误情况至关重要，并且 *不要* 编写类似以下内容的代码：
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // 如果 `write_all` 错误，那么我们将永远不会知道，因为返回值将被忽略。
//! //
//! file.write_all(b"important message");
//! ```
//!
//! 如果您确实将其写在 Rust 中，则编译器将向您发出警告 (默认情况下，由 `unused_must_use` lint 控制)。
//!
//! 相反，如果您不想处理该错误，则可以断言 [`expect`] 成功。
//! 如果写入失败，这将为 panic，提供了一条边际有用的消息，指出原因：
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! 您可能还简单地宣称成功：
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! 或者使用 [`?`] 在调用栈中传播错误：
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # 问号运算符，`?`
//!
//! 在编写调用许多返回 [`Result`] 类型的函数的代码时，错误处理可能很乏味。
//! 问号运算符 [`?`] 在调用栈中隐藏了一些传播错误的样板。
//!
//! 它将替换为：
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // 尽早返回错误
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! 有了这个：
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // 尽早返回错误
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *好多了！*
//!
//! 用 [`?`] 结束表达式将得到未包装的成功 ([`Ok`]) 值，除非结果为 [`Err`]，在这种情况下，[`Err`] 会从封闭的函数中提前返回。
//!
//!
//! [`?`] 只能用在返回 [`Result`] 的函数中，因为它提供了 [`Err`] 的提前返回。
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html "io::Write"
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all "io::Write::write_all"
//! [`io::Result`]: ../../std/io/type.Result.html "io::Result"
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [io::Error]: ../../std/io/struct.Error.html "io::Error"
//!
//! # 方法概述
//!
//! 除了使用模式匹配，[`Result`] 还提供了多种不同的方法。
//!
//! ## 查询变体
//!
//! 如果 [`Result`] 分别为 [`Ok`] 或 [`Err`]，则 [`is_ok`] 和 [`is_err`] 方法返回 [`true`]。
//!
//! [`is_err`]: Result::is_err
//! [`is_ok`]: Result::is_ok
//!
//! ## 用于处理引用的适配器
//!
//! * [`as_ref`] 从 `&Result<T, E>` 转换为 `Result<&T, &E>`
//! * [`as_mut`] 从 `&mut Result<T, E>` 转换为 `Result<&mut T, &mut E>`
//! * [`as_deref`] 从 `&Result<T, E>` 转换为 `Result<&T::Target, &E>`
//! * [`as_deref_mut`] 从 `&mut Result<T, E>` 转换为 `Result<&mut T::Target, &mut E>`
//!
//! [`as_deref`]: Result::as_deref
//! [`as_deref_mut`]: Result::as_deref_mut
//! [`as_mut`]: Result::as_mut
//! [`as_ref`]: Result::as_ref
//!
//! ## 提取包含的值
//!
//! 当它是 [`Ok`] 变体时，这些方法提取 [`Result<T, E>`] 中包含的值。如果 [`Result`] 是 [`Err`]：
//!
//! * [`expect`] panics 带有提供的自定义消息
//! * [`unwrap`] panics 带有泛型信息
//! * [`unwrap_or`] 返回提供的默认值
//! * [`unwrap_or_default`] 返回类型 `T` 的默认值 (必须实现 [`Default`] trait)
//! * [`unwrap_or_else`] 返回对提供的函数求值的结果
//!
//! panicking 方法 [`expect`] 和 [`unwrap`] 需要 `E` 来实现 [`Debug`] trait。
//!
//! [`Debug`]: crate::fmt::Debug
//! [`expect`]: Result::expect
//! [`unwrap`]: Result::unwrap
//! [`unwrap_or`]: Result::unwrap_or
//! [`unwrap_or_default`]: Result::unwrap_or_default
//! [`unwrap_or_else`]: Result::unwrap_or_else
//!
//! 当它是 [`Err`] 变体时，这些方法提取 [`Result<T, E>`] 中包含的值。他们需要 `T` 来实现 [`Debug`] trait。如果 [`Result`] 是 [`Ok`]：
//!
//! * [`expect_err`] panics 带有提供的自定义消息
//! * [`unwrap_err`] panics 带有泛型信息
//!
//! [`Debug`]: crate::fmt::Debug
//! [`expect_err`]: Result::expect_err
//! [`unwrap_err`]: Result::unwrap_err
//!
//! ## 转换包含的值
//!
//! 这些方法将 [`Result`] 转换为 [`Option`]：
//!
//! * [`err`][Result::err] transforms [`Result<T, E>`] into [`Option<E>`], mapping [`Err(e)`] to [`Some(e)`] and [`Ok(v)`] to [`None`]
//! * [`ok`][Result::ok] transforms [`Result<T, E>`] into [`Option<T>`], mapping [`Ok(v)`] to [`Some(v)`] and [`Err(e)`] to [`None`]
//! * [`transpose`] transposes a [`Result`] of an [`Option`] into an [`Option`] of a [`Result`]
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
// 不要为 `err` 或 `ok` 添加链接引用定义，因为由于大小写折叠，它们会在其他地方为 `Err` 和 `Ok` 生成大量不正确的 URL。
//
//
//! [`Err(e)`]: Err
//! [`Ok(v)`]: Ok
//! [`Some(e)`]: Option::Some
//! [`Some(v)`]: Option::Some
//! [`transpose`]: Result::transpose
//!
//! 此方法转换 [`Ok`] 变体中包含的值：
//!
//! * [`map`] 通过将提供的函数应用于 [`Ok`] 的包含值并保持 [`Err`] 值不变，将 [`Result<T, E>`] 转换为 [`Result<U, E>`]
//!
//! [`map`]: Result::map
//!
//! 此方法转换 [`Err`] 变体中包含的值：
//!
//! * [`map_err`] 通过将提供的函数应用于 [`Err`] 的包含值并保持 [`Ok`] 值不变，将 [`Result<T, E>`] 转换为 [`Result<T, F>`]
//!
//! [`map_err`]: Result::map_err
//!
//! 这些方法将 [`Result<T, E>`] 转换为可能不同类型 `U` 的值：
//!
//! * [`map_or`] 将提供的函数应用于 [`Ok`] 的包含值，或者如果 [`Result`] 是返回提供的默认值
//!   [`Err`]
//! * [`map_or_else`] applies the provided function to the contained value of [`Ok`], or applies the provided default fallback function to the contained value of [`Err`]
//!
//! [`map_or`]: Result::map_or
//! [`map_or_else`]: Result::map_or_else
//!
//! ## 布尔运算符
//!
//! 这些方法将 [`Result`] 视为布尔值，其中 [`Ok`] 的作用类似于 [`true`]，而 [`Err`] 的作用类似于 [`false`]。这些方法有两类：一类以 [`Result`] 作为输入，一类以函数作为输入 (延迟评估)。
//!
//! [`and`] 和 [`or`] 方法将另一个 [`Result`] 作为输入，并生成一个 [`Result`] 作为输出。[`and`] 方法可以生成具有与 [`Result<T, E>`] 不同的内部类型 `U` 的 [`Result<U, E>`] 值。
//! [`or`] 方法可以生成具有与 [`Result<T, E>`] 不同的错误类型 `F` 的 [`Result<T, F>`] 值。
//!
//! | method  | self     | input     | output   |
//! |---------|----------|-----------|----------|
//! | [`and`] | `Err(e)` | (ignored) | `Err(e)` |
//! | [`and`] | `Ok(x)`  | `Err(d)`  | `Err(d)` |
//! | [`and`] | `Ok(x)`  | `Ok(y)`   | `Ok(y)`  |
//! | [`or`]  | `Err(e)` | `Err(d)`  | `Err(d)` |
//! | [`or`]  | `Err(e)` | `Ok(y)`   | `Ok(y)`  |
//! | [`or`]  | `Ok(x)`  | (ignored) | `Ok(x)`  |
//!
//! [`and`]: Result::and
//! [`or`]: Result::or
//!
//! [`and_then`] 和 [`or_else`] 方法将函数作为输入，并且仅在需要产生新值时才评估函数。[`and_then`] 方法可以生成一个 [`Result<U，E>`] 值，该值的内部类型 `U` 与 [`Result<T，E>`] 不同。
//! [`or_else`] 方法可以生成具有与 [`Result<T, E>`] 不同的错误类型 `F` 的 [`Result<T, F>`] 值。
//!
//! | method       | self     | function input | function result | output   |
//! |--------------|----------|----------------|-----------------|----------|
//! | [`and_then`] | `Err(e)` | (not provided) | (not evaluated) | `Err(e)` |
//! | [`and_then`] | `Ok(x)`  | `x`            | `Err(d)`        | `Err(d)` |
//! | [`and_then`] | `Ok(x)`  | `x`            | `Ok(y)`         | `Ok(y)`  |
//! | [`or_else`]  | `Err(e)` | `e`            | `Err(d)`        | `Err(d)` |
//! | [`or_else`]  | `Err(e)` | `e`            | `Ok(y)`         | `Ok(y)`  |
//! | [`or_else`]  | `Ok(x)`  | (not provided) | (not evaluated) | `Ok(x)`  |
//!
//! [`and_then`]: Result::and_then
//! [`or_else`]: Result::or_else
//!
//! ## 比较运算符
//!
//! 如果 `T` 和 `E` 都实现 [`PartialOrd`]，那么 [`Result<T, E>`] 将派生其 [`PartialOrd`] 实现。
//! 按照此顺序，一个 [`Ok`] 的比较小于任何 [`Err`]，而两个 [`Ok`] 或两个 [`Err`] 的比较与其包含的值分别在 `T` 或 `E` 中进行比较。
//! 如果 `T` 和 `E` 都实现了 [`Ord`]，那么 [`Result<T, E>`] 也实现了。
//!
//! ```
//! assert!(Ok(1) < Err(0));
//! let x: Result<i32, ()> = Ok(0);
//! let y = Ok(1);
//! assert!(x < y);
//! let x: Result<(), i32> = Err(0);
//! let y = Err(1);
//! assert!(x < y);
//! ```
//!
//! ## 迭代 `Result`
//!
//! 可以对 [`Result`] 进行迭代。如果您需要一个条件为空的迭代器，这会很有帮助。迭代器要么产生单个值 (当 [`Result`] 为 [`Ok`] 时)，要么不产生任何值 (当 [`Result`] 为 [`Err`] 时)。
//! 例如，如果 [`Result`] 是 [`Ok(v)`]，则 [`into_iter`] 的作用类似于 [`once(v)`]; 如果 [`Result`] 是 [`Err`]，则它的作用类似于 [`empty()`]。
//!
//! [`Ok(v)`]: Ok
//! [`empty()`]: crate::iter::empty
//! [`once(v)`]: crate::iter::once
//!
//! [`Result<T, E>`] 上的迭代器分为三种类型：
//!
//! * [`into_iter`] 消耗 [`Result`] 并产生包含的值
//! * [`iter`] 对包含的值产生类型为 `&T` 的不可变引用
//! * [`iter_mut`] 产生一个 `&mut T` 类型的可变引用到包含的值
//!
//! 有关这如何有用的示例，请参见 [迭代 `Option`][Iterating over `Option`]。
//!
//! [Iterating over `Option`]: crate::option#iterating-over-option
//! [`into_iter`]: Result::into_iter
//! [`iter`]: Result::iter
//! [`iter_mut`]: Result::iter_mut
//!
//! 您可能希望使用迭代器链来执行可能失败的操作的多个实例，但希望在继续处理成功结果的同时忽略失败。
//! 在本例中，我们利用 [`Result`] 的可迭代特性，使用 [`flatten`][Iterator::flatten] 仅选择 [`Ok`] 值。
//!
//! ```
//! # use std::str::FromStr;
//! let mut results = vec![];
//! let mut errs = vec![];
//! let nums: Vec<_> = ["17", "not a number", "99", "-27", "768"]
//!    .into_iter()
//!    .map(u8::from_str)
//!    // 保存原始 `Result` 值的克隆以进行检查
//!    .inspect(|x| results.push(x.clone()))
//!    // 挑战：解释这如何仅捕获 `Err` 值
//!    .inspect(|x| errs.extend(x.clone().err()))
//!    .flatten()
//!    .collect();
//! assert_eq!(errs.len(), 3);
//! assert_eq!(nums, [17, 99]);
//! println!("results {results:?}");
//! println!("errs {errs:?}");
//! println!("nums {nums:?}");
//! ```
//!
//! ## 收集到 `Result`
//!
//! [`Result`] 实现了 [`FromIterator`][impl-FromIterator] trait，它允许将 [`Result`] 值上的迭代器收集到原始 [`Result`] 值的每个包含值的集合的 [`Result`] 中，或者如果任何元素是 [`Err`]，则为 [`Err`]。
//!
//!
//! [impl-FromIterator]: Result#impl-FromIterator%3CResult%3CA%2C%20E%3E%3E-for-Result%3CV%2C%20E%3E
//!
//! ```
//! let v = [Ok(2), Ok(4), Err("err!"), Ok(8)];
//! let res: Result<Vec<_>, &str> = v.into_iter().collect();
//! assert_eq!(res, Err("err!"));
//! let v = [Ok(2), Ok(4), Ok(8)];
//! let res: Result<Vec<_>, &str> = v.into_iter().collect();
//! assert_eq!(res, Ok(vec![2, 4, 8]));
//! ```
//!
//! [`Result`] 还实现了 [`Product`][impl-Product] 和 [`Sum`][impl-Sum] traits，允许对 [`Result`] 值的迭代器提供 [`product`][Iterator::product] 和 [`sum`][Iterator::sum] 方法。
//!
//! [impl-Product]: Result#impl-Product%3CResult%3CU%2C%20E%3E%3E-for-Result%3CT%2C%20E%3E
//! [impl-Sum]: Result#impl-Sum%3CResult%3CU%2C%20E%3E%3E-for-Result%3CT%2C%20E%3E
//!
//! ```
//! let v = [Err("error!"), Ok(1), Ok(2), Ok(3), Err("foo")];
//! let res: Result<i32, &str> = v.into_iter().sum();
//! assert_eq!(res, Err("error!"));
//! let v = [Ok(1), Ok(2), Ok(21)];
//! let res: Result<i32, &str> = v.into_iter().product();
//! assert_eq!(res, Ok(42));
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::marker::Destruct;
use crate::ops::{self, ControlFlow, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` 是代表成功 ([`Ok`]) 或失败 ([`Err`]) 的类型。
///
/// 有关详细信息，请参见 [模块文档](self)。
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "Result"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// 包含成功值
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// 包含错误值
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// 类型实现
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // 查询包含的值
    /////////////////////////////////////////////////////////////////////////

    /// 如果结果为 [`Ok`]，则返回 `true`。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result_basics", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// 如果结果是 [`Ok`] 并且其中的值与谓词匹配，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_some_and)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.is_ok_and(|x| x > 1), true);
    ///
    /// let x: Result<u32, &str> = Ok(0);
    /// assert_eq!(x.is_ok_and(|x| x > 1), false);
    ///
    /// let x: Result<u32, &str> = Err("hey");
    /// assert_eq!(x.is_ok_and(|x| x > 1), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "is_some_and", issue = "93050")]
    pub fn is_ok_and(self, f: impl FnOnce(T) -> bool) -> bool {
        match self {
            Err(_) => false,
            Ok(x) => f(x),
        }
    }

    /// 如果结果为 [`Err`]，则返回 `true`。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result_basics", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// 如果结果是 [`Err`] 并且其中的值与谓词匹配，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_some_and)]
    /// use std::io::{Error, ErrorKind};
    ///
    /// let x: Result<u32, Error> = Err(Error::new(ErrorKind::NotFound, "!"));
    /// assert_eq!(x.is_err_and(|x| x.kind() == ErrorKind::NotFound), true);
    ///
    /// let x: Result<u32, Error> = Err(Error::new(ErrorKind::PermissionDenied, "!"));
    /// assert_eq!(x.is_err_and(|x| x.kind() == ErrorKind::NotFound), false);
    ///
    /// let x: Result<u32, Error> = Ok(123);
    /// assert_eq!(x.is_err_and(|x| x.kind() == ErrorKind::NotFound), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "is_some_and", issue = "93050")]
    pub fn is_err_and(self, f: impl FnOnce(E) -> bool) -> bool {
        match self {
            Ok(_) => false,
            Err(e) => f(e),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 每个变体的适配器
    /////////////////////////////////////////////////////////////////////////

    /// 从 `Result<T, E>` 转换为 [`Option<T>`]。
    ///
    /// 将 `self` 转换为 [`Option<T>`]，使用 `self`，并丢弃错误 (如果有)。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_result_drop", issue = "92384")]
    pub const fn ok(self) -> Option<T>
    where
        E: ~const Destruct,
    {
        match self {
            Ok(x) => Some(x),
            // FIXME: ~const 丢弃还不能正常工作
            #[allow(unused_variables)]
            Err(x) => None,
        }
    }

    /// 从 `Result<T, E>` 转换为 [`Option<E>`]。
    ///
    /// 将 `self` 转换为 [`Option<E>`]，使用 `self`，并丢弃成功值 (如果有)。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_result_drop", issue = "92384")]
    pub const fn err(self) -> Option<E>
    where
        T: ~const Destruct,
    {
        match self {
            // FIXME: ~const 丢弃还不能正常工作
            #[allow(unused_variables)]
            Ok(x) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 用于引用的适配器
    /////////////////////////////////////////////////////////////////////////

    /// 从 `&Result<T, E>` 转换为 `Result<&T, &E>`。
    ///
    /// 产生一个新的 `Result`，其中包含对原始引用的引用，并将原始保留在原处。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result_basics", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// 从 `&mut Result<T, E>` 转换为 `Result<&mut T, &mut E>`。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 转换包含的值
    /////////////////////////////////////////////////////////////////////////

    /// 通过对包含的 [`Ok`] 值应用函数，将 [`Err`] 值 Maps 转换为 `Result<U, E>`，而保持 [`Err`] 值不变。
    ///
    ///
    /// 该函数可用于组合两个函数的结果。
    ///
    /// # Examples
    ///
    /// 在字符串的每一行上将数字乘以 2 来打印数字。
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{n}"),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// 返回提供的默认值 (如果 [`Err`])，或者将函数应用于包含的值 (如果 [`Ok`])，
    ///
    /// 传递给 `map_or` 的参数会被急切地评估； 如果要传递函数调用的结果，建议使用 [`map_or_else`]，它是延迟计算的。
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// 通过将 fallback 函数 `default` 应用于包含的 [`Err`] 值，或将函数 `f` 应用于包含的 [`Ok`] 值，将 `Result<T, E>` 映射为 `U`。
    ///
    ///
    /// 此函数可用于在处理错误时解压成功的结果。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// 通过对包含的 [`Err`] 值应用函数，将 [`Ok`] 值 Maps 转换为 `Result<T, F>`，而保持 [`Ok`] 值不变。
    ///
    ///
    /// 此函数可用于在处理错误时传递成功的结果。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {x}") }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /// 使用对包含值的引用调用提供的闭包 (如果 [`Ok`])。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_option_inspect)]
    ///
    /// let x: u8 = "4"
    ///     .parse::<u8>()
    ///     .inspect(|x| println!("original: {x}"))
    ///     .map(|x| x.pow(3))
    ///     .expect("failed to parse number");
    /// ```
    #[inline]
    #[unstable(feature = "result_option_inspect", issue = "91345")]
    pub fn inspect<F: FnOnce(&T)>(self, f: F) -> Self {
        if let Ok(ref t) = self {
            f(t);
        }

        self
    }

    /// 调用提供的闭包，并引用包含的错误 (如果 [`Err`])。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_option_inspect)]
    ///
    /// use std::{fs, io};
    ///
    /// fn read() -> io::Result<String> {
    ///     fs::read_to_string("address.txt")
    ///         .inspect_err(|e| eprintln!("failed to read file: {e}"))
    /// }
    /// ```
    #[inline]
    #[unstable(feature = "result_option_inspect", issue = "91345")]
    pub fn inspect_err<F: FnOnce(&E)>(self, f: F) -> Self {
        if let Err(ref e) = self {
            f(e);
        }

        self
    }

    /// 从 `Result<T, E>` (或 `&Result<T, E>`) 转换为 `Result<&<T as Deref>::Target, &E>`。
    ///
    /// 通过 [`Deref`](crate::ops::Deref) 强制转换原始 [`Result`] 的 [`Ok`] 变体，并返回新的 [`Result`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E>
    where
        T: Deref,
    {
        self.as_ref().map(|t| t.deref())
    }

    /// 从 `Result<T, E>` (或 `&mut Result<T, E>`) 转换为 `Result<&mut <T as DerefMut>::Target, &mut E>`。
    ///
    /// 通过 [`DerefMut`](crate::ops::DerefMut) 强制转换原始 [`Result`] 的 [`Ok`] 变体，并返回新的 [`Result`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E>
    where
        T: DerefMut,
    {
        self.as_mut().map(|t| t.deref_mut())
    }

    /////////////////////////////////////////////////////////////////////////
    // 迭代器构造函数
    /////////////////////////////////////////////////////////////////////////

    /// 返回可能包含的值的迭代器。
    ///
    /// 如果结果为 [`Result::Ok`]，则迭代器将产生一个值，否则将不产生任何值。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// 返回可能包含的值的可变迭代器。
    ///
    /// 如果结果为 [`Result::Ok`]，则迭代器将产生一个值，否则将不产生任何值。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    /////////////////////////////////////////////////////////////////////////
    // 提取一个值
    /////////////////////////////////////////////////////////////////////////

    /// 返回包含 `self` 值的包含的 [`Ok`] 值。
    ///
    /// 由于此函数可能为 panic，因此通常不建议使用该函数。
    /// 相反，更喜欢使用模式匹配并显式处理 [`Err`] 大小写，或者调用 [`unwrap_or`]，[`unwrap_or_else`] 或 [`unwrap_or_default`]。
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// 如果值为 [`Err`]，就会出现 panics，其中 panic 消息包括传递的消息以及 [`Err`] 的内容。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // `Testing expect: emergency failure` 的 panics
    /// ```
    ///
    /// # 推荐的消息样式
    ///
    /// 我们建议使用 `expect` 消息来描述您期望 `Result` 应该是 `Ok` 的原因。
    ///
    /// ```should_panic
    /// let path = std::env::var("IMPORTANT_PATH")
    ///     .expect("env variable `IMPORTANT_PATH` should be set by `wrapper_script.sh`");
    /// ```
    ///
    /// **提示**: 如果您无法记住如何表达预期错误消息，请记住将注意力集中在 "should" 上，就像在 "env 变量应该由 blah 设置" 或 " 给定的二进制文件应该可由当前用户使用和执行" 中一样。
    ///
    /// 有关期望消息样式的更多详细信息以及我们建议背后的原因，请参见 [`std::error`](../../std/error/index.html) 模块文档中有关 ["常见的消息样式"](../../std/error/index.html#common-message-styles) 的部分。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T
    where
        E: fmt::Debug,
    {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// 返回包含 `self` 值的包含的 [`Ok`] 值。
    ///
    /// 由于此函数可能为 panic，因此通常不建议使用该函数。
    /// 相反，更喜欢使用模式匹配并显式处理 [`Err`] 大小写，或者调用 [`unwrap_or`]，[`unwrap_or_else`] 或 [`unwrap_or_default`]。
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// 如果该值为 [`Err`]，就会出现 Panics，并由 [`Err`] 的值提供 panic 消息。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // `emergency failure` 的 panics
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T
    where
        E: fmt::Debug,
    {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }

    /// 返回包含的 [`Ok`] 值或默认值
    ///
    /// 然后使用 `self` 参数，如果 [`Ok`]，则返回包含的值，否则如果 [`Err`]，则返回该类型的默认值。
    ///
    ///
    /// # Examples
    ///
    /// 将字符串转换为整数，将格式不正确的字符串转换为 0 (整数的默认值)。
    /// [`parse`] 将字符串转换为实现 [`FromStr`] 的任何其他类型，并在出错时返回 [`Err`]。
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T
    where
        T: Default,
    {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }

    /// 返回包含 `self` 值的包含的 [`Err`] 值。
    ///
    /// # Panics
    ///
    /// 如果值为 [`Ok`]，就会出现 panics，其中 panic 消息包括传递的消息以及 [`Ok`] 的内容。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // `Testing expect_err: 10` 的 panics
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E
    where
        T: fmt::Debug,
    {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// 返回包含 `self` 值的包含的 [`Err`] 值。
    ///
    /// # Panics
    ///
    /// 如果该值为 [`Ok`]，则会发生 panic，[`Ok`] 的值提供自定义 panic 消息。
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // `2` 的 panics
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E
    where
        T: fmt::Debug,
    {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }

    /// 返回包含的 [`Ok`] 值，但不返回 panics。
    ///
    /// 与 [`unwrap`] 不同，已知该方法永远不会对其实现的结果类型进行 panic 的处理。
    /// 因此，它可以代替 `unwrap` 用作可维护性保护措施，如果以后将 `Result` 的错误类型更改为实际可能发生的错误，它将无法编译。
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{s}");
    /// ```
    ///
    ///
    #[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
    #[inline]
    pub fn into_ok(self) -> T
    where
        E: Into<!>,
    {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }

    /// 返回包含的 [`Err`] 值，但从不返回 panics。
    ///
    /// 与 [`unwrap_err`] 不同，已知此方法永远不会在其实现的结果类型上使用 panic。
    /// 因此，它可以代替 `unwrap_err` 用作可维护性保障，如果 `Result` 的 ok 类型稍后更改为实际可以发生的类型，则将无法编译。
    ///
    ///
    /// [`unwrap_err`]: Result::unwrap_err
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_bad_news() -> Result<!, String> {
    ///     Err("Oops, it failed".into())
    /// }
    ///
    /// let error: String = only_bad_news().into_err();
    /// println!("{error}");
    /// ```
    ///
    ///
    #[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
    #[inline]
    pub fn into_err(self) -> E
    where
        T: Into<!>,
    {
        match self {
            Ok(x) => x.into(),
            Err(e) => e,
        }
    }

    ////////////////////////////////////////////////////////////////////////
    // 对值的布尔运算，渴望和懒惰
    /////////////////////////////////////////////////////////////////////////

    /// 如果结果为 [`Ok`]，则返回 `res`; 否则，返回 `self` 的 [`Err`] 值。
    ///
    /// 传递给 `and` 的参数被热切地评估; 如果要传递函数调用的结果，建议使用 [`and_then`]，它是惰性求值的。
    ///
    ///
    /// [`and_then`]: Result::and_then
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    ///
    #[inline]
    #[rustc_const_unstable(feature = "const_result_drop", issue = "92384")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn and<U>(self, res: Result<U, E>) -> Result<U, E>
    where
        T: ~const Destruct,
        U: ~const Destruct,
        E: ~const Destruct,
    {
        match self {
            // FIXME: ~const 丢弃还不能正常工作
            #[allow(unused_variables)]
            Ok(x) => res,
            Err(e) => Err(e),
        }
    }

    /// 如果结果为 [`Ok`]，则调用 `op`，否则返回 `self` 的 [`Err`] 值。
    ///
    ///
    /// 该函数可用于基于 `Result` 值的控制流。
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq_then_to_string(x: u32) -> Result<String, &'static str> {
    ///     x.checked_mul(x).map(|sq| sq.to_string()).ok_or("overflowed")
    /// }
    ///
    /// assert_eq!(Ok(2).and_then(sq_then_to_string), Ok(4.to_string()));
    /// assert_eq!(Ok(1_000_000).and_then(sq_then_to_string), Err("overflowed"));
    /// assert_eq!(Err("not a number").and_then(sq_then_to_string), Err("not a number"));
    /// ```
    ///
    /// 通常用于链接可能返回 [`Err`] 的错误操作。
    ///
    /// ```
    /// use std::{io::ErrorKind, path::Path};
    ///
    /// // Note: 在 Windows "/" 映射到 "C:\"
    /// let root_modified_time = Path::new("/").metadata().and_then(|md| md.modified());
    /// assert!(root_modified_time.is_ok());
    ///
    /// let should_fail = Path::new("/bad/path").metadata().and_then(|md| md.modified());
    /// assert!(should_fail.is_err());
    /// assert_eq!(should_fail.unwrap_err().kind(), ErrorKind::NotFound);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// 如果结果为 [`Err`]，则返回 `res`; 否则，返回 `self` 的 [`Ok`] 值。
    ///
    /// 传递给 `or` 的参数会被急切地评估； 如果要传递函数调用的结果，建议使用 [`or_else`]，它是延迟计算的。
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[rustc_const_unstable(feature = "const_result_drop", issue = "92384")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn or<F>(self, res: Result<T, F>) -> Result<T, F>
    where
        T: ~const Destruct,
        E: ~const Destruct,
        F: ~const Destruct,
    {
        match self {
            Ok(v) => Ok(v),
            // FIXME: ~const 丢弃还不能正常工作
            #[allow(unused_variables)]
            Err(e) => res,
        }
    }

    /// 如果结果为 [`Err`]，则调用 `op`，否则返回 `self` 的 [`Ok`] 值。
    ///
    /// 该函数可用于基于结果值的控制流。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// 返回包含的 [`Ok`] 值或提供的默认值。
    ///
    /// 急切地评估传递给 `unwrap_or` 的参数； 如果要传递函数调用的结果，建议使用 [`unwrap_or_else`]，它是惰性求值的。
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[rustc_const_unstable(feature = "const_result_drop", issue = "92384")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn unwrap_or(self, default: T) -> T
    where
        T: ~const Destruct,
        E: ~const Destruct,
    {
        match self {
            Ok(t) => t,
            // FIXME: ~const 丢弃还不能正常工作
            #[allow(unused_variables)]
            Err(e) => default,
        }
    }

    /// 返回包含的 [`Ok`] 值或从闭包中计算得出。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// 返回包含 `self` 值的包含的 [`Ok`] 值，而不检查该值是否不是 [`Err`]。
    ///
    ///
    /// # Safety
    ///
    /// 在 [`Err`] 上调用此方法是 *[undefined 行为]*。
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // 未定义的行为！
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "option_result_unwrap_unchecked", since = "1.58.0")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // SAFETY: 调用者必须坚持安全保证。
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// 返回包含 `self` 值的包含的 [`Err`] 值，而不检查该值是否不是 [`Ok`]。
    ///
    ///
    /// # Safety
    ///
    /// 在 [`Ok`] 上调用此方法是 *[undefined 行为]*。
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // 未定义的行为！
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "option_result_unwrap_unchecked", since = "1.58.0")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // SAFETY: 调用者必须坚持安全保证。
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 杂项或 niche
    /////////////////////////////////////////////////////////////////////////

    /// 如果结果是包含给定值的 [`Ok`] 值，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// 如果结果是包含给定值的 [`Err`] 值，则返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }
}

impl<T, E> Result<&T, E> {
    /// 通过复制 `Ok` 部件的内容，将 `Result<&T, E>` 的 Maps 转换为 `Result<T, E>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[inline]
    #[stable(feature = "result_copied", since = "1.59.0")]
    pub fn copied(self) -> Result<T, E>
    where
        T: Copy,
    {
        self.map(|&t| t)
    }

    /// 通过克隆 `Ok` 部分的内容，将 `Result<&T, E>` Maps 转换为 `Result<T, E>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[inline]
    #[stable(feature = "result_cloned", since = "1.59.0")]
    pub fn cloned(self) -> Result<T, E>
    where
        T: Clone,
    {
        self.map(|t| t.clone())
    }
}

impl<T, E> Result<&mut T, E> {
    /// 通过复制 `Ok` 部件的内容，将 `Result<&mut T, E>` 的 Maps 转换为 `Result<T, E>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[inline]
    #[stable(feature = "result_copied", since = "1.59.0")]
    pub fn copied(self) -> Result<T, E>
    where
        T: Copy,
    {
        self.map(|&mut t| t)
    }

    /// 通过克隆 `Ok` 部分的内容，将 `Result<&mut T, E>` Maps 转换为 `Result<T, E>`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[inline]
    #[stable(feature = "result_cloned", since = "1.59.0")]
    pub fn cloned(self) -> Result<T, E>
    where
        T: Clone,
    {
        self.map(|t| t.clone())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// 将 `Option` 的 `Result` 转换为 `Result` 的 `Option`。
    ///
    /// `Ok(None)` 将映射到 `None`。
    /// `Ok(Some(_))` 和 `Err(_)` 将映射到 `Some(Ok(_))` 和 `Some(Err(_))`。
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// 从 `Result<Result<T, E>, E>` 转换为 `Result<T, E>`
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// 展平一次只能删除一层嵌套：
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

// 这是一个单独的函数，以减少方法的代码大小
#[cfg(not(feature = "panic_immediate_abort"))]
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{msg}: {error:?}")
}

// 这是一个单独的函数，以避免构建一个被立即丢弃的 `dyn Debug`，因为如果构建了一个 trait 对象，即使它没有被使用，vtables 也不会被死代码消除清除
//
//
//
#[cfg(feature = "panic_immediate_abort")]
#[inline]
#[cold]
#[track_caller]
fn unwrap_failed<T>(_msg: &str, _error: &T) -> ! {
    panic!()
}

/////////////////////////////////////////////////////////////////////////////
// trait 实现
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_clone", issue = "91805")]
impl<T, E> const Clone for Result<T, E>
where
    T: ~const Clone + ~const Destruct,
    E: ~const Clone + ~const Destruct,
{
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// 返回可能包含的值上的消耗迭代器。
    ///
    /// 如果结果为 [`Result::Ok`]，则迭代器将产生一个值，否则将不产生任何值。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// 结果迭代器
/////////////////////////////////////////////////////////////////////////////

/// [`Result`] 的 [`Ok`] 变体的引用上的迭代器。
///
/// 如果结果为 [`Ok`]，则迭代器将产生一个值，否则将不产生任何值。
///
/// 由 [`Result::iter`] 创建。
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] 的 [`Ok`] 变体的可变引用上的迭代器。
///
/// 由 [`Result::iter_mut`] 创建。
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`] 的 [`Ok`] 变体中的值的迭代器。
///
/// 如果结果为 [`Ok`]，则迭代器将产生一个值，否则将不产生任何值。
///
/// 该结构体是通过 [`Result`] (由 [`IntoIterator`] trait 提供) 上的 [`into_iter`] 方法创建的。
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// 接受 `Iterator` 中的每个元素：如果它是 `Err`，则不再获取其他元素，并返回 `Err`。
    /// 如果没有发生 `Err`，则返回包含每个 `Result` 值的容器。
    ///
    /// 这是一个示例，该示例将递增 vector 中的的每个整数，并检查溢出：
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// 这是另一个示例，尝试从另一个整数列表中减去一个，这次检查下溢：
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// 这是前一个示例的变体，显示在第一个 `Err` 之后不再从 `iter` 提取其他元素。
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// 由于第三个元素引起下溢，因此不再使用其他元素，因此 `shared` 的最终值为 6 (= `3 + 2 + 1`)，而不是 16。
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        iter::try_process(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait_v2", issue = "84277")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T, E> const ops::Try for Result<T, E> {
    type Output = T;
    type Residual = Result<convert::Infallible, E>;

    #[inline]
    fn from_output(output: Self::Output) -> Self {
        Ok(output)
    }

    #[inline]
    fn branch(self) -> ControlFlow<Self::Residual, Self::Output> {
        match self {
            Ok(v) => ControlFlow::Continue(v),
            Err(e) => ControlFlow::Break(Err(e)),
        }
    }
}

#[unstable(feature = "try_trait_v2", issue = "84277")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T, E, F: ~const From<E>> const ops::FromResidual<Result<convert::Infallible, E>>
    for Result<T, F>
{
    #[inline]
    #[track_caller]
    fn from_residual(residual: Result<convert::Infallible, E>) -> Self {
        match residual {
            Err(e) => Err(From::from(e)),
        }
    }
}

#[unstable(feature = "try_trait_v2_yeet", issue = "96374")]
impl<T, E, F: From<E>> ops::FromResidual<ops::Yeet<E>> for Result<T, F> {
    #[inline]
    fn from_residual(ops::Yeet(e): ops::Yeet<E>) -> Self {
        Err(From::from(e))
    }
}

#[unstable(feature = "try_trait_v2_residual", issue = "91285")]
#[rustc_const_unstable(feature = "const_try", issue = "74935")]
impl<T, E> const ops::Residual<T> for Result<convert::Infallible, E> {
    type TryType = Result<T, E>;
}
