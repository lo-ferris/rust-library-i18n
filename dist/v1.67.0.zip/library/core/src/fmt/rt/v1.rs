//! 这是 ifmt 使用的内部模块！ 运行时。这些结构会被发送到静态数组，以提前对格式字符串进行预编译。
//!
//! 这些定义与它们的 `ct` 等效项相似，但不同之处在于它们可以静态分配，并针对运行时进行了略微优化。
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// 可以作为格式设置指令的一部分请求的可能的对齐方式。
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// 指示内容应左对齐。
    Left,
    /// 指示内容应右对齐。
    Right,
    /// 指示内容应居中对齐。
    Center,
    /// 没有要求对齐。
    Unknown,
}

/// 由 [width](https://doc.rust-lang.org/std/fmt/#width) 和 [precision](https://doc.rust-lang.org/std/fmt/#precision) 说明符使用。
#[derive(Copy, Clone)]
pub enum Count {
    /// 用字面量数字指定，存储该值
    Is(usize),
    /// 使用 `$` 和 `*` 语法指定，将索引存储到 `args`
    Param(usize),
    /// 未标明
    Implied,
}
