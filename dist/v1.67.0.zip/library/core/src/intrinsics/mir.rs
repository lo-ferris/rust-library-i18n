//! Rustc 用于手写 MIR 的内部工具。
//!
//! 如果由于某些原因您没有编写 rustc 测试，并且发现自己正在考虑使用此特性，那么请返回。
//! 这是*非常*不稳定的。
//! 除了 rustc 测试套件恰好需要的那些东西之外，根本没有尝试使任何东西工作。
//! 如果您打错字，您可能会 ICE。
//! 真的，这不是解决您问题的方法。
//! 考虑改为支持 [稳定的 MIR 项目组](https://github.com/rust-lang/project-stable-mir)。
//!
//! 此模块的文档描述了如何使用此特性。
//! 如果您有兴趣破解实现，大部分文档都位于 `rustc_mir_building/src/build/custom/mod.rs`。
//!
//!
//! 典型用法如下所示:
//!
//! ```rust
//! #![feature(core_intrinsics, custom_mir)]
//!
//! extern crate core;
//! use core::intrinsics::mir::*;
//!
//! #[custom_mir(dialect = "built")]
//! pub fn simple(x: i32) -> i32 {
//!     mir!(
//!         let temp1: i32;
//!         let temp2: _;
//!
//!         {
//!             temp1 = x;
//!             Goto(exit)
//!         }
//!
//!         exit = {
//!             temp2 = Move(temp1);
//!             RET = temp2;
//!             Return()
//!         }
//!     )
//! }
//! ```
//!
//! 希望其中大部分是不言自明的。扩展一些值得注意的细节:
//!
//!  - `custom_mir` 属性告诉编译器将函数视为自定义 MIR。
//!  此属性仅适用于函数 - 无法将自定义 MIR 插入另一个函数的中间。
//!  - `dialect` 和 `phase` 参数指示您在此处插入的 MIR 版本。
//!    这通常是与您要测试的事物相对应的阶段。
//!    对于只有一个的方言，可以省略相位。
//!  - 您应该像往常一样定义您的函数签名。在外部，这个函数可以像任何其他函数一样被调用。
//!  - 类型推断有效 - 您不必拼出所有当地人的类型。
//!
//! 现在，所有的语句和终止符都是从这个模块中提供的特殊函数的嵌套调用中解析出来的。
//! 我们还希望 (但还没有) 在有意义的地方支持更多的 "normal" Rust 语法。
//! 此外，目前还不支持大多数类型的指令。
//!
//!
//!

#![unstable(
    feature = "custom_mir",
    reason = "MIR is an implementation detail and extremely unstable",
    issue = "none"
)]
#![allow(unused_variables, non_snake_case, missing_debug_implementations)]

/// 表示基本块的类型。
///
/// 所有终止符都将此类型作为返回类型。它有助于实现某种类型的安全性。
pub struct BasicBlock;

macro_rules! define {
    ($name:literal, $($sig:tt)*) => {
        #[rustc_diagnostic_item = $name]
        pub $($sig)* { panic!() }
    }
}

define!("mir_return", fn Return() -> BasicBlock);
define!("mir_goto", fn Goto(destination: BasicBlock) -> BasicBlock);
define!("mir_retag", fn Retag<T>(place: T));
define!("mir_retag_raw", fn RetagRaw<T>(place: T));
define!("mir_move", fn Move<T>(place: T) -> T);
define!("mir_static", fn Static<T>(s: T) -> &'static T);
define!("mir_static_mut", fn StaticMut<T>(s: T) -> *mut T);

/// 方便宏生成自定义 MIR。
///
/// 有关语法详细信息，请参见模块文档。
/// 这个宏并不神奇 -- 它只是将您的 MIR 转换成更容易在编译器中解析的东西。
#[rustc_macro_transparency = "transparent"]
pub macro mir {
    (
        $(let $local_decl:ident $(: $local_decl_ty:ty)? ;)*

        {
            $($entry:tt)*
        }

        $(
            $block_name:ident = {
                $($block:tt)*
            }
        )*
    ) => {{
        // 首先，我们声明所有基本块。
        $(
            let $block_name: ::core::intrinsics::mir::BasicBlock;
        )*

        {
            // 现在都是局部的
            #[allow(non_snake_case)]
            let RET;
            $(
                let $local_decl $(: $local_decl_ty)? ;
            )*

            ::core::intrinsics::mir::__internal_extract_let!($($entry)*);
            $(
                ::core::intrinsics::mir::__internal_extract_let!($($block)*);
            )*

            {
                // 最后是基本块的内容
                ::core::intrinsics::mir::__internal_remove_let!({
                    {}
                    { $($entry)* }
                });
                $(
                    ::core::intrinsics::mir::__internal_remove_let!({
                        {}
                        { $($block)* }
                    });
                )*

                RET
            }
        }
    }}
}

/// 从一堆语言中提取 `let` 声明的助手宏。
///
/// 这个宏是用 "statement muncher" 策略写的。
/// 每次调用都会从输入中解析出第一条语句，对其执行适当的操作，然后对输入的其余部分递归调用相同的宏。
///
#[doc(hidden)]
pub macro __internal_extract_let {
    // 如果是类似 `let` 的语句，则保留 `let`
    (
        let $var:ident $(: $ty:ty)? = $expr:expr; $($rest:tt)*
    ) => {
        let $var $(: $ty)?;
        ::core::intrinsics::mir::__internal_extract_let!($($rest)*);
    },
    // 由于 #86730，我们必须单独处理 const 块
    (
        let $var:ident $(: $ty:ty)? = const $block:block; $($rest:tt)*
    ) => {
        let $var $(: $ty)?;
        ::core::intrinsics::mir::__internal_extract_let!($($rest)*);
    },
    // 否则什么都不输出
    (
        $stmt:stmt; $($rest:tt)*
    ) => {
        ::core::intrinsics::mir::__internal_extract_let!($($rest)*);
    },
    (
        $expr:expr
    ) => {}
}

/// 从一堆语言中删除 `let` 声明的助手宏。
/// 因为表达式位置宏不能展开成语句 + 表达式，这里需要稍微有点创意。一般的策略也是像上面一样的语句咀嚼，但是在随后的宏调用中宏的输出是 "stored"。通过示例最容易理解:
///
/// ```text
/// invoke!(
///     {
///         {
///             x = 5;
///         }
///         {
///             let d = e;
///             Call()
///         }
///     }
/// )
/// ```
///
/// becomes
///
/// ```text
/// invoke!(
///     {
///         {
///             x = 5;
///             d = e;
///         }
///         {
///             Call()
///         }
///     }
/// )
/// ```
#[doc(hidden)]
pub macro __internal_remove_let {
    // 如果是类似 `let` 的语句，去掉 `let`
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                let $var:ident $(: $ty:ty)? = $expr:expr;
                $($rest:tt)*
            }
        }
    ) => { ::core::intrinsics::mir::__internal_remove_let!(
        {
            {
                $($already_parsed)*
                $var = $expr;
            }
            {
                $($rest)*
            }
        }
    )},
    // 由于 #86730，我们必须单独处理 const 块
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                let $var:ident $(: $ty:ty)? = const $block:block;
                $($rest:tt)*
            }
        }
    ) => { ::core::intrinsics::mir::__internal_remove_let!(
        {
            {
                $($already_parsed)*
                $var = const $block;
            }
            {
                $($rest)*
            }
        }
    )},
    // 否则，继续
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                $stmt:stmt;
                $($rest:tt)*
            }
        }
    ) => { ::core::intrinsics::mir::__internal_remove_let!(
        {
            {
                $($already_parsed)*
                $stmt;
            }
            {
                $($rest)*
            }
        }
    )},
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                $expr:expr
            }
        }
    ) => {
        {
            $($already_parsed)*
            $expr
        }
    },
}
