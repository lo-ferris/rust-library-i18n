use crate::marker::Destruct;
#[cfg(not(bootstrap))]
use crate::marker::Tuple;

/// 结构体表示具有可变借用数据的闭包。
///
/// Example:
/// ```no_build
/// #![feature(const_mut_refs)]
/// use crate::const_closure::ConstFnMutClosure;
/// const fn imp(state: &mut i32, (arg,): (i32,)) -> i32 {
///   *state += arg;
///   *state
/// }
/// let mut i = 5;
/// let mut cl = ConstFnMutClosure::new(&mut i, imp);
///
/// assert!(7 == cl(2));
/// assert!(8 == cl(1));
/// ```
pub(crate) struct ConstFnMutClosure<CapturedData, Function> {
    /// 闭包捕获的数据。
    /// 必须是 (mutable) 引用或 (mutable) 引用的元组。
    pub data: CapturedData,
    /// 闭包的函数，必须是: Fn(CapturedData, ClosureArgs) -> ClosureReturn
    pub func: Function,
}
impl<'a, CapturedData: ?Sized, Function> ConstFnMutClosure<&'a mut CapturedData, Function> {
    /// 用于创建新闭包的函数。
    ///
    /// `data` 是从环境中捕获的数据的一种错误借用。
    /// 如果要 Data 的元组不借用，则必须手动构建结构体。
    ///
    /// `func` 是闭包函数，它获取参数闭包的数据和一个元组，并返回闭包的返回值。
    ///
    pub(crate) const fn new<ClosureArguments, ClosureReturnValue>(
        data: &'a mut CapturedData,
        func: Function,
    ) -> Self
    where
        Function: ~const Fn(&mut CapturedData, ClosureArguments) -> ClosureReturnValue,
    {
        Self { data, func }
    }
}

macro_rules! impl_fn_mut_tuple {
    ($($var:ident)*) => {
        #[cfg(bootstrap)]
        #[allow(unused_parens)]
        impl<'a, $($var,)* ClosureArguments, Function, ClosureReturnValue> const
            FnOnce<ClosureArguments> for ConstFnMutClosure<($(&'a mut $var),*), Function>
        where
            Function: ~const Fn(($(&mut $var),*), ClosureArguments) -> ClosureReturnValue+ ~const Destruct,
        {
            type Output = ClosureReturnValue;

            extern "rust-call" fn call_once(mut self, args: ClosureArguments) -> Self::Output {
            self.call_mut(args)
            }
        }
        #[cfg(bootstrap)]
        #[allow(unused_parens)]
        impl<'a, $($var,)* ClosureArguments, Function, ClosureReturnValue> const
            FnMut<ClosureArguments> for ConstFnMutClosure<($(&'a mut $var),*), Function>
        where
            Function: ~const Fn(($(&mut $var),*), ClosureArguments)-> ClosureReturnValue,
        {
            extern "rust-call" fn call_mut(&mut self, args: ClosureArguments) -> Self::Output {
                #[allow(non_snake_case)]
                let ($($var),*) = &mut self.data;
                (self.func)(($($var),*), args)
            }
        }
        #[cfg(not(bootstrap))]
        #[allow(unused_parens)]
        impl<'a, $($var,)* ClosureArguments: Tuple, Function, ClosureReturnValue> const
            FnOnce<ClosureArguments> for ConstFnMutClosure<($(&'a mut $var),*), Function>
        where
            Function: ~const Fn(($(&mut $var),*), ClosureArguments) -> ClosureReturnValue+ ~const Destruct,
        {
            type Output = ClosureReturnValue;

            extern "rust-call" fn call_once(mut self, args: ClosureArguments) -> Self::Output {
            self.call_mut(args)
            }
        }
        #[cfg(not(bootstrap))]
        #[allow(unused_parens)]
        impl<'a, $($var,)* ClosureArguments: Tuple, Function, ClosureReturnValue> const
            FnMut<ClosureArguments> for ConstFnMutClosure<($(&'a mut $var),*), Function>
        where
            Function: ~const Fn(($(&mut $var),*), ClosureArguments)-> ClosureReturnValue,
        {
            extern "rust-call" fn call_mut(&mut self, args: ClosureArguments) -> Self::Output {
                #[allow(non_snake_case)]
                let ($($var),*) = &mut self.data;
                (self.func)(($($var),*), args)
            }
        }
    };
}
impl_fn_mut_tuple!(A);
impl_fn_mut_tuple!(A B);
impl_fn_mut_tuple!(A B C);
impl_fn_mut_tuple!(A B C D);
impl_fn_mut_tuple!(A B C D E);
