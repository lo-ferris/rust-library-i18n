//! Rustc internal tooling for hand-writing MIR. <br>Rustc 用于手写 MIR 的内部工具。<br>
//!
//! If for some reasons you are not writing rustc tests and have found yourself considering using this feature, turn back. <br>如果由于某些原因您没有编写 rustc 测试，并且发现自己正在考虑使用此特性，那么请返回。<br>
//! This is *exceptionally* unstable. <br>这是*非常*不稳定的。<br>
//! There is no attempt at all to make anything work besides those things which the rustc test suite happened to need. <br>除了 rustc 测试套件恰好需要的那些东西之外，根本没有尝试使任何东西工作。<br>
//! If you make a typo you'll probably ICE. <br>如果您打错字，您可能会 ICE。<br>
//! Really, this is not the solution to your problems. <br>真的，这不是解决您问题的方法。<br>
//! Consider instead supporting the [stable MIR project group](https://github.com/rust-lang/project-stable-mir). <br>考虑改为支持 [稳定的 MIR 项目组](https://github.com/rust-lang/project-stable-mir)。<br>
//!
//! The documentation for this module describes how to use this feature. <br>此模块的文档描述了如何使用此特性。<br>
//! If you are interested in hacking on the implementation, most of that documentation lives at `rustc_mir_building/src/build/custom/mod.rs`. <br>如果您有兴趣破解实现，大部分文档都位于 `rustc_mir_building/src/build/custom/mod.rs`。<br>
//!
//!
//! Typical usage will look like this: <br>典型用法如下所示:<br>
//!
//! ```rust
//! #![feature(core_intrinsics, custom_mir)]
//!
//! extern crate core;
//! use core::intrinsics::mir::*;
//!
//! #[custom_mir(dialect = "built")]
//! pub fn simple(x: i32) -> i32 {
//!     mir!(
//!         let temp1: i32;
//!         let temp2: _;
//!
//!         {
//!             temp1 = x;
//!             Goto(exit)
//!         }
//!
//!         exit = {
//!             temp2 = Move(temp1);
//!             RET = temp2;
//!             Return()
//!         }
//!     )
//! }
//! ```
//!
//! Hopefully most of this is fairly self-explanatory. <br>希望其中大部分是不言自明的。<br> Expanding on some notable details: <br>扩展一些值得注意的细节:<br>
//!
//!  - The `custom_mir` attribute tells the compiler to treat the function as being custom MIR. <br>`custom_mir` 属性告诉编译器将函数视为自定义 MIR。<br>
//!  This attribute only works on functions - there is no way to insert custom MIR into the middle of another function. <br>此属性仅适用于函数 - 无法将自定义 MIR 插入另一个函数的中间。<br>
//!  - The `dialect` and `phase` parameters indicate which version of MIR you are inserting here. <br>`dialect` 和 `phase` 参数指示您在此处插入的 MIR 版本。<br>
//!    This will normally be the phase that corresponds to the thing you are trying to test. <br>这通常是与您要测试的事物相对应的阶段。<br>
//!    The phase can be omitted for dialects that have just one. <br>对于只有一个的方言，可以省略相位。<br>
//!  - You should define your function signature like you normally would. <br>您应该像往常一样定义您的函数签名。<br> Externally, this function can be called like any other function. <br>在外部，这个函数可以像任何其他函数一样被调用。<br>
//!  - Type inference works - you don't have to spell out the type of all of your locals. <br>类型推断有效 - 您不必拼出所有当地人的类型。<br>
//!
//! For now, all statements and terminators are parsed from nested invocations of the special functions provided in this module. <br>现在，所有的语句和终止符都是从这个模块中提供的特殊函数的嵌套调用中解析出来的。<br>
//! We additionally want to (but do not yet) support more "normal" Rust syntax in places where it makes sense. <br>我们还希望 (但还没有) 在有意义的地方支持更多的 "normal" Rust 语法。<br>
//! Also, most kinds of instructions are not supported yet. <br>此外，目前还不支持大多数类型的指令。<br>
//!
//!
//!

#![unstable(
    feature = "custom_mir",
    reason = "MIR is an implementation detail and extremely unstable",
    issue = "none"
)]
#![allow(unused_variables, non_snake_case, missing_debug_implementations)]

/// Type representing basic blocks. <br>表示基本块的类型。<br>
///
/// All terminators will have this type as a return type. <br>所有终止符都将此类型作为返回类型。<br> It helps achieve some type safety. <br>它有助于实现某种类型的安全性。<br>
pub struct BasicBlock;

macro_rules! define {
    ($name:literal, $($sig:tt)*) => {
        #[rustc_diagnostic_item = $name]
        pub $($sig)* { panic!() }
    }
}

define!("mir_return", fn Return() -> BasicBlock);
define!("mir_goto", fn Goto(destination: BasicBlock) -> BasicBlock);
define!("mir_retag", fn Retag<T>(place: T));
define!("mir_retag_raw", fn RetagRaw<T>(place: T));
define!("mir_move", fn Move<T>(place: T) -> T);
define!("mir_static", fn Static<T>(s: T) -> &'static T);
define!("mir_static_mut", fn StaticMut<T>(s: T) -> *mut T);

/// Convenience macro for generating custom MIR. <br>方便宏生成自定义 MIR。<br>
///
/// See the module documentation for syntax details. <br>有关语法详细信息，请参见模块文档。<br>
/// This macro is not magic - it only transforms your MIR into something that is easier to parse in the compiler. <br>这个宏并不神奇 -- 它只是将您的 MIR 转换成更容易在编译器中解析的东西。<br>
#[rustc_macro_transparency = "transparent"]
pub macro mir {
    (
        $(let $local_decl:ident $(: $local_decl_ty:ty)? ;)*

        {
            $($entry:tt)*
        }

        $(
            $block_name:ident = {
                $($block:tt)*
            }
        )*
    ) => {{
        // First, we declare all basic blocks. <br>首先，我们声明所有基本块。<br>
        $(
            let $block_name: ::core::intrinsics::mir::BasicBlock;
        )*

        {
            // Now all locals <br>现在都是局部的<br>
            #[allow(non_snake_case)]
            let RET;
            $(
                let $local_decl $(: $local_decl_ty)? ;
            )*

            ::core::intrinsics::mir::__internal_extract_let!($($entry)*);
            $(
                ::core::intrinsics::mir::__internal_extract_let!($($block)*);
            )*

            {
                // Finally, the contents of the basic blocks <br>最后是基本块的内容<br>
                ::core::intrinsics::mir::__internal_remove_let!({
                    {}
                    { $($entry)* }
                });
                $(
                    ::core::intrinsics::mir::__internal_remove_let!({
                        {}
                        { $($block)* }
                    });
                )*

                RET
            }
        }
    }}
}

/// Helper macro that extracts the `let` declarations out of a bunch of statements. <br>从一堆语言中提取 `let` 声明的助手宏。<br>
///
/// This macro is written using the "statement muncher" strategy. <br>这个宏是用 "statement muncher" 策略写的。<br>
/// Each invocation parses the first statement out of the input, does the appropriate thing with it, and then recursively calls the same macro on the remainder of the input. <br>每次调用都会从输入中解析出第一条语句，对其执行适当的操作，然后对输入的其余部分递归调用相同的宏。<br>
///
#[doc(hidden)]
pub macro __internal_extract_let {
    // If it's a `let` like statement, keep the `let` <br>如果是类似 `let` 的语句，则保留 `let`<br>
    (
        let $var:ident $(: $ty:ty)? = $expr:expr; $($rest:tt)*
    ) => {
        let $var $(: $ty)?;
        ::core::intrinsics::mir::__internal_extract_let!($($rest)*);
    },
    // Due to #86730, we have to handle const blocks separately <br>由于 #86730，我们必须单独处理 const 块<br>
    (
        let $var:ident $(: $ty:ty)? = const $block:block; $($rest:tt)*
    ) => {
        let $var $(: $ty)?;
        ::core::intrinsics::mir::__internal_extract_let!($($rest)*);
    },
    // Otherwise, output nothing <br>否则什么都不输出<br>
    (
        $stmt:stmt; $($rest:tt)*
    ) => {
        ::core::intrinsics::mir::__internal_extract_let!($($rest)*);
    },
    (
        $expr:expr
    ) => {}
}

/// Helper macro that removes the `let` declarations from a bunch of statements. <br>从一堆语言中删除 `let` 声明的助手宏。<br>
/// Because expression position macros cannot expand to statements + expressions, we need to be slightly creative here. <br>因为表达式位置宏不能展开成语句 + 表达式，这里需要稍微有点创意。<br> The general strategy is also statement munching as above, but the output of the macro is "stored" in the subsequent macro invocation. <br>一般的策略也是像上面一样的语句咀嚼，但是在随后的宏调用中宏的输出是 "stored"。<br> Easiest understood via example: <br>通过示例最容易理解:<br>
///
/// ```text
/// invoke!(
///     {
///         {
///             x = 5;
///         }
///         {
///             let d = e;
///             Call()
///         }
///     }
/// )
/// ```
///
/// becomes
///
/// ```text
/// invoke!(
///     {
///         {
///             x = 5;
///             d = e;
///         }
///         {
///             Call()
///         }
///     }
/// )
/// ```
#[doc(hidden)]
pub macro __internal_remove_let {
    // If it's a `let` like statement, remove the `let` <br>如果是类似 `let` 的语句，去掉 `let`<br>
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                let $var:ident $(: $ty:ty)? = $expr:expr;
                $($rest:tt)*
            }
        }
    ) => { ::core::intrinsics::mir::__internal_remove_let!(
        {
            {
                $($already_parsed)*
                $var = $expr;
            }
            {
                $($rest)*
            }
        }
    )},
    // Due to #86730 , we have to handle const blocks separately <br>由于 #86730，我们必须单独处理 const 块<br>
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                let $var:ident $(: $ty:ty)? = const $block:block;
                $($rest:tt)*
            }
        }
    ) => { ::core::intrinsics::mir::__internal_remove_let!(
        {
            {
                $($already_parsed)*
                $var = const $block;
            }
            {
                $($rest)*
            }
        }
    )},
    // Otherwise, keep going <br>否则，继续<br>
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                $stmt:stmt;
                $($rest:tt)*
            }
        }
    ) => { ::core::intrinsics::mir::__internal_remove_let!(
        {
            {
                $($already_parsed)*
                $stmt;
            }
            {
                $($rest)*
            }
        }
    )},
    (
        {
            {
                $($already_parsed:tt)*
            }
            {
                $expr:expr
            }
        }
    ) => {
        {
            $($already_parsed)*
            $expr
        }
    },
}
