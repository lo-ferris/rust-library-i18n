use crate::cmp;
use crate::mem::{self, MaybeUninit, SizedTypeProperties};
use crate::ptr;

/// Rotates the range `[mid-left, mid+right)` such that the element at `mid` becomes the first element. <br>旋转范围 `[mid-left, mid+right)`，以使 `mid` 处的元素成为第一个元素。<br> Equivalently, rotates the range `left` elements to the left or `right` elements to the right. <br>等效地，将范围 `left` 元素向左旋转或将 `right` 元素向右旋转。<br>
///
/// # Safety
///
/// The specified range must be valid for reading and writing. <br>指定的范围必须对读写有效。<br>
///
/// # Algorithm
///
/// Algorithm 1 is used for small values of `left + right` or for large `T`. <br>算法 1 用于较小的 `left + right` 或较大的 `T`。<br>
/// The elements are moved into their final positions one at a time starting at `mid - left` and advancing by `right` steps modulo `left + right`, such that only one temporary is needed. <br>元素从 `mid - left` 开始一次移动到它们的最终位置，并以 `left + right` 为模以 `right` 步长前进，因此只需要一个临时位置。<br>
/// Eventually, we arrive back at `mid - left`. <br>最终，我们回到 `mid - left`。<br>
/// However, if `gcd(left + right, right)` is not 1, the above steps skipped over elements. <br>但是，如果 `gcd(left + right, right)` 不为 1，则上述步骤将跳过元素。<br>
/// For example: <br>例如：<br>
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Fortunately, the number of skipped over elements between finalized elements is always equal, so we can just offset our starting position and do more rounds (the total number of rounds is the `gcd(left + right, right)` value). <br>幸运的是，最终元素之间被跳过的元素的数量始终相等，因此我们可以偏移起始位置并进行更多的回合 (总回合数为 `gcd(left + right, right)` 值)。<br>
///
/// The end result is that all elements are finalized once and only once. <br>最终结果是所有元素只能一次完成。<br>
///
/// Algorithm 2 is used if `left + right` is large but `min(left, right)` is small enough to fit onto a stack buffer. <br>如果 `left + right` 大但 `min(left, right)` 小到足以适合栈缓冲区，则使用算法 2。<br>
/// The `min(left, right)` elements are copied onto the buffer, `memmove` is applied to the others, and the ones on the buffer are moved back into the hole on the opposite side of where they originated. <br>将 `min(left, right)` 元素复制到缓冲区，将 `memmove` 应用于其他元素，然后将缓冲区中的元素移回它们起源的另一侧的 hole 中。<br>
///
/// Algorithms that can be vectorized outperform the above once `left + right` becomes large enough. <br>一旦 `left + right` 变得足够大，可以向量化的算法就会胜过上面的算法。<br>
/// Algorithm 1 can be vectorized by chunking and performing many rounds at once, but there are too few rounds on average until `left + right` is enormous, and the worst case of a single round is always there. <br>可以通过分块并一次执行多个回合来对算法 1 进行矢量化，但是在 `left + right` 变得巨大之前，平均回合数量太少，而且单回合的最坏情况始终存在。<br>
/// Instead, algorithm 3 utilizes repeated swapping of `min(left, right)` elements until a smaller rotate problem is left. <br>相反，算法 3 利用 `min(left, right)` 元素的重复交换，直到剩下较小的旋转问题为止。<br>
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// when `left < right` the swapping happens from the left instead. <br>`left < right` 时，交换发生在左侧。<br>
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if T::IS_ZST {
        return;
    }
    loop {
        // N.B. the below algorithms can fail if these cases are not checked <br>注意，如果不检查这些情况，以下算法可能会失败<br>
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks indicate that the average performance for random shifts is better all the way until about `left + right == 32`, but the worst case performance breaks even around 16. <br>算法 1 的微基准测试表明，直到 `left + right == 32` 左右，随机移位的平均性能一直都比较好，但是最坏的情况甚至会达到 16。<br>
            // 24 was chosen as middle ground. <br>24 被选为中间立场。<br>
            // If the size of `T` is larger than 4 `usize`s, this algorithm also outperforms other algorithms. <br>如果 `T` 的大小大于 4 个 `usize`，则该算法也将优于其他算法。<br>
            // SAFETY: callers must ensure `mid - left` is valid for reading and writing. <br>调用者必须确保 `mid - left` 对读写有效。<br>
            //
            //
            let x = unsafe { mid.sub(left) };
            // beginning of first round <br>第一轮开始<br>
            // SAFETY: see previous comment. <br>参见上一个注释。<br>
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` can be found before hand by calculating `gcd(left + right, right)`, but it is faster to do one loop which calculates the gcd as a side effect, then doing the rest of the chunk <br>`gcd` 可以通过计算 `gcd(left + right, right)` 预先找到，但执行一个循环会更快，将 gcd 作为副作用计算，然后执行块的其余部分<br>
            //
            //
            let mut gcd = right;
            // benchmarks reveal that it is faster to swap temporaries all the way through instead of reading one temporary once, copying backwards, and then writing that temporary at the very end. <br>基准测试表明，与一遍交换临时文件相比，一次读取一个临时文件，向后复制，然后在最后写入该临时文件要快得多。<br>
            // This is possibly due to the fact that swapping or replacing temporaries uses only one memory address in the loop instead of needing to manage two. <br>这可能是由于以下事实：交换或替换临时节点在循环中仅使用一个内存地址，而不需要管理两个。<br>
            //
            //
            loop {
                // [long-safety-expl]
                // SAFETY: callers must ensure `[left, left+mid+right)` are all valid for reading and writing. <br>调用者必须确保 `[left, left+mid+right)` 对读取和写入都是有效的。<br>
                //
                // - `i` start with `right` so `mid-left <= x+i = x+right = mid-left+right < mid+right` <br>`i` 以 `right` 开头所以 `mid-left <= x+i = x+right = mid-left+right < mid+right`<br>
                // - `i <= left+right-1` is always true <br>`i <= left+right-1` 始终为 true<br>
                //   - if `i < left`, `right` is added so `i < left+right` and on the next iteration `left` is removed from `i` so it doesn't go further <br>如果 `i < left`，`right` 被添加，所以 `i < left+right` 和在下一次迭代中 `left` 从 `i` 中删除，所以它不会更进一步<br>
                //
                //   - if `i >= left`, `left` is removed immediately and so it doesn't go further. <br>如果 `i >= left`，`left` 立即被删除，所以它不会更进一步。<br>
                // - overflows cannot happen for `i` since the function's safety contract ask for `mid+right-1 = x+left+right` to be valid for writing <br>`i` 不会发生溢出，因为函数的安全保证要求 `mid+right-1 = x+left+right` 对写入有效<br>
                // - underflows cannot happen because `i` must be bigger or equal to `left` for a subtraction of `left` to happen. <br>不能发生下溢，因为 `i` 必须大于或等于 `left`，才能发生 `left` 的减法。<br>
                //
                // So `x+i` is valid for reading and writing if the caller respected the contract <br>因此，如果调用者遵守契约，则 `x+i` 对读和写是有效的<br>
                //
                //
                //
                tmp = unsafe { x.add(i).replace(tmp) };
                // instead of incrementing `i` and then checking if it is outside the bounds, we check if `i` will go outside the bounds on the next increment. <br>而不是递增 `i`，然后检查它是否在范围之内，我们检查 `i` 是否在下一次递增时越界。<br>
                // This prevents any wrapping of pointers or `usize`. <br>这样可以防止指针或 `usize` 的任何换行。<br>
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // end of first round <br>第一轮结束<br>
                        // SAFETY: tmp has been read from a valid source and x is valid for writing according to the caller. <br>tmp 已从有效来源读取，并且 x 可根据调用者的情况进行写入。<br>
                        //
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // this conditional must be here if `left + right >= 15` <br>如果 `left + right >= 15`，则此条件必须在此处<br>
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // finish the chunk with more rounds <br>用更多的回合完成大块<br>
            for start in 1..gcd {
                // SAFETY: `gcd` is at most equal to `right` so all values in `1..gcd` are valid for reading and writing as per the function's safety contract, see [long-safety-expl] above <br>`gcd` 至多等于 `right`，因此 `1..gcd` 中的所有值都可以根据函数的安全保证进行读写，参见上面的 [long-safety-expl]<br>
                //
                //
                tmp = unsafe { x.add(start).read() };
                // [safety-expl-addition]
                //
                // Here `start < gcd` so `start < right` so `i < right+right`: `right` being the greatest common divisor of `(left+right, right)` means that `left = right` so `i < left+right` so `x+i = mid-left+i` is always valid for reading and writing according to the function's safety contract. <br>这里 `start < gcd` so `start < right` so `i < right+right`: `right` 是 `(left+right, right)` 的最大公约数意味着 `left = right` so `i < left+right` so `x+i = mid-left+i` 根据函数的安全保证对于读写总是有效的。<br>
                //
                //
                //
                i = start + right;
                loop {
                    // SAFETY: see [long-safety-expl] and [safety-expl-addition] <br>请参见 [long-safety-expl] 和 [safety-expl-addition]<br>
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            // SAFETY: see [long-safety-expl] and [safety-expl-addition] <br>请参见 [long-safety-expl] 和 [safety-expl-addition]<br>
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` is not a zero-sized type, so it's okay to divide by its size. <br>`T` 不是零大小类型，所以除以它的大小是可以的。<br>
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 The `[T; 0]` here is to ensure this is appropriately aligned for T <br>算法 2 这里的 `[T; 0]` 是为了确保它与 T 正确对齐<br>
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            // SAFETY: `mid-left <= mid-left+right < mid+right`
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                // SAFETY:
                //
                // 1) The `else if` condition about the sizes ensures `[mid-left; left]` will fit in `buf` without overflow and `buf` was created just above and so cannot be overlapped with any value of `[mid-left; left]` <br>关于大小的 `else if` 条件确保 `[mid-left; left]` 将适合 `buf` 而不会溢出，而 `buf` 是在上面创建的，因此不能与 `[mid-left; left]` 的任何值重叠<br>
                //
                // 2) [mid-left, mid+right) are all valid for reading and writing and we don't care about overlaps here. <br>[mid-left, mid+right) 都适用于读取和写入，我们不关心这里的重叠。<br>
                // 3) The `if` condition about `left <= right` ensures writing `left` elements to `dim = mid-left+right` is valid because: <br>关于 `left <= right` 的 `if` 条件确保将 `left` 元素写入 `dim = mid-left+right` 是有效的，因为：<br>
                //    - `buf` is valid and `left` elements were written in it in 1) <br>`buf` 有效且 `left` 元素写入其中 1)<br>
                //    - `dim+left = mid-left+right+left = mid+right` and we write `[dim, dim+left)` <br>`dim+left = mid-left+right+left = mid+right` 我们写 `[dim, dim+left)`<br>
                //
                //
                //
                unsafe {
                    // 1)
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    // 2)
                    ptr::copy(mid, mid.sub(left), right);
                    // 3)
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                // SAFETY: same reasoning as above but with `left` and `right` reversed <br>与上述相同的推理，但 `left` 和 `right` 颠倒了<br>
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 There is an alternate way of swapping that involves finding where the last swap of this algorithm would be, and swapping using that last chunk instead of swapping adjacent chunks like this algorithm is doing, but this way is still faster. <br>算法 3 有另一种交换方式，该方式涉及找到该算法的最后交换位置，然后使用该最后一个块进行交换，而不是像该算法那样交换相邻的块，但是这种方式仍然更快。<br>
            //
            //
            //
            loop {
                // SAFETY:
                // `left >= right` so `[mid-right, mid+right)` is valid for reading and writing Subtracting `right` from `mid` each turn is counterbalanced by the addition and check after it. <br>`left >= right` 所以 `[mid-right, mid+right)` 对读写有效从 `mid` 中减去 `right` 每圈被加法抵消并在它之后检查。<br>
                //
                //
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right` <br>算法 3，`left < right`<br>
            loop {
                // SAFETY: `[mid-left, mid+left)` is valid for reading and writing because `left < right` so `mid+left < mid+right`. <br>`[mid-left, mid+left)` 对读写有效，因为 `left < right` 所以 `mid+left < mid+right`。<br>
                //
                // Adding `left` to `mid` each turn is counterbalanced by the subtraction and check after it. <br>将 `left` 添加到 `mid` 每一圈都会被减法及其后的检查抵消。<br>
                //
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}
