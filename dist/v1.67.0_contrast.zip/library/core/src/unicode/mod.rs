#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// The version of [Unicode](https://www.unicode.org/) that the Unicode parts of `char` and `str` methods are based on. <br>`char` 和 `str` 方法的 Unicode 部分所基于的 [Unicode](https://www.unicode.org/) 版本。<br>
///
/// New versions of Unicode are released regularly and subsequently all methods in the standard library depending on Unicode are updated. <br>Unicode 的新版本会定期发布，随后会更新标准库中取决于 Unicode 的所有方法。<br>
/// Therefore the behavior of some `char` and `str` methods and the value of this constant changes over time. <br>因此，某些 `char` 和 `str` 方法的行为以及该常量的值会随时间变化。<br>
/// This is *not* considered to be a breaking change. <br>这不是一个突破性的改变。<br>
///
/// The version numbering scheme is explained in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4). <br>版本编号方案在 [Unicode 11.0 或更高版本，第 3.1 节 Unicode 标准版本](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 中进行了说明。<br>
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// For use in liballoc, not re-exported in libstd. <br>供在 liballoc 中使用，而不在 libstd 中重导出。<br>
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;
