//! Ways to create a `str` from bytes slice. <br>从字节切片创建 `str` 的方法。<br>

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converts a slice of bytes to a string slice. <br>将字节切片转换为字符串切片。<br>
///
/// A string slice ([`&str`]) is made of bytes ([`u8`]), and a byte slice ([`&[u8]`][byteslice]) is made of bytes, so this function converts between the two. <br>字符串 ([`&str`]) 由字节 ([`u8`]) 组成，字节 ([`&[u8]`][byteslice]) 由字节组成，因此此函数在两者之间进行转换。<br>
/// Not all byte slices are valid string slices, however: [`&str`] requires that it is valid UTF-8. <br>并非所有的字节片都是有效的字符串切片，但是: [`&str`] 要求它是有效的 UTF-8。<br>
/// `from_utf8()` checks to ensure that the bytes are valid UTF-8, and then does the conversion. <br>`from_utf8()` 检查以确保字节是有效的 UTF-8，然后进行转换。<br>
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// If you are sure that the byte slice is valid UTF-8, and you don't want to incur the overhead of the validity check, there is an unsafe version of this function, [`from_utf8_unchecked`], which has the same behavior but skips the check. <br>如果您确定字节切片是有效的 UTF-8，并且不想增加有效性检查的开销，则此函数有一个不安全的版本 [`from_utf8_unchecked`]，它具有相同的行为，但是会跳过检查。<br>
///
///
/// If you need a `String` instead of a `&str`, consider [`String::from_utf8`][string]. <br>如果需要 `String` 而不是 `&str`，请考虑使用 [`String::from_utf8`][string]。<br>
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Because you can stack-allocate a `[u8; N]`, and you can take a [`&[u8]`][byteslice] of it, this function is one way to have a stack-allocated string. <br>因为您可以栈分配 `[u8; N]`，也可以使用它的 [`&[u8]`][byteslice]，所以此函数是具有栈分配的字符串的一种方法。<br> There is an example of this in the examples section below. <br>在下面的示例部分中有一个示例。<br>
///
/// [byteslice]: slice
///
/// # Errors
///
/// Returns `Err` if the slice is not UTF-8 with a description as to why the provided slice is not UTF-8. <br>如果切片不是 UTF-8，则返回 `Err`，并说明为什么提供的切片不是 UTF-8。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::str;
///
/// // some bytes, in a vector <br>vector 中的一些字节<br>
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // We know these bytes are valid, so just use `unwrap()`. <br>我们知道这些字节是有效的，因此只需使用 `unwrap()`。<br>
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Incorrect bytes: <br>字节不正确：<br>
///
/// ```
/// use std::str;
///
/// // some invalid bytes, in a vector <br>vector 中的一些无效字节<br>
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// See the docs for [`Utf8Error`] for more details on the kinds of errors that can be returned. <br>有关可以返回的错误类型的更多详细信息，请参见 [`Utf8Error`] 文档。<br>
///
/// A "stack allocated string": <br>一个栈分配的字符串：<br>
///
/// ```
/// use std::str;
///
/// // some bytes, in a stack-allocated array <br>栈分配的数组中的一些字节<br>
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // We know these bytes are valid, so just use `unwrap()`. <br>我们知道这些字节是有效的，因此只需使用 `unwrap()`。<br>
/// let sparkle_heart: &str = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_stable(feature = "const_str_from_utf8_shared", since = "1.63.0")]
#[rustc_allow_const_fn_unstable(str_internals)]
pub const fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    // FIXME: This should use `?` again, once it's `const` <br>这应该再次使用 `?`，一旦它是 `const`<br>
    match run_utf8_validation(v) {
        Ok(_) => {
            // SAFETY: validation succeeded. <br>验证成功。<br>
            Ok(unsafe { from_utf8_unchecked(v) })
        }
        Err(err) => Err(err),
    }
}

/// Converts a mutable slice of bytes to a mutable string slice. <br>将字节的可变切片转换为可变字符串切片。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" as a mutable vector <br>"Hello, Rust!" 作为一个附属 vector<br>
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // As we know these bytes are valid, we can use `unwrap()` <br>我们知道这些字节是有效的，因此我们可以使用 `unwrap()`<br>
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Incorrect bytes: <br>字节不正确：<br>
///
/// ```
/// use std::str;
///
/// // Some invalid bytes in a mutable vector <br>可变 vector 中的一些无效字节<br>
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// See the docs for [`Utf8Error`] for more details on the kinds of errors that can be returned. <br>有关可以返回的错误类型的更多详细信息，请参见 [`Utf8Error`] 文档。<br>
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8", issue = "91006")]
pub const fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    // This should use `?` again, once it's `const` <br>这应该再次使用 `?`，一旦它是 `const`<br>
    match run_utf8_validation(v) {
        Ok(_) => {
            // SAFETY: validation succeeded. <br>验证成功。<br>
            Ok(unsafe { from_utf8_unchecked_mut(v) })
        }
        Err(err) => Err(err),
    }
}

/// Converts a slice of bytes to a string slice without checking that the string contains valid UTF-8. <br>将字节切片转换为字符串切片，而无需检查字符串是否包含有效的 UTF-8。<br>
///
///
/// See the safe version, [`from_utf8`], for more information. <br>有关更多信息，请参见安全版本 [`from_utf8`]。<br>
///
/// # Safety
///
/// The bytes passed in must be valid UTF-8. <br>传入的字节必须是有效的 UTF-8。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::str;
///
/// // some bytes, in a vector <br>vector 中的一些字节<br>
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_stable(feature = "const_str_from_utf8_unchecked", since = "1.55.0")]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: the caller must guarantee that the bytes `v` are valid UTF-8. <br>调用者必须保证字节 `v` 是有效的 UTF-8。<br>
    // Also relies on `&str` and `&[u8]` having the same layout. <br>还依赖于 `&str` 和 `&[u8]` 具有相同的布局。<br>
    unsafe { mem::transmute(v) }
}

/// Converts a slice of bytes to a string slice without checking that the string contains valid UTF-8; <br>将字节切片转换为字符串切片，而无需检查字符串是否包含有效的 UTF-8；<br> mutable version. <br>可变版本。<br>
///
///
/// See the immutable version, [`from_utf8_unchecked()`] for more information. <br>有关更多信息，请参见不可变版本 [`from_utf8_unchecked()`]。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[must_use]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked_mut", issue = "91005")]
pub const unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: the caller must guarantee that the bytes `v` are valid UTF-8, thus the cast to `*mut str` is safe. <br>调用者必须保证字节 `v` 是有效的 UTF-8，因此将其强制转换为 `*mut str` 是安全的。<br>
    // Also, the pointer dereference is safe because that pointer comes from a reference which is guaranteed to be valid for writes. <br>而且，指针解引用是安全的，因为该指针来自引用，保证对写有效。<br>
    //
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}
