//! Constants for the `f64` double-precision floating point type. <br>`f64` 双精度浮点类型的常量。<br>
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Mathematically significant numbers are provided in the `consts` sub-module. <br>`consts` 子模块中提供了数学上有效的数字。<br>
//!
//! For the constants defined directly in this module (as distinct from those defined in the `consts` sub-module), new code should instead use the associated constants defined directly on the `f64` type. <br>对于直接在此模块中定义的常量 (不同于 `consts` 子模块中定义的常量)，新代码应改为使用直接在 `f64` 类型上定义的关联常量。<br>
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// The radix or base of the internal representation of `f64`. <br>`f64` 内部表示形式的基数或基数。<br>
/// Use [`f64::RADIX`] instead. <br>请改用 [`f64::RADIX`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // intended way <br>预期的方式<br>
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Number of significant digits in base 2. <br>以 2 为底的有效位数。<br>
/// Use [`f64::MANTISSA_DIGITS`] instead. <br>请改用 [`f64::MANTISSA_DIGITS`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // intended way <br>预期的方式<br>
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(
    since = "TBD",
    note = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Approximate number of significant digits in base 10. <br>以 10 为基数的有效位数的大概数字。<br>
/// Use [`f64::DIGITS`] instead. <br>请改用 [`f64::DIGITS`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // intended way <br>预期的方式<br>
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] value for `f64`. <br>`f64` 的 [机器精度][Machine epsilon] 值。<br>
/// Use [`f64::EPSILON`] instead. <br>请改用 [`f64::EPSILON`]。<br>
///
/// This is the difference between `1.0` and the next larger representable number. <br>这是 `1.0` 与下一个较大的可表示数字之间的差异。<br>
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // intended way <br>预期的方式<br>
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `EPSILON` associated constant on `f64`")]
pub const EPSILON: f64 = f64::EPSILON;

/// Smallest finite `f64` value. <br>最小的 `f64` 有限值。<br>
/// Use [`f64::MIN`] instead. <br>请改用 [`f64::MIN`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // intended way <br>预期的方式<br>
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Smallest positive normal `f64` value. <br>最小正 `f64` 正值。<br>
/// Use [`f64::MIN_POSITIVE`] instead. <br>请改用 [`f64::MIN_POSITIVE`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // intended way <br>预期的方式<br>
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN_POSITIVE` associated constant on `f64`")]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Largest finite `f64` value. <br>最大的有限 `f64` 值。<br>
/// Use [`f64::MAX`] instead. <br>请改用 [`f64::MAX`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // intended way <br>预期的方式<br>
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// One greater than the minimum possible normal power of 2 exponent. <br>比 2 的最小可能标准幂大一。<br>
/// Use [`f64::MIN_EXP`] instead. <br>请改用 [`f64::MIN_EXP`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // intended way <br>预期的方式<br>
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN_EXP` associated constant on `f64`")]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Maximum possible power of 2 exponent. <br>2 指数的最大可能乘方。<br>
/// Use [`f64::MAX_EXP`] instead. <br>请改用 [`f64::MAX_EXP`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // intended way <br>预期的方式<br>
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MAX_EXP` associated constant on `f64`")]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Minimum possible normal power of 10 exponent. <br>最小可能的标准幂为 10 指数。<br>
/// Use [`f64::MIN_10_EXP`] instead. <br>请改用 [`f64::MIN_10_EXP`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // intended way <br>预期的方式<br>
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN_10_EXP` associated constant on `f64`")]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Maximum possible power of 10 exponent. <br>最大可能功效为 10 指数。<br>
/// Use [`f64::MAX_10_EXP`] instead. <br>请改用 [`f64::MAX_10_EXP`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // intended way <br>预期的方式<br>
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MAX_10_EXP` associated constant on `f64`")]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Not a Number (NaN). <br>不是数字 (NaN)。<br>
/// Use [`f64::NAN`] instead. <br>请改用 [`f64::NAN`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // intended way <br>预期的方式<br>
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞). <br>无限 (∞)。<br>
/// Use [`f64::INFINITY`] instead. <br>请改用 [`f64::INFINITY`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // intended way <br>预期的方式<br>
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `INFINITY` associated constant on `f64`")]
pub const INFINITY: f64 = f64::INFINITY;

/// Negative infinity (−∞). <br>负无穷大 (−∞)。<br>
/// Use [`f64::NEG_INFINITY`] instead. <br>请改用 [`f64::NEG_INFINITY`]。<br>
///
/// # Examples
///
/// ```rust
/// // deprecated way <br>弃用的方式<br>
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // intended way <br>预期的方式<br>
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `NEG_INFINITY` associated constant on `f64`")]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Basic mathematical constants. <br>基本数学常量。<br>
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: replace with mathematical constants from cmath. <br>用 cmath 中的数学常量替换。<br>

    /// Archimedes' constant (π) <br>阿基米德的恒定 (π)<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// The full circle constant (τ) <br>整圈常量 (τ)<br>
    ///
    /// Equal to 2π. <br>等于 2π。<br>
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Euler's number (e) <br>欧拉数 (e)<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[cfg(not(test))]
impl f64 {
    /// The radix or base of the internal representation of `f64`. <br>`f64` 内部表示形式的基数或基数。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Number of significant digits in base 2. <br>以 2 为底的有效位数。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Approximate number of significant digits in base 10. <br>以 10 为基数的有效位数的大概数字。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] value for `f64`. <br>`f64` 的 [机器精度][Machine epsilon] 值。<br>
    ///
    /// This is the difference between `1.0` and the next larger representable number. <br>这是 `1.0` 与下一个较大的可表示数字之间的差异。<br>
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Smallest finite `f64` value. <br>最小的 `f64` 有限值。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Smallest positive normal `f64` value. <br>最小正 `f64` 正值。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Largest finite `f64` value. <br>最大的有限 `f64` 值。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// One greater than the minimum possible normal power of 2 exponent. <br>比 2 的最小可能标准幂大一。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Maximum possible power of 2 exponent. <br>2 指数的最大可能乘方。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Minimum possible normal power of 10 exponent. <br>最小可能的标准幂为 10 指数。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Maximum possible power of 10 exponent. <br>最大可能功效为 10 指数。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Not a Number (NaN). <br>不是数字 (NaN)。<br>
    ///
    /// Note that IEEE 754 doesn't define just a single NaN value; <br>请注意，IEEE 754 不只定义一个 NaN 值;<br>
    /// a plethora of bit patterns are considered to be NaN. <br>过多的位模式被认为是 NaN。<br>
    /// Furthermore, the standard makes a difference between a "signaling" and a "quiet" NaN, and allows inspecting its "payload" (the unspecified bits in the bit pattern). <br>此外，该标准区分了 "signaling" 和 "quiet" NaN，并允许检查其 "payload" (位模式中未指定的位)。<br>
    /// This constant isn't guaranteed to equal to any specific NaN bitpattern, and the stability of its representation over Rust versions and target platforms isn't guaranteed. <br>不保证此特性等于任何特定的 NaN 位模式，并且不保证其表示在 Rust 版本和目标平台上的稳定性。<br>
    ///
    ///
    ///
    ///
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞). <br>无限 (∞)。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Negative infinity (−∞). <br>负无穷大 (−∞)。<br>
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Returns `true` if this value is NaN. <br>如果此值为 NaN，则返回 `true`。<br>
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` is publicly unavailable in libcore due to concerns about portability, so this implementation is for private use internally. <br>由于担心可移植性，`abs` 在 libcore 中公开不可用，所以这个实现是内部私有的。<br>
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub(crate) const fn abs_private(self) -> f64 {
        // SAFETY: This transmutation is fine. <br>这个转变很好。<br> Probably. For the reasons std is using it. <br>大概吧。可能因为 std 使用它的原因。<br>
        unsafe {
            mem::transmute::<u64, f64>(mem::transmute::<f64, u64>(self) & 0x7fff_ffff_ffff_ffff)
        }
    }

    /// Returns `true` if this value is positive infinity or negative infinity, and `false` otherwise. <br>如果此值是正无穷大或负无穷大，则返回 `true`，否则返回 `false`。<br>
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        // Getting clever with transmutation can result in incorrect answers on some FPUs <br>使用转变可能会导致某些 FPU 的错误答复<br>
        // FIXME: alter the Rust <-> Rust calling convention to prevent this problem. <br>改变 Rust <-> Rust 调用约定来防止这个问题。<br>
        // See https://github.com/rust-lang/rust/issues/72327
        (self == f64::INFINITY) | (self == f64::NEG_INFINITY)
    }

    /// Returns `true` if this number is neither infinite nor NaN. <br>如果此数字既不是无穷大也不是 NaN，则返回 `true`。<br>
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // There's no need to handle NaN separately: if self is NaN, the comparison is not true, exactly as desired. <br>无需单独处理 NaN: 如果 self 是 NaN，则比较不完全正确。<br>
        //
        self.abs_private() < Self::INFINITY
    }

    /// Returns `true` if the number is [subnormal]. <br>如果数字为 [subnormal]，则返回 `true`。<br>
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Values between `0` and `min` are Subnormal. <br>`0` 和 `min` 之间的值是次标准的。<br>
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[must_use]
    #[stable(feature = "is_subnormal", since = "1.53.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Returns `true` if the number is neither zero, infinite, [subnormal], or NaN. <br>如果数字既不是零、无穷大、[subnormal] 或 NaN，则返回 `true`。<br>
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Values between `0` and `min` are Subnormal. <br>`0` 和 `min` 之间的值是次标准的。<br>
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Returns the floating point category of the number. <br>返回数字的浮点类别。<br>
    /// If only one property is going to be tested, it is generally faster to use the specific predicate instead. <br>如果仅要测试一个属性，则通常使用特定谓词会更快。<br>
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        // A previous implementation tried to only use bitmask-based checks, using f64::to_bits to transmute the float to its bit repr and match on that. <br>以前的实现尝试仅使用基于位掩码的检查，使用 f64::to_bits 将浮点数转换为它的位 repr 并在其上进行匹配。<br>
        // Unfortunately, floating point numbers can be much worse than that. <br>不幸的是，浮点数可能比这更糟糕。<br>
        // This also needs to not result in recursive evaluations of f64::to_bits. <br>这也不需要导致对 f64::to_bits 的递归计算。<br>
        //
        // On some processors, in some cases, LLVM will "helpfully" lower floating point ops, in spite of a request for them using f32 and f64, to things like x87 operations. <br>在某些处理器上，在某些情况下，LLVM 将有益地降低浮点运算，尽管要求它们使用 f32 和 f64，但对 x87 运算之类的操作。<br>
        //
        // These have an f64's mantissa, but can have a larger than normal exponent. <br>它们有一个 f64 的尾数，但可以具有比正常指数更大的指数。<br>
        // FIXME(jubilee): Using x87 operations is never necessary in order to function on x86 processors for Rust-to-Rust calls, so this issue should not happen. <br>为了在 x86 处理器上进行 Rust 到 Rust 的调用，永远不需要使用 x87 操作，所以不应该发生这个问题。<br>
        // Code generation should be adjusted to use non-C calling conventions, avoiding this. <br>应调整代码生成以使用非 C 调用约定，从而避免这种情况。<br>
        //
        // Thus, a value may compare unequal to infinity, despite having a "full" exponent mask. <br>因此，一个值可能比较不等于无穷大，尽管具有 "full" 指数掩码。<br>
        // And it may not be NaN, as it can simply be an "overextended" finite value. <br>它可能不是 NaN，因为它可以简单地是一个 "overextended" 有限值。<br>
        //
        //
        if self.is_nan() {
            FpCategory::Nan
        } else {
            // However, std can't simply compare to zero to check for zero, either, as correctness requires avoiding equality tests that may be Subnormal == -0.0 because it may be wrong under "denormals are zero" and "flush to zero" modes. <br>但是，std 也不能简单地与零比较来检查是否为零，因为正确性需要避免可能是 Subnormal == -0.0 的相等测试，因为它在 "denormals are zero" 和 "flush to zero" 模式下可能是错误的。<br>
            //
            // Most of std's targets don't use those, but they are used for thumbv7neon. <br>大多数 std 的目标不使用这些，但它们用于 thumbv7neon。<br>
            // So, this does use bitpattern matching for the rest. <br>因此，这确实使用了其余部分的位模式匹配。<br>
            //

            // SAFETY: f64 to u64 is fine. <br>f64 到 u64 没问题。<br> Usually.
            // If control flow has gotten this far, the value is definitely in one of the categories that f64::partial_classify can correctly analyze. <br>如果控制流已经走到了这一步，那么该值肯定属于 f64::partial_classify 可以正确分析的类别之一。<br>
            //
            unsafe { f64::partial_classify(self) }
        }
    }

    // This doesn't actually return a right answer for NaN on purpose, seeing as how it cannot correctly discern between a floating point NaN, and some normal floating point numbers truncated from an x87 FPU. <br>这实际上并没有故意返回 NaN 的正确答案，因为它无法正确区分浮点 NaN 和从 x87 FPU 截断的一些正常浮点数。<br>
    //
    //
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const unsafe fn partial_classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        // SAFETY: The caller is not asking questions for which this will tell lies. <br>调用者不会问这样会说谎的问题。<br>
        let b = unsafe { mem::transmute::<f64, u64>(self) };
        match (b & MAN_MASK, b & EXP_MASK) {
            (0, EXP_MASK) => FpCategory::Infinite,
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            _ => FpCategory::Normal,
        }
    }

    // This operates on bits, and only bits, so it can ignore concerns about weird FPUs. <br>它对位进行操作，并且仅对位进行操作，因此它可以忽略对奇怪 FPU 的担忧。<br>
    // FIXME(jubilee): In a just world, this would be the entire impl for classify, plus a transmute. <br>在一个公正的世界里，这将是分类的整个 impl，加上一个 transmute。<br>
    // We do not live in a just world, but we can make it more so. <br>我们并不生活在一个公正的世界里，但我们可以让它变得更加公正。<br>
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn classify_bits(b: u64) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        match (b & MAN_MASK, b & EXP_MASK) {
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            _ => FpCategory::Normal,
        }
    }

    /// Returns `true` if `self` has a positive sign, including `+0.0`, NaNs with positive sign bit and positive infinity. <br>如果 `self` 有正号，则返回 `true`，包括 `+0.0`、带正号位的 NaN 和正无穷大。<br>
    /// Note that IEEE 754 doesn't assign any meaning to the sign bit in case of a NaN, and as Rust doesn't guarantee that the bit pattern of NaNs are conserved over arithmetic operations, the result of `is_sign_positive` on a NaN might produce an unexpected result in some cases. <br>请注意，在 NaN 的情况下，IEEE 754 不会为符号位分配任何含义，并且由于 Rust 不保证 NaN 的位模式在算术运算中保持不变，因此 `is_sign_positive` 对 NaN 的结果可能会产生意外在某些情况下导致。<br>
    ///
    /// See [explanation of NaN as a special value](f32) for more info. <br>有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。<br>
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    ///
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(since = "1.0.0", note = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Returns `true` if `self` has a negative sign, including `-0.0`, NaNs with negative sign bit and negative infinity. <br>如果 `self` 具有 negative 符号，则返回 `true`，包括 `-0.0`、具有 negative 符号位的 NaN 和 negative 无穷大。<br>
    /// Note that IEEE 754 doesn't assign any meaning to the sign bit in case of a NaN, and as Rust doesn't guarantee that the bit pattern of NaNs are conserved over arithmetic operations, the result of `is_sign_negative` on a NaN might produce an unexpected result in some cases. <br>请注意，在 NaN 的情况下，IEEE 754 不会为符号位分配任何含义，并且由于 Rust 不保证 NaN 的位模式在算术运算中保持不变，因此 `is_sign_negative` 对 NaN 的结果可能会产生意外在某些情况下导致。<br>
    ///
    /// See [explanation of NaN as a special value](f32) for more info. <br>有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。<br>
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    ///
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 says: isSignMinus(x) is true if and only if x has negative sign. <br>IEEE754 说：当且仅当 x 具有负号时，isSignMinus(x) 才为 true。<br>
        // isSignMinus applies to zeros and NaNs as well. <br>isSignMinus 也适用于零和 NaN。<br>
        // SAFETY: This is just transmuting to get the sign bit, it's fine. <br>这只是为了得到符号位而转换，没关系。<br>
        unsafe { mem::transmute::<f64, u64>(self) & 0x8000_0000_0000_0000 != 0 }
    }

    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(since = "1.0.0", note = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Returns the least number greater than `self`. <br>返回大于 `self` 的最小数字。<br>
    ///
    /// Let `TINY` be the smallest representable positive `f64`. <br>令 `TINY` 为可表示的最小正 `f64`。<br>
    /// Then,
    ///  - if `self.is_nan()`, this returns `self`; <br>如果是 `self.is_nan()`，则返回 `self`;<br>
    ///  - if `self` is [`NEG_INFINITY`], this returns [`MIN`]; <br>如果 `self` 是 [`NEG_INFINITY`]，则返回 [`MIN`];<br>
    ///  - if `self` is `-TINY`, this returns -0.0; <br>如果 `self` 是 `-TINY`，则返回 - 0.0;<br>
    ///  - if `self` is -0.0 or +0.0, this returns `TINY`; <br>如果 `self` 为 - 0.0 或 + 0.0，则返回 `TINY`;<br>
    ///  - if `self` is [`MAX`] or [`INFINITY`], this returns [`INFINITY`]; <br>如果 `self` 是 [`MAX`] 或 [`INFINITY`]，则返回 [`INFINITY`];<br>
    ///  - otherwise the unique least value greater than `self` is returned. <br>否则返回大于 `self` 的唯一最小值。<br>
    ///
    /// The identity `x.next_up() == -(-x).next_down()` holds for all non-NaN `x`. <br>恒等式 `x.next_up() == -(-x).next_down()` 适用于所有非 NaN `x`。<br> When `x` is finite `x == x.next_up().next_down()` also holds. <br>当 `x` 为有限时，`x == x.next_up().next_down()` 也成立。<br>
    ///
    /// ```rust
    /// #![feature(float_next_up_down)]
    /// // f64::EPSILON is the difference between 1.0 and the next number up. <br>f64::EPSILON 是 1.0 和下一个数字之间的差。<br>
    /// assert_eq!(1.0f64.next_up(), 1.0 + f64::EPSILON);
    /// // But not for most numbers. <br>但不适用于大多数数字。<br>
    /// assert!(0.1f64.next_up() < 0.1 + f64::EPSILON);
    /// assert_eq!(9007199254740992f64.next_up(), 9007199254740994.0);
    /// ```
    ///
    /// [`NEG_INFINITY`]: Self::NEG_INFINITY
    /// [`INFINITY`]: Self::INFINITY
    /// [`MIN`]: Self::MIN
    /// [`MAX`]: Self::MAX
    #[unstable(feature = "float_next_up_down", issue = "91399")]
    #[rustc_const_unstable(feature = "float_next_up_down", issue = "91399")]
    pub const fn next_up(self) -> Self {
        // We must use strictly integer arithmetic to prevent denormals from flushing to zero after an arithmetic operation on some platforms. <br>我们必须使用严格的整数算术来防止非正规在某些平台上的算术运算后刷新为零。<br>
        //
        const TINY_BITS: u64 = 0x1; // Smallest positive f64. <br>最小正 f64。<br>
        const CLEAR_SIGN_MASK: u64 = 0x7fff_ffff_ffff_ffff;

        let bits = self.to_bits();
        if self.is_nan() || bits == Self::INFINITY.to_bits() {
            return self;
        }

        let abs = bits & CLEAR_SIGN_MASK;
        let next_bits = if abs == 0 {
            TINY_BITS
        } else if bits == abs {
            bits + 1
        } else {
            bits - 1
        };
        Self::from_bits(next_bits)
    }

    /// Returns the greatest number less than `self`. <br>返回小于 `self` 的最大数。<br>
    ///
    /// Let `TINY` be the smallest representable positive `f64`. <br>令 `TINY` 为可表示的最小正 `f64`。<br>
    /// Then,
    ///  - if `self.is_nan()`, this returns `self`; <br>如果是 `self.is_nan()`，则返回 `self`;<br>
    ///  - if `self` is [`INFINITY`], this returns [`MAX`]; <br>如果 `self` 是 [`INFINITY`]，则返回 [`MAX`];<br>
    ///  - if `self` is `TINY`, this returns 0.0; <br>如果 `self` 是 `TINY`，则返回 0.0;<br>
    ///  - if `self` is -0.0 or +0.0, this returns `-TINY`; <br>如果 `self` 为 - 0.0 或 + 0.0，则返回 `-TINY`;<br>
    ///  - if `self` is [`MIN`] or [`NEG_INFINITY`], this returns [`NEG_INFINITY`]; <br>如果 `self` 是 [`MIN`] 或 [`NEG_INFINITY`]，则返回 [`NEG_INFINITY`];<br>
    ///  - otherwise the unique greatest value less than `self` is returned. <br>否则返回小于 `self` 的唯一最大值。<br>
    ///
    /// The identity `x.next_down() == -(-x).next_up()` holds for all non-NaN `x`. <br>恒等式 `x.next_down() == -(-x).next_up()` 适用于所有非 NaN `x`。<br> When `x` is finite `x == x.next_down().next_up()` also holds. <br>当 `x` 为有限时，`x == x.next_down().next_up()` 也成立。<br>
    ///
    /// ```rust
    /// #![feature(float_next_up_down)]
    /// let x = 1.0f64;
    /// // Clamp value into range [0, 1). <br>将值限制在 [0, 1) 范围内。<br>
    /// let clamped = x.clamp(0.0, 1.0f64.next_down());
    /// assert!(clamped < 1.0);
    /// assert_eq!(clamped.next_up(), 1.0);
    /// ```
    ///
    /// [`NEG_INFINITY`]: Self::NEG_INFINITY
    /// [`INFINITY`]: Self::INFINITY
    /// [`MIN`]: Self::MIN
    /// [`MAX`]: Self::MAX
    #[unstable(feature = "float_next_up_down", issue = "91399")]
    #[rustc_const_unstable(feature = "float_next_up_down", issue = "91399")]
    pub const fn next_down(self) -> Self {
        // We must use strictly integer arithmetic to prevent denormals from flushing to zero after an arithmetic operation on some platforms. <br>我们必须使用严格的整数算术来防止非正规在某些平台上的算术运算后刷新为零。<br>
        //
        const NEG_TINY_BITS: u64 = 0x8000_0000_0000_0001; // Smallest (in magnitude) negative f64. <br>最小 (幅度) negative f64。<br>
        const CLEAR_SIGN_MASK: u64 = 0x7fff_ffff_ffff_ffff;

        let bits = self.to_bits();
        if self.is_nan() || bits == Self::NEG_INFINITY.to_bits() {
            return self;
        }

        let abs = bits & CLEAR_SIGN_MASK;
        let next_bits = if abs == 0 {
            NEG_TINY_BITS
        } else if bits == abs {
            bits - 1
        } else {
            bits + 1
        };
        Self::from_bits(next_bits)
    }

    /// Takes the reciprocal (inverse) of a number, `1/x`. <br>取一个数 `1/x` 的倒数 (inverse)。<br>
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[must_use = "this returns the result of the operation, without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Converts radians to degrees. <br>将弧度转换为度数。<br>
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // The division here is correctly rounded with respect to the true value of 180/π. <br>此处的除法相对于 180/π 的真实值正确取整。<br>
        // (This differs from f32, where a constant must be used to ensure a correctly rounded result.) <br>(这与 f32 不同，在 f32 中，必须使用常量来确保正确舍入结果。)<br>
        //
        self * (180.0f64 / consts::PI)
    }

    /// Converts degrees to radians. <br>将度数转换为弧度。<br>
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Returns the maximum of the two numbers, ignoring NaN. <br>返回两个数字中的最大值，忽略 NaN。<br>
    ///
    /// If one of the arguments is NaN, then the other argument is returned. <br>如果参数之一是 NaN，则返回另一个参数。<br>
    /// This follows the IEEE 754-2008 semantics for maxNum, except for handling of signaling NaNs; <br>这遵循 maxNum 的 IEEE 754-2008 语义，除了处理信令 NaN;<br>
    /// this function handles all NaNs the same way and avoids maxNum's problems with associativity. <br>这个函数以相同的方式处理所有的 NaN，并避免了 maxNum 的关联性问题。<br>
    /// This also matches the behavior of libm’s fmax. <br>这也符合 libm 的 fmax 的行为。<br>
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Returns the minimum of the two numbers, ignoring NaN. <br>返回两个数字中的最小值，忽略 NaN。<br>
    ///
    /// If one of the arguments is NaN, then the other argument is returned. <br>如果参数之一是 NaN，则返回另一个参数。<br>
    /// This follows the IEEE 754-2008 semantics for minNum, except for handling of signaling NaNs; <br>这遵循 minNum 的 IEEE 754-2008 语义，除了处理信令 NaN;<br>
    /// this function handles all NaNs the same way and avoids minNum's problems with associativity. <br>这个函数以相同的方式处理所有的 NaN，并避免了 minNum 的关联性问题。<br>
    /// This also matches the behavior of libm’s fmin. <br>这也符合 libm 的 fmin 的行为。<br>
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Returns the maximum of the two numbers, propagating NaN. <br>返回两个数字中的最大值，传播 NaN。<br>
    ///
    /// This returns NaN when *either* argument is NaN, as opposed to [`f64::max`] which only returns NaN when *both* arguments are NaN. <br>当任一参数为 NaN 时，这将返回 NaN，而 [`f64::max`] 仅当两个参数都为 NaN 时才返回 NaN。<br>
    ///
    /// ```
    /// #![feature(float_minimum_maximum)]
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.maximum(y), y);
    /// assert!(x.maximum(f64::NAN).is_nan());
    /// ```
    ///
    /// If one of the arguments is NaN, then NaN is returned. <br>如果参数之一是 NaN，则返回 NaN。<br> Otherwise this returns the greater of the two numbers. <br>否则，这将返回两个数字中较大的一个。<br> For this operation, -0.0 is considered to be less than +0.0. <br>对于此操作，`-0.0` 被认为小于 `+0.0`。<br>
    /// Note that this follows the semantics specified in IEEE 754-2019. <br>请注意，这遵循 IEEE 754-2019 中指定的语义。<br>
    ///
    /// Also note that "propagation" of NaNs here doesn't necessarily mean that the bitpattern of a NaN operand is conserved; <br>另请注意，此处 NaN 的 "propagation" 并不一定意味着 NaN 操作数的位模式是守恒的;<br> see [explanation of NaN as a special value](f32) for more info. <br>有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。<br>
    ///
    ///
    ///
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[unstable(feature = "float_minimum_maximum", issue = "91079")]
    #[inline]
    pub fn maximum(self, other: f64) -> f64 {
        if self > other {
            self
        } else if other > self {
            other
        } else if self == other {
            if self.is_sign_positive() && other.is_sign_negative() { self } else { other }
        } else {
            self + other
        }
    }

    /// Returns the minimum of the two numbers, propagating NaN. <br>返回两个数字中的最小值，传播 NaN。<br>
    ///
    /// This returns NaN when *either* argument is NaN, as opposed to [`f64::min`] which only returns NaN when *both* arguments are NaN. <br>当任一参数为 NaN 时返回 NaN，而 [`f64::min`] 仅当两个参数都为 NaN 时才返回 NaN。<br>
    ///
    /// ```
    /// #![feature(float_minimum_maximum)]
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.minimum(y), x);
    /// assert!(x.minimum(f64::NAN).is_nan());
    /// ```
    ///
    /// If one of the arguments is NaN, then NaN is returned. <br>如果参数之一是 NaN，则返回 NaN。<br> Otherwise this returns the lesser of the two numbers. <br>否则，这将返回两个数字中的较小者。<br> For this operation, -0.0 is considered to be less than +0.0. <br>对于此操作，`-0.0` 被认为小于 `+0.0`。<br>
    /// Note that this follows the semantics specified in IEEE 754-2019. <br>请注意，这遵循 IEEE 754-2019 中指定的语义。<br>
    ///
    /// Also note that "propagation" of NaNs here doesn't necessarily mean that the bitpattern of a NaN operand is conserved; <br>另请注意，此处 NaN 的 "propagation" 并不一定意味着 NaN 操作数的位模式是守恒的;<br> see [explanation of NaN as a special value](f32) for more info. <br>有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。<br>
    ///
    ///
    ///
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[unstable(feature = "float_minimum_maximum", issue = "91079")]
    #[inline]
    pub fn minimum(self, other: f64) -> f64 {
        if self < other {
            self
        } else if other < self {
            other
        } else if self == other {
            if self.is_sign_negative() && other.is_sign_positive() { self } else { other }
        } else {
            self + other
        }
    }

    /// Rounds toward zero and converts to any primitive integer type, assuming that the value is finite and fits in that type. <br>舍入为零并转换为任何原始整数类型，前提是该值是有限的并且适合该类型。<br>
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// The value must: <br>该值必须：<br>
    ///
    /// * Not be `NaN` <br>不是 `NaN`<br>
    /// * Not be infinite <br>不是无限的<br>
    /// * Be representable in the return type `Int`, after truncating off its fractional part <br>截断小数部分后，可以在返回类型 `Int` 中表示<br>
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: the caller must uphold the safety contract for `FloatToInt::to_int_unchecked`. <br>调用者必须遵守 `FloatToInt::to_int_unchecked` 的安全保证。<br>
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutation to `u64`. <br>原始 trans 变为 `u64`。<br>
    ///
    /// This is currently identical to `transmute::<f64, u64>(self)` on all platforms. <br>当前，这与所有平台上的 `transmute::<f64, u64>(self)` 相同。<br>
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    /// Note that this function is distinct from `as` casting, which attempts to preserve the *numeric* value, and not the bitwise value. <br>请注意，此函数与 `as` 强制转换不同，后者试图保留 *数字* 值，而不是按位值。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() is not casting! <br>to_bits() 不是 casting!<br>
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SAFETY: `u64` is a plain old datatype so we can always transmute to it. <br>`u64` 是一个普通的旧数据类型，所以我们总是可以转换成它。<br>
        // ...sorta.
        //
        // See the SAFETY comment in f64::from_bits for more. <br>有关更多信息，请参见 f64::from_bits 中的 SAFETY 注释。<br>
        #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
        const fn ct_f64_to_u64(ct: f64) -> u64 {
            match ct.classify() {
                FpCategory::Nan => {
                    panic!("const-eval error: cannot use f64::to_bits on a NaN")
                }
                FpCategory::Subnormal => {
                    panic!("const-eval error: cannot use f64::to_bits on a subnormal number")
                }
                FpCategory::Infinite | FpCategory::Normal | FpCategory::Zero => {
                    // SAFETY: We have a normal floating point number. <br>我们有一个普通的浮点数。<br> Now we transmute, i.e. do a bitcopy. <br>现在我们进行转换，即进行位复制。<br>
                    unsafe { mem::transmute::<f64, u64>(ct) }
                }
            }
        }

        #[inline(always)] // See https://github.com/rust-lang/compiler-builtins/issues/491
        fn rt_f64_to_u64(rt: f64) -> u64 {
            // SAFETY: `u64` is a plain old datatype so we can always... <br>`u64` 是一个普通的旧数据类型，所以我们总是可以......<br> uh...
            // ...look, just pretend you forgot what you just read. <br>... 看，就假装您忘记了您刚刚读到的东西。<br>
            // Stability concerns. <br>稳定性问题。<br>
            unsafe { mem::transmute::<f64, u64>(rt) }
        }
        // SAFETY: We use internal implementations that either always work or fail at compile time. <br>我们使用在编译时要么总是工作要么失败的内部实现。<br>
        unsafe { intrinsics::const_eval_select((self,), ct_f64_to_u64, rt_f64_to_u64) }
    }

    /// Raw transmutation from `u64`. <br>来自 `u64` 的原始 mut 变。<br>
    ///
    /// This is currently identical to `transmute::<u64, f64>(v)` on all platforms. <br>当前，这与所有平台上的 `transmute::<u64, f64>(v)` 相同。<br>
    /// It turns out this is incredibly portable, for two reasons: <br>事实证明，此方法具有很高的可移植性，其原因有两个：<br>
    ///
    /// * Floats and Ints have the same endianness on all supported platforms. <br>浮点数和整数在所有受支持的平台上具有相同的字节序。<br>
    /// * IEEE 754 very precisely specifies the bit layout of floats. <br>IEEE 754 非常精确地指定了浮点数的位布局。<br>
    ///
    /// However there is one caveat: prior to the 2008 version of IEEE 754, how to interpret the NaN signaling bit wasn't actually specified. <br>但是有一个警告: 在 2008 年版本的 IEEE 754 之前，实际上并未指定如何解释 NaN 信号位。<br>
    /// Most platforms (notably x86 and ARM) picked the interpretation that was ultimately standardized in 2008, but some didn't (notably MIPS). <br>大多数平台 (特别是 x86 和 ARM) 采用了最终在 2008 年标准化的解释，但有些则没有 (特别是 MIPS)。<br>
    /// As a result, all signaling NaNs on MIPS are quiet NaNs on x86, and vice-versa. <br>结果，MIPS 上的所有信令 NaN 都是 x86 上的安静 NaN，反之亦然。<br>
    ///
    /// Rather than trying to preserve signaling-ness cross-platform, this implementation favors preserving the exact bits. <br>该实现方式不是尝试保留跨信令的信令，而是倾向于保留确切的位。<br>
    /// This means that any payloads encoded in NaNs will be preserved even if the result of this method is sent over the network from an x86 machine to a MIPS one. <br>这意味着，即使此方法的结果通过网络从 x86 机器发送到 MIPS 机器，任何以 NaN 编码的有效载荷也将被保留。<br>
    ///
    ///
    /// If the results of this method are only manipulated by the same architecture that produced them, then there is no portability concern. <br>如果这个方法的结果只由产生它们的同一个架构操纵，那么就没有可移植性的问题。<br>
    ///
    /// If the input isn't NaN, then there is no portability concern. <br>如果输入的不是 NaN，则不存在可移植性问题。<br>
    ///
    /// If you don't care about signaling-ness (very likely), then there is no portability concern. <br>如果您不太在意信号传递性，那么就不必担心可移植性。<br>
    ///
    /// Note that this function is distinct from `as` casting, which attempts to preserve the *numeric* value, and not the bitwise value. <br>请注意，此函数与 `as` 强制转换不同，后者试图保留 *数字* 值，而不是按位值。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // It turns out the safety issues with sNaN were overblown! <br>事实证明，sNaN 的安全问题被夸大了!<br> Hooray!
        // SAFETY: `u64` is a plain old datatype so we can always transmute from it ...sorta. <br>`u64` 是一个普通的旧数据类型，所以我们总是可以从它变形...... 排序。<br>
        //
        // It turns out that at runtime, it is possible for a floating point number to be subject to floating point modes that alter nonzero subnormal numbers to zero on reads and writes, aka "denormals are zero" and "flush to zero". <br>事实证明，在运行时，浮点数可能会受到浮点模式的影响，这些模式在读取和写入时将非零 subnormal 数更改为零，即 "denormals are zero" 和 "flush to zero"。<br>
        // This is not a problem usually, but at least one tier2 platform for Rust actually exhibits an FTZ behavior by default: thumbv7neon aka "the Neon FPU in AArch32 state" <br>这通常不是问题，但 Rust 的至少一个 tier2 平台实际上默认表现出 FTZ 行为: thumbv7neon aka "the Neon FPU in AArch32 state"<br>
        //
        // Even with this, not all instructions exhibit the FTZ behaviors on thumbv7neon, so this should load the same bits if LLVM emits the "correct" instructions, but LLVM sometimes makes interesting choices about float optimization, and other FPUs may do similar. <br>即使这样，并非所有指令都在 thumbv7neon 上表现出 FTZ 行为，因此如果 LLVM 发出 "correct" 指令，这应该加载相同的位，但 LLVM 有时会做出有趣的浮点优化选择，其他 FPU 可能会做类似的事情。<br>
        //
        // Thus, it is wise to indulge luxuriously in caution. <br>因此，谨慎地放纵奢华是明智的。<br>
        //
        // In addition, on x86 targets with SSE or SSE2 disabled and the x87 FPU enabled, i.e. <br>此外，在禁用 SSE 或 SSE2 并启用 x87 FPU 的 x86 目标上，即<br>
        // not soft-float, the way Rust does parameter passing can actually alter a number that is "not infinity" to have the same exponent as infinity, in a slightly unpredictable manner. <br>不是软浮点，Rust 进行参数传递的方式实际上可以以稍微不可预测的方式将 "not infinity" 的数字更改为具有与无穷大相同的指数。<br>
        //
        // And, of course evaluating to a NaN value is fairly nondeterministic. <br>而且，当然评估到 NaN 值是相当不确定的。<br>
        // More precisely: when NaN should be returned is knowable, but which NaN? <br>更准确地说: 什么时候应该返回 NaN 是可知的，但是哪个 NaN 呢?<br>
        // So far that's defined by a combination of LLVM and the CPU, not Rust. <br>到目前为止，这是由 LLVM 和 CPU 的组合定义的，而不是 Rust。<br>
        // This function, however, allows observing the bitstring of a NaN, thus introspection on CTFE. <br>然而，这个函数允许观察 NaN 的位串，从而对 CTFE 进行内省。<br>
        //
        // In order to preserve, at least for the moment, const-to-runtime equivalence, reject any of these possible situations from happening. <br>为了至少暂时保持 const 到运行时的等价性，拒绝任何这些可能的情况发生。<br>
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
        const fn ct_u64_to_f64(ct: u64) -> f64 {
            match f64::classify_bits(ct) {
                FpCategory::Subnormal => {
                    panic!("const-eval error: cannot use f64::from_bits on a subnormal number")
                }
                FpCategory::Nan => {
                    panic!("const-eval error: cannot use f64::from_bits on NaN")
                }
                FpCategory::Infinite | FpCategory::Normal | FpCategory::Zero => {
                    // SAFETY: It's not a frumious number <br>这不是一个有趣的数字<br>
                    unsafe { mem::transmute::<u64, f64>(ct) }
                }
            }
        }

        #[inline(always)] // See https://github.com/rust-lang/compiler-builtins/issues/491
        fn rt_u64_to_f64(rt: u64) -> f64 {
            // SAFETY: `u64` is a plain old datatype so we can always... <br>`u64` 是一个普通的旧数据类型，所以我们总是可以......<br> uh...
            // ...look, just pretend you forgot what you just read. <br>... 看，就假装您忘记了您刚刚读到的东西。<br>
            // Stability concerns. <br>稳定性问题。<br>
            unsafe { mem::transmute::<u64, f64>(rt) }
        }
        // SAFETY: We use internal implementations that either always work or fail at compile time. <br>我们使用在编译时要么总是工作要么失败的内部实现。<br>
        unsafe { intrinsics::const_eval_select((v,), ct_u64_to_f64, rt_u64_to_f64) }
    }

    /// Return the memory representation of this floating point number as a byte array in big-endian (network) byte order. <br>以大端 (网络) 字节顺序的字节数组形式返回此浮点数的内存表示形式。<br>
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Return the memory representation of this floating point number as a byte array in little-endian byte order. <br>以小字节序字节顺序将浮点数的内存表示形式返回为字节数组。<br>
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Return the memory representation of this floating point number as a byte array in native byte order. <br>返回此浮点数的内存表示形式，以原生字节顺序的字节数组形式。<br>
    ///
    /// As the target platform's native endianness is used, portable code should use [`to_be_bytes`] or [`to_le_bytes`], as appropriate, instead. <br>由于使用了目标平台的原生字节序，因此，可移植代码应酌情使用 [`to_be_bytes`] 或 [`to_le_bytes`]。<br>
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Create a floating point value from its representation as a byte array in big endian. <br>从其表示形式以 big endian 的字节数组创建一个浮点值。<br>
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Create a floating point value from its representation as a byte array in little endian. <br>从它的表示形式以 Little Endian 的字节数组创建一个浮点值。<br>
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Create a floating point value from its representation as a byte array in native endian. <br>从其表示形式 (以原生字节序形式的字节数组形式) 创建浮点值。<br>
    ///
    /// As the target platform's native endianness is used, portable code likely wants to use [`from_be_bytes`] or [`from_le_bytes`], as appropriate instead. <br>由于使用了目标平台的原生字节序，因此可移植代码可能希望酌情使用 [`from_be_bytes`] 或 [`from_le_bytes`]。<br>
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// See [`from_bits`](Self::from_bits) for some discussion of the portability of this operation (there are almost no issues). <br>有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Return the ordering between `self` and `other`. <br>返回 `self` 和 `other` 之间的顺序。<br>
    ///
    /// Unlike the standard partial comparison between floating point numbers, this comparison always produces an ordering in accordance to the `totalOrder` predicate as defined in the IEEE 754 (2008 revision) floating point standard. <br>与浮点数之间的标准部分比较不同，此比较始终根据 IEEE 754 (2008 修订版) 浮点标准中定义的 `totalOrder` 谓词生成排序。<br>
    /// The values are ordered in the following sequence: <br>这些值按以下顺序排序:<br>
    ///
    /// - negative quiet NaN
    /// - negative signaling NaN
    /// - negative infinity
    /// - negative numbers
    /// - negative subnormal numbers
    /// - negative zero
    /// - positive zero
    /// - positive subnormal numbers
    /// - positive numbers
    /// - positive infinity
    /// - positive signaling NaN
    /// - positive quiet NaN.
    ///
    /// The ordering established by this function does not always agree with the [`PartialOrd`] and [`PartialEq`] implementations of `f64`. <br>这个函数建立的顺序并不总是与 `f64` 的 [`PartialOrd`] 和 [`PartialEq`] 实现一致。<br>
    /// For example, they consider negative and positive zero equal, while `total_cmp` <br>例如，他们认为负零和正零相等，而 `total_cmp`<br>
    /// doesn't.
    ///
    /// The interpretation of the signaling NaN bit follows the definition in the IEEE 754 standard, which may not match the interpretation by some of the older, non-conformant (e.g. MIPS) hardware implementations. <br>信令 NaN 位的解释遵循 IEEE 754 标准中的定义，这可能与一些旧的、不符合标准的 (例如 MIPS) 硬件实现的解释不匹配。<br>
    ///
    /// # Example
    ///
    /// ```
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "total_cmp", since = "1.62.0")]
    #[must_use]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // In case of negatives, flip all the bits except the sign to achieve a similar layout as two's complement integers <br>如果是负数，将除符号外的所有位翻转以实现与二进制补码整数相似的布局<br>
        //
        // Why does this work? <br>为什么这样做？<br> IEEE 754 floats consist of three fields: <br>IEEE 754 浮点数包含三个字段：<br>
        // Sign bit, exponent and mantissa. <br>符号位，指数和尾数。<br> The set of exponent and mantissa fields as a whole have the property that their bitwise order is equal to the numeric magnitude where the magnitude is defined. <br>整个指数和尾数字段具有以下属性：它们的按位顺序等于定义大小的数字大小。<br>
        // The magnitude is not normally defined on NaN values, but IEEE 754 totalOrder defines the NaN values also to follow the bitwise order. <br>幅度通常不是在 NaN 值上定义的，但是 IEEE 754 totalOrder 将 NaN 值也定义为遵循位顺序。<br> This leads to order explained in the doc comment. <br>这导致了文档注释中解释的顺序。<br>
        // However, the representation of magnitude is the same for negative and positive numbers – only the sign bit is different. <br>但是，对于负数和正数，幅值的表示是相同的 - 仅符号位不同。<br>
        // To easily compare the floats as signed integers, we need to flip the exponent and mantissa bits in case of negative numbers. <br>为了轻松地将浮点数与带符号整数进行比较，在负数的情况下，我们需要翻转指数位和尾数位。<br>
        // We effectively convert the numbers to "two's complement" form. <br>我们将数字有效地转换为 "二进制补码" 的形式。<br>
        //
        // To do the flipping, we construct a mask and XOR against it. <br>为了进行翻转，我们构造了一个掩码并对它进行 XOR。<br>
        // We branchlessly calculate an "all-ones except for the sign bit" mask from negative-signed values: right shifting sign-extends the integer, so we "fill" the mask with sign bits, and then convert to unsigned to push one more zero bit. <br>我们从负号值无分支地计算 "除符号位之外的全 1" 掩码: 右移符号以扩展整数，因此我们用符号位 "fill" 掩码，然后转换为无符号以压入另一个零位。<br>
        //
        // On positive values, the mask is all zeros, so it's a no-op. <br>如果为正值，则掩码全为零，因此是空操作。<br>
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Restrict a value to a certain interval unless it is NaN. <br>除非是 NaN，否则将值限制为一定的时间间隔。<br>
    ///
    /// Returns `max` if `self` is greater than `max`, and `min` if `self` is less than `min`. <br>如果 `self` 大于 `max`，则返回 `max`; 如果 `self` 小于 `min`，则返回 `min`。<br>
    /// Otherwise this returns `self`. <br>否则，将返回 `self`。<br>
    ///
    /// Note that this function returns NaN if the initial value was NaN as well. <br>请注意，如果初始值也为 NaN，则此函数将返回 NaN。<br>
    ///
    /// # Panics
    ///
    /// Panics if `min > max`, `min` is NaN, or `max` is NaN. <br>如果 `min > max`，`min` 为 NaN 或 `max` 为 NaN，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(mut self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        if self < min {
            self = min;
        }
        if self > max {
            self = max;
        }
        self
    }
}
