//! The libcore prelude
//!
//! This module is intended for users of libcore which do not link to libstd as well. <br>该模块适用于 libcore 的用户，这些用户也未链接到 libstd。<br>
//! This module is imported by default when `#![no_std]` is used in the same manner as the standard library's prelude. <br>当以与标准库的 prelude 相同的方式使用 `#![no_std]` 时，默认情况下将导入此模块。<br>
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// The 2015 version of the core prelude. <br>2015 版本的核心 prelude。<br>
///
/// See the [module-level documentation](self) for more. <br>有关更多信息，请参见 [模块级文档](self)。<br>
#[stable(feature = "prelude_2015", since = "1.55.0")]
pub mod rust_2015 {
    #[stable(feature = "prelude_2015", since = "1.55.0")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// The 2018 version of the core prelude. <br>2018 版本的核心 prelude。<br>
///
/// See the [module-level documentation](self) for more. <br>有关更多信息，请参见 [模块级文档](self)。<br>
#[stable(feature = "prelude_2018", since = "1.55.0")]
pub mod rust_2018 {
    #[stable(feature = "prelude_2018", since = "1.55.0")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// The 2021 version of the core prelude. <br>2021 版本的核心 prelude。<br>
///
/// See the [module-level documentation](self) for more. <br>有关更多信息，请参见 [模块级文档](self)。<br>
#[stable(feature = "prelude_2021", since = "1.55.0")]
pub mod rust_2021 {
    #[stable(feature = "prelude_2021", since = "1.55.0")]
    #[doc(no_inline)]
    pub use super::v1::*;

    #[stable(feature = "prelude_2021", since = "1.55.0")]
    #[doc(no_inline)]
    pub use crate::iter::FromIterator;

    #[stable(feature = "prelude_2021", since = "1.55.0")]
    #[doc(no_inline)]
    pub use crate::convert::{TryFrom, TryInto};
}

/// The 2024 edition of the core prelude. <br>核心 prelude 的 2024 年版。<br>
///
/// See the [module-level documentation](self) for more. <br>有关更多信息，请参见 [模块级文档](self)。<br>
#[unstable(feature = "prelude_2024", issue = "none")]
pub mod rust_2024 {
    #[unstable(feature = "prelude_2024", issue = "none")]
    #[doc(no_inline)]
    pub use super::rust_2021::*;
}
