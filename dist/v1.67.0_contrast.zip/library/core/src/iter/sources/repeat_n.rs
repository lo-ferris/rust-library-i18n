use crate::iter::{FusedIterator, TrustedLen};
use crate::mem::ManuallyDrop;

/// Creates a new iterator that repeats a single element a given number of times. <br>创建一个新的迭代器，该迭代器将单个元素重复给定的次数。<br>
///
/// The `repeat_n()` function repeats a single value exactly `n` times. <br>`repeat_n()` 函数精确重复单个值 `n` 次。<br>
///
/// This is very similar to using [`repeat()`] with [`Iterator::take()`], but there are two differences: <br>这与将 [`repeat()`] 与 [`Iterator::take()`] 一起使用非常相似，但有两个区别:<br>
///
/// - `repeat_n()` can return the original value, rather than always cloning. <br>`repeat_n()` 可以返回原始值，而不是总是克隆。<br>
/// - `repeat_n()` produces an [`ExactSizeIterator`]. <br>`repeat_n()` 生成 [`ExactSizeIterator`]。<br>
///
/// [`repeat()`]: crate::iter::repeat
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// #![feature(iter_repeat_n)]
/// use std::iter;
///
/// // four of the number four: <br>数字 4 中的 4:<br>
/// let mut four_fours = iter::repeat_n(4, 4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // no more fours <br>没有更多的四<br>
/// assert_eq!(None, four_fours.next());
/// ```
///
/// For non-`Copy` types, <br>对于非 `复制` 类型，<br>
///
/// ```
/// #![feature(iter_repeat_n)]
/// use std::iter;
///
/// let v: Vec<i32> = Vec::with_capacity(123);
/// let mut it = iter::repeat_n(v, 5);
///
/// for i in 0..4 {
///     // It starts by cloning things <br>它从克隆事物开始<br>
///     let cloned = it.next().unwrap();
///     assert_eq!(cloned.len(), 0);
///     assert_eq!(cloned.capacity(), 0);
/// }
///
/// // ... but the last item is the original one <br>但最后一项是原来的<br>
/// let last = it.next().unwrap();
/// assert_eq!(last.len(), 0);
/// assert_eq!(last.capacity(), 123);
///
/// // ... and now we're done <br>现在我们完成了<br>
/// assert_eq!(None, it.next());
/// ```
#[inline]
#[unstable(feature = "iter_repeat_n", issue = "104434")]
#[doc(hidden)] // waiting on ACP#120 to decide whether to expose publicly <br>等待 ACP#120 决定是否公开<br>
pub fn repeat_n<T: Clone>(element: T, count: usize) -> RepeatN<T> {
    let mut element = ManuallyDrop::new(element);

    if count == 0 {
        // SAFETY: we definitely haven't dropped it yet, since we only just got passed it in, and because the count is zero the instance we're about to create won't drop it, so to avoid leaking we need to now. <br>我们肯定还没有丢掉它，因为我们刚刚传入它，并且因为计数为零，我们将要创建的实例不会丢掉它，所以为了避免泄漏我们现在需要。<br>
        //
        //
        unsafe { ManuallyDrop::drop(&mut element) };
    }

    RepeatN { element, count }
}

/// An iterator that repeats an element an exact number of times. <br>将元素重复精确次数的迭代器。<br>
///
/// This `struct` is created by the [`repeat_n()`] function. <br>这个 `struct` 是由 [`repeat_n()`] 函数创造的。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
#[derive(Clone, Debug)]
#[unstable(feature = "iter_repeat_n", issue = "104434")]
#[doc(hidden)] // waiting on ACP#120 to decide whether to expose publicly <br>等待 ACP#120 决定是否公开<br>
pub struct RepeatN<A> {
    count: usize,
    // Invariant: has been dropped iff count == 0. <br>不变体: 已丢弃当且仅当 count == 0。<br>
    element: ManuallyDrop<A>,
}

impl<A> RepeatN<A> {
    /// If we haven't already dropped the element, return it in an option. <br>如果我们还没有抛弃该元素，请在选项中返回它。<br>
    ///
    /// Clears the count so it won't be dropped again later. <br>清除计数，这样以后就不会再丢了。<br>
    #[inline]
    fn take_element(&mut self) -> Option<A> {
        if self.count > 0 {
            self.count = 0;
            // SAFETY: We just set count to zero so it won't be dropped again, and it used to be non-zero so it hasn't already been dropped. <br>我们只是将 count 设置为零，这样它就不会再次丢弃，并且它曾经是非零的，所以它还没有被丢弃。<br>
            //
            unsafe { Some(ManuallyDrop::take(&mut self.element)) }
        } else {
            None
        }
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A> Drop for RepeatN<A> {
    fn drop(&mut self) {
        self.take_element();
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> Iterator for RepeatN<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.count == 0 {
            return None;
        }

        self.count -= 1;
        Some(if self.count == 0 {
            // SAFETY: the check above ensured that the count used to be non-zero, so element hasn't been dropped yet, and we just lowered the count to zero so it won't be dropped later, and thus it's okay to take it here. <br>上面的检查确保了计数曾经是非零的，所以元素还没有丢弃，我们只是将计数降低到零所以它以后不会丢弃，所以把它放在这里是可以的。<br>
            //
            //
            unsafe { ManuallyDrop::take(&mut self.element) }
        } else {
            A::clone(&mut self.element)
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    #[inline]
    fn advance_by(&mut self, skip: usize) -> Result<(), usize> {
        let len = self.count;

        if skip >= len {
            self.take_element();
        }

        if skip > len {
            Err(len)
        } else {
            self.count = len - skip;
            Ok(())
        }
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.take_element()
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> ExactSizeIterator for RepeatN<A> {
    fn len(&self) -> usize {
        self.count
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> DoubleEndedIterator for RepeatN<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        self.advance_by(n)
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        self.nth(n)
    }
}

#[unstable(feature = "iter_repeat_n", issue = "104434")]
impl<A: Clone> FusedIterator for RepeatN<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for RepeatN<A> {}
