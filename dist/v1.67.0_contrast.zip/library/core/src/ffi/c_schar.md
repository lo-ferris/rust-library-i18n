Equivalent to C's `signed char` type. <br>等效于 C 的 `signed char` 类型。<br>

This type will always be [`i8`], but is included for completeness. <br>此类型将始终为 [`i8`]，但出于完整性考虑将其包括在内。<br> It is defined as being a signed integer the same size as a C [`char`]. <br>它定义为与 C [`char`] 大小相同的有符号整数。<br>

[`char`]: c_char
