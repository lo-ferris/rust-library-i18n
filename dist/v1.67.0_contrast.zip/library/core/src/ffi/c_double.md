Equivalent to C's `double` type. <br>等效于 C 的 `double` 类型。<br>

This type will almost always be [`f64`], which is guaranteed to be an [IEEE 754 double-precision float] in Rust. <br>这种类型几乎总是 [`f64`]，在 Rust 中保证是 [IEEE 754 double-precision float]。<br> That said, the standard technically only guarantees that it be a floating-point number with at least the precision of a [`float`], and it may be `f32` or something entirely different from the IEEE-754 standard. <br>也就是说，该标准从技术上仅保证它是至少具有 [`float`] 精度的浮点数，并且它可以是 `f32` 或与 IEEE-754 标准完全不同的东西。<br>

[IEEE 754 double-precision float]: https://en.wikipedia.org/wiki/IEEE_754
[`float`]: c_float
