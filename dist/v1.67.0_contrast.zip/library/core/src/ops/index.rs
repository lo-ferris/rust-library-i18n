/// Used for indexing operations (`container[index]`) in immutable contexts. <br>用于在不可变上下文中索引操作 (`container[index]`)。<br>
///
/// `container[index]` is actually syntactic sugar for `*container.index(index)`, but only when used as an immutable value. <br>`container[index]` 实际上是 `*container.index(index)` 的语法糖，但仅在用作不可变值时使用。<br>
/// If a mutable value is requested, [`IndexMut`] is used instead. <br>如果请求一个可变值，则使用 [`IndexMut`]。<br>
/// This allows nice things such as `let value = v[index]` if the type of `value` implements [`Copy`]. <br>如果 `value` 的类型实现 [`Copy`]，则这允许使用诸如 `let value = v[index]` 之类的好东西。<br>
///
/// # Examples
///
/// The following example implements `Index` on a read-only `NucleotideCount` container, enabling individual counts to be retrieved with index syntax. <br>下面的示例在只读 `NucleotideCount` 容器上实现 `Index`，从而可以使用索引语法检索单个计数。<br>
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
#[const_trait]
pub trait Index<Idx: ?Sized> {
    /// The returned type after indexing. <br>索引后返回的类型。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Performs the indexing (`container[index]`) operation. <br>执行索引 (`container[index]`) 操作。<br>
    ///
    /// # Panics
    ///
    /// May panic if the index is out of bounds. <br>如果索引越界，则可能为 panic。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Used for indexing operations (`container[index]`) in mutable contexts. <br>用于可变上下文中的索引操作 (`container[index]`)。<br>
///
/// `container[index]` is actually syntactic sugar for `*container.index_mut(index)`, but only when used as a mutable value. <br>`container[index]` 实际上是 `*container.index_mut(index)` 的语法糖，但仅在用作可变值时使用。<br>
/// If an immutable value is requested, the [`Index`] trait is used instead. <br>如果请求一个不可变值，则使用 [`Index`] trait。<br>
/// This allows nice things such as `v[index] = value`. <br>这允许使用诸如 `v[index] = value` 之类的好东西。<br>
///
/// # Examples
///
/// A very simple implementation of a `Balance` struct that has two sides, where each can be indexed mutably and immutably. <br>`Balance` 结构体的非常简单的实现，它具有两个面，每个面都可以可变和不可变地进行索引。<br>
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {index:?}-side of balance immutably");
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {index:?}-side of balance mutably");
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // In this case, `balance[Side::Right]` is sugar for `*balance.index(Side::Right)`, since we are only *reading* `balance[Side::Right]`, not writing it. <br>在这种情况下，`balance[Side::Right]` 是 `*balance.index(Side::Right)` 的糖，因为我们只是* 读*`balance[Side::Right]`，而不是写 `balance[Side::Right]`。<br>
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // However, in this case `balance[Side::Left]` is sugar for `*balance.index_mut(Side::Left)`, since we are writing `balance[Side::Left]`. <br>但是，在这种情况下，`balance[Side::Left]` 是 `*balance.index_mut(Side::Left)` 的糖，因为我们正在编写 `balance[Side::Left]`。<br>
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
#[const_trait]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Performs the mutable indexing (`container[index]`) operation. <br>执行可变索引 (`container[index]`) 操作。<br>
    ///
    /// # Panics
    ///
    /// May panic if the index is out of bounds. <br>如果索引越界，则可能为 panic。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}
