use core::ffi::c_void;
use core::fmt;

/// Inspects the current call-stack, passing all active frames into the closure provided to calculate a stack trace. <br>检查当前调用栈，将所有活动帧传递到提供的闭包中以计算栈跟踪。<br>
///
/// This function is the workhorse of this library in calculating the stack traces for a program. <br>该函数是该库在计算程序的栈跟踪时的主力。<br> The given closure `cb` is yielded instances of a `Frame` which represent information about that call frame on the stack. <br>给定的闭包 `cb` 是 `Frame` 的实例，这些实例表示有关栈上该调用帧的信息。<br>
/// The closure is yielded frames in a top-down fashion (most recently called functions first). <br>闭包以自上而下的方式生成框架 (最近称为函数优先)。<br>
///
/// The closure's return value is an indication of whether the backtrace should continue. <br>闭包的返回值指示回溯是否应继续。<br> A return value of `false` will terminate the backtrace and return immediately. <br>`false` 的返回值将终止回溯并立即返回。<br>
///
/// Once a `Frame` is acquired you will likely want to call `backtrace::resolve` to convert the `ip` (instruction pointer) or symbol address to a `Symbol` through which the name and/or filename/line number can be learned. <br>一旦获取了 `Frame`，您可能希望调用 `backtrace::resolve` 将 `ip` (指令指针) 或符号地址转换为 `Symbol`，通过该 `Symbol` 可以了解名称或者文件名 / 行号。<br>
///
///
/// Note that this is a relatively low-level function and if you'd like to, for example, capture a backtrace to be inspected later, then the `Backtrace` type may be more appropriate. <br>请注意，这是一个相对较为灵活的函数，例如，如果您想捕获回溯以供以后检查，则 `Backtrace` 类型可能更合适。<br>
///
/// # Required features <br>要求的特性<br>
///
/// This function requires the `std` feature of the `backtrace` crate to be enabled, and the `std` feature is enabled by default. <br>此函数需要启用 `backtrace` crate 的 `std` 特性，并且默认启用 `std` 特性。<br>
///
/// # Panics
///
/// This function strives to never panic, but if the `cb` provided panics then some platforms will force a double panic to abort the process. <br>这个函数尽量避免 panic，但是如果 `cb` 提供了 panics，则某些平台将强制使用双 panic 来终止进程。<br>
/// Some platforms use a C library which internally uses callbacks which cannot be unwound through, so panicking from `cb` may trigger a process abort. <br>某些平台使用 C 库，该库在内部使用无法解开的回调，因此从 `cb` panic 可能会触发进程终止。<br>
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continue the backtrace <br>继续回溯<br>
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Same as `trace`, only unsafe as it's unsynchronized. <br>与 `trace` 相同，只是不安全，因为它未同步。<br>
///
/// This function does not have synchronization guarantees but is available when the `std` feature of this crate isn't compiled in. <br>这个函数没有同步保证，但是当这个 crate 的 `std` 特性没有被编译时，这个函数是可用的。<br>
/// See the `trace` function for more documentation and examples. <br>有关更多文档和示例，请参见 `trace` 函数。<br>
///
/// # Panics
///
/// See information on `trace` for caveats on `cb` panicking. <br>有关 `cb` panic 的警告，请参见 `trace` 上的信息。<br>
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait representing one frame of a backtrace, yielded to the `trace` function of this crate. <br>代表回溯的一帧的 trait 产生给此 crate 的 `trace` 函数。<br>
///
/// The tracing function's closure will be yielded frames, and the frame is virtually dispatched as the underlying implementation is not always known until runtime. <br>跟踪函数的闭包将是产生的帧，并且实际上将分派该帧，因为直到运行时才知道底层实现。<br>
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Returns the current instruction pointer of this frame. <br>返回此帧的当前指令指针。<br>
    ///
    /// This is normally the next instruction to execute in the frame, but not all implementations list this with 100% accuracy (but it's generally pretty close). <br>通常，这是在框架中执行的下一条指令，但并非所有实现都以 100% 的精度列出该指令 (但通常非常接近)。<br>
    ///
    ///
    /// It is recommended to pass this value to `backtrace::resolve` to turn it into a symbol name. <br>建议将此值传递给 `backtrace::resolve`，以将其转换为符号名称。<br>
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Returns the current stack pointer of this frame. <br>返回此帧的当前栈指针。<br>
    ///
    /// In the case that a backend cannot recover the stack pointer for this frame, a null pointer is returned. <br>如果后端无法恢复该帧的栈指针，则返回空指针。<br>
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Returns the starting symbol address of the frame of this function. <br>返回此函数框架的起始符号地址。<br>
    ///
    /// This will attempt to rewind the instruction pointer returned by `ip` to the start of the function, returning that value. <br>这将尝试将 `ip` 返回的指令指针回退到函数的开头，并返回该值。<br>
    ///
    /// In some cases, however, backends will just return `ip` from this function. <br>但是，在某些情况下，后端只会从此函数返回 `ip`。<br>
    ///
    /// The returned value can sometimes be used if `backtrace::resolve` failed on the `ip` given above. <br>如果 `backtrace::resolve` 在上面给定的 `ip` 上失败，则有时可以使用返回值。<br>
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Returns the base address of the module to which the frame belongs. <br>返回框架所属模块的基地址。<br>
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // This needs to come first, to ensure that Miri takes priority over the host platform <br>首先需要确保 Miri 优先于主机平台<br>
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // only used in dbghelp symbolize <br>仅在 dbghelp 中使用象征<br>
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}
