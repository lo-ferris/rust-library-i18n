#![stable(feature = "wake_trait", since = "1.51.0")]

//! Types and Traits for working with asynchronous tasks. <br>类型和 Traits 用于处理异步任务。<br>
//!
//! **Note**: This module is only available on platforms that support atomic loads and stores of pointers. <br>该模块仅在支持原子加载和指针存储的平台上可用。<br>
//! This may be detected at compile time using `#[cfg(target_has_atomic = "ptr")]`. <br>这可以在编译时使用 `#[cfg(target_has_atomic = "ptr")]` 检测到。<br>
//!

use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// The implementation of waking a task on an executor. <br>在执行程序上唤醒任务的实现。<br>
///
/// This trait can be used to create a [`Waker`]. <br>一个可以用于创建 [`Waker`] 的 trait。<br>
/// An executor can define an implementation of this trait, and use that to construct a Waker to pass to the tasks that are executed on that executor. <br>执行者可以定义此 trait 的实现，并使用它来构造一个 Waker 以传递给在该执行者上执行的任务。<br>
///
/// This trait is a memory-safe and ergonomic alternative to constructing a [`RawWaker`]. <br>这个 trait 是构建 [`RawWaker`] 的一种内存安全且符合人体工程学的替代方案。<br>
/// It supports the common executor design in which the data used to wake up a task is stored in an [`Arc`]. <br>它支持通用执行程序设计，其中用于唤醒任务的数据存储在 [`Arc`] 中。<br>
/// Some executors (especially those for embedded systems) cannot use this API, which is why [`RawWaker`] exists as an alternative for those systems. <br>某些执行程序 (尤其是嵌入式系统的执行程序) 无法使用此 API，这就是为什么存在 [`RawWaker`] 来替代这些系统的原因。<br>
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// A basic `block_on` function that takes a future and runs it to completion on the current thread. <br>一个基本的 `block_on` 函数，它采用 future 并在当前线程上运行该函数以使其完成。<br>
///
/// **Note:** This example trades correctness for simplicity. <br>本示例以正确性为代价。<br>
/// In order to prevent deadlocks, production-grade implementations will also need to handle intermediate calls to `thread::unpark` as well as nested invocations. <br>为了防止死锁，生产级实现也将需要处理对 `thread::unpark` 的中间调用以及嵌套调用。<br>
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// A waker that wakes up the current thread when called. <br>一个在调用时唤醒当前线程的唤醒器。<br>
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Run a future to completion on the current thread. <br>在当前线程上运行 future 以完成操作。<br>
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin the future so it can be polled. <br>固定 future，以便可以对其进行轮询。<br>
///     let mut fut = Box::pin(fut);
///
///     // Create a new context to be passed to the future. <br>创建一个要传递给 future 的新上下文。<br>
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Run the future to completion. <br>运行 future 直到完成操作。<br>
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Wake this task. <br>唤醒此任务。<br>
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Wake this task without consuming the waker. <br>在不消耗唤醒程序的情况下唤醒此任务。<br>
    ///
    /// If an executor supports a cheaper way to wake without consuming the waker, it should override this method. <br>如果执行程序支持一种更便宜的唤醒方式而不消耗唤醒程序，则它应该重写此方法。<br>
    /// By default, it clones the [`Arc`] and calls [`wake`] on the clone. <br>默认情况下，它将克隆 [`Arc`] 并在克隆上调用 [`wake`]。<br>
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    /// Use a `Wake`-able type as a `Waker`. <br>使用 `Wake` 类型作为 `Waker`。<br>
    ///
    /// No heap allocations or atomic operations are used for this conversion. <br>此转换不使用堆分配或原子操作。<br>
    fn from(waker: Arc<W>) -> Waker {
        // SAFETY: This is safe because raw_waker safely constructs a RawWaker from Arc<W>. <br>这是安全的，因为 raw_waker 从 Arc<W> 安全地构造了 RawWaker。<br>
        //
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    /// Use a `Wake`-able type as a `RawWaker`. <br>使用 `Wake` 类型作为 `RawWaker`。<br>
    ///
    /// No heap allocations or atomic operations are used for this conversion. <br>此转换不使用堆分配或原子操作。<br>
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: This private function for constructing a RawWaker is used, rather than inlining this into the `From<Arc<W>> for RawWaker` impl, to ensure that the safety of `From<Arc<W>> for Waker` does not depend on the correct trait dispatch - instead both impls call this function directly and explicitly. <br>使用此私有函数来构造 RawWaker，而不是将其内联到 `From<Arc<W>> for RawWaker` impl 中，以确保 `From<Arc<W>> for Waker` 的安全性不依赖于正确的 trait 调度 - 而是都直接或显式地调用此函数。<br>
//
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Increment the reference count of the arc to clone it. <br>增加 Arc 的引用计数以克隆它。<br>
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wake by value, moving the Arc into the Wake::wake function <br>按值唤醒，将 Arc 移到 Wake::wake 函数中<br>
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wake by reference, wrap the waker in ManuallyDrop to avoid dropping it <br>通过引用唤醒，将唤醒器包裹在 ManuallyDrop 中，以避免被丢弃<br>
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Decrement the reference count of the Arc on drop <br>丢弃时减少 Arc 的引用计数<br>
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}
