#![unstable(feature = "raw_vec_internals", reason = "unstable const warnings", issue = "none")]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit, SizedTypeProperties};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

#[cfg(not(no_global_oom_handling))]
use crate::alloc::handle_alloc_error;
use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::collections::TryReserveErrorKind::*;

#[cfg(test)]
mod tests;

#[cfg(not(no_global_oom_handling))]
enum AllocInit {
    /// The contents of the new memory are uninitialized. <br>新存储器的内容未初始化。<br>
    Uninitialized,
    /// The new memory is guaranteed to be zeroed. <br>确保将新内存清零。<br>
    Zeroed,
}

/// A low-level utility for more ergonomically allocating, reallocating, and deallocating a buffer of memory on the heap without having to worry about all the corner cases involved. <br>一个底层的实用程序，用于更符合人体工程学地分配、重新分配和释放堆上的内存缓冲区，而不必担心所涉及的所有极端情况。<br>
///
/// This type is excellent for building your own data structures like Vec and VecDeque. <br>此类型非常适合构建自己的数据结构，例如 Vec 和 VecDeque。<br>
/// In particular: <br>特别是：<br>
///
/// * Produces `Unique::dangling()` on zero-sized types. <br>在零大小类型上生成 `Unique::dangling()`。<br>
/// * Produces `Unique::dangling()` on zero-length allocations. <br>在零长度分配上产生 `Unique::dangling()`。<br>
/// * Avoids freeing `Unique::dangling()`. <br>避免释放 `Unique::dangling()`。<br>
/// * Catches all overflows in capacity computations (promotes them to "capacity overflow" panics). <br>捕获容量计算中的所有溢出 (将它们提升为 "容量溢出" panics)。<br>
/// * Guards against 32-bit systems allocating more than isize::MAX bytes. <br>防止 32 位系统分配超过 `isize::MAX` 字节。<br>
/// * Guards against overflowing your length. <br>防止您的长度溢出。<br>
/// * Calls `handle_alloc_error` for fallible allocations. <br>调用 `handle_alloc_error` 进行错误分配。<br>
/// * Contains a `ptr::Unique` and thus endows the user with all related benefits. <br>包含 `ptr::Unique`，因此为用户提供了所有相关的好处。<br>
/// * Uses the excess returned from the allocator to use the largest available capacity. <br>使用分配器返回的多余资源来使用最大可用容量。<br>
///
/// This type does not in anyway inspect the memory that it manages. <br>无论如何，此类型不会检查它管理的内存。<br> When dropped it *will* free its memory, but it *won't* try to drop its contents. <br>当丢弃后，它会释放其内存，但不会尝试丢弃其内容。<br>
/// It is up to the user of `RawVec` to handle the actual things *stored* inside of a `RawVec`. <br>由 `RawVec` 的用户来处理存储在 `RawVec` 中的实际内容。<br>
///
/// Note that the excess of a zero-sized types is always infinite, so `capacity()` always returns `usize::MAX`. <br>注意，零大小类型的余量始终是无限的，因此 `capacity()` 始终返回 `usize::MAX`。<br>
/// This means that you need to be careful when round-tripping this type with a `Box<[T]>`, since `capacity()` won't yield the length. <br>这意味着与 `Box<[T]>` 进行双向交互时需要小心，因为 `capacity()` 不会产生长度。<br>
///
///
#[allow(missing_debug_implementations)]
pub(crate) struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): This exists because stable `const fn` can only call stable `const fn`, so they cannot call `Self::new()`. <br>之所以存在，是因为稳定的 `const fn` 只能调用稳定的 `const fn`，所以他们不能调用`Self::new()`。<br>
    ///
    /// If you change `RawVec<T>::new` or dependencies, please take care to not introduce anything that would truly const-call something unstable. <br>如果您更改 `RawVec<T>::new` 或依赖项，请注意不要引入任何真正不稳定的东西。<br>
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Creates the biggest possible `RawVec` (on the system heap) without allocating. <br>创建最大的 `RawVec` (在系统堆上) 而不分配。<br>
    /// If `T` has positive size, then this makes a `RawVec` with capacity `0`. <br>如果 `T` 的大小为正，则表示 `RawVec` 的容量为 `0`。<br>
    /// If `T` is zero-sized, then it makes a `RawVec` with capacity `usize::MAX`. <br>如果 `T` 的大小为零，则生成一个容量为 `usize::MAX` 的 `RawVec`。<br>
    /// Useful for implementing delayed allocation. <br>对于实现延迟分配很有用。<br>
    ///
    #[must_use]
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Creates a `RawVec` (on the system heap) with exactly the capacity and alignment requirements for a `[T; capacity]`. <br>创建 `RawVec` (在系统堆上)，该 `RawVec` 具有 `[T; capacity]` 的确切容量和对齐要求。<br>
    /// This is equivalent to calling `RawVec::new` when `capacity` is `0` or `T` is zero-sized. <br>这等效于 `capacity` 为 `0` 或 `T` 为零大小时调用 `RawVec::new`。<br>
    /// Note that if `T` is zero-sized this means you will *not* get a `RawVec` with the requested capacity. <br>请注意，如果 `T` 的大小为零，这意味着您将无法获得具有请求容量的 `RawVec`。<br>
    ///
    /// # Panics
    ///
    /// Panics if the requested capacity exceeds `isize::MAX` bytes. <br>如果请求的容量超过 `isize::MAX` 字节，就会出现 panics。<br>
    ///
    /// # Aborts
    ///
    /// Aborts on OOM. <br>在 OOM 上中止。<br>
    ///
    ///
    #[cfg(not(any(no_global_oom_handling, test)))]
    #[must_use]
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Like `with_capacity`, but guarantees the buffer is zeroed. <br>类似于 `with_capacity`，但保证缓冲区为零。<br>
    #[cfg(not(any(no_global_oom_handling, test)))]
    #[must_use]
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs are dumb. <br>微小的 Vecs 是愚蠢的。<br> Skip to: <br>跳转到：<br>
    // - 8 if the element size is 1, because any heap allocators is likely to round up a request of less than 8 bytes to at least 8 bytes. <br>如果元素大小为 1，则为 8，因为任何堆分配器都可能会将少于 8 个字节的请求舍入为至少 8 个字节。<br>
    //
    // - 4 if elements are moderate-sized (<= 1 KiB). <br>如果元素大小适中 (<= 1 KiB)，则为 4。<br>
    // - 1 otherwise, to avoid wasting too much space for very short Vecs. <br>1 否则，为了避免为非常短的 Vecs 浪费太多空间。<br>
    pub(crate) const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Like `new`, but parameterized over the choice of allocator for the returned `RawVec`. <br>类似于 `new`，但是在返回的 `RawVec` 的分配器选择上进行了参数化。<br>
    ///
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` means "unallocated".  zero-sized types are ignored. <br>忽略大小为零的类型。<br>
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Like `with_capacity`, but parameterized over the choice of allocator for the returned `RawVec`. <br>类似于 `with_capacity`，但是在返回的 `RawVec` 的分配器选择上进行了参数化。<br>
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Like `with_capacity_zeroed`, but parameterized over the choice of allocator for the returned `RawVec`. <br>类似于 `with_capacity_zeroed`，但是在返回的 `RawVec` 的分配器选择上进行了参数化。<br>
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Converts the entire buffer into `Box<[MaybeUninit<T>]>` with the specified `len`. <br>使用指定的 `len` 将整个缓冲区转换为 `Box<[MaybeUninit<T>]>`。<br>
    ///
    /// Note that this will correctly reconstitute any `cap` changes that may have been performed. <br>请注意，这将正确地重构可能已执行的所有 `cap` 更改。<br> (See description of type for details.) <br>(有关详细信息，请参见类型说明。)<br>
    ///
    /// # Safety
    ///
    /// * `len` must be greater than or equal to the most recently requested capacity, and <br>`len` 必须大于或等于最近请求的容量，并且<br>
    /// * `len` must be less than or equal to `self.capacity()`. <br>`len` 必须小于或等于 `self.capacity()`。<br>
    ///
    /// Note, that the requested capacity and `self.capacity()` could differ, as an allocator could overallocate and return a greater memory block than requested. <br>请注意，请求的容量和 `self.capacity()` 可能有所不同，因为分配器可能会整合并返回比请求更大的内存块。<br>
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-check one half of the safety requirement (we cannot check the other half). <br>仔细检查安全要求的一半 (我们不能检查另一半)。<br>
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    #[cfg(not(no_global_oom_handling))]
    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        // Don't allocate here because `Drop` will not deallocate when `capacity` is 0. <br>不要在这里分配，因为当 `capacity` 为 0 时，`Drop` 不会释放。<br>
        if T::IS_ZST || capacity == 0 {
            Self::new_in(alloc)
        } else {
            // We avoid `unwrap_or_else` here because it bloats the amount of LLVM IR generated. <br>我们在这里避免使用 `unwrap_or_else`，因为它会使生成的 LLVM IR 数量膨胀。<br>
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            // Allocators currently return a `NonNull<[u8]>` whose length matches the size requested. <br>分配器当前返回一个 `NonNull<[u8]>`，其长度与请求的大小相匹配。<br>
            // If that ever changes, the capacity here should change to `ptr.len() / mem::size_of::<T>()`. <br>如果情况发生变化，此处的容量应更改为 `ptr.len() / mem::size_of::<T>()`。<br>
            //
            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: capacity,
                alloc,
            }
        }
    }

    /// Reconstitutes a `RawVec` from a pointer, capacity, and allocator. <br>从指针，容量和分配器重构 `RawVec`。<br>
    ///
    /// # Safety
    ///
    /// The `ptr` must be allocated (via the given allocator `alloc`), and with the given `capacity`. <br>必须通过给定的 `capacity` 分配 `ptr` (通过给定的分配器 `alloc`)。<br>
    /// The `capacity` cannot exceed `isize::MAX` for sized types. <br>对于大小类型，`capacity` 不能超过 `isize::MAX`。<br>
    /// (only a concern on 32-bit systems). <br>(仅在 32 位系统上需要考虑)。<br>
    /// ZST vectors may have a capacity up to `usize::MAX`. <br>ZST vectors 的容量最多为 `usize::MAX`。<br>
    /// If the `ptr` and `capacity` come from a `RawVec` created via `alloc`, then this is guaranteed. <br>如果 `ptr` 和 `capacity` 来自通过 `alloc` 创建的 `RawVec`，则可以保证。<br>
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Gets a raw pointer to the start of the allocation. <br>获取分配开始处的裸指针。<br>
    /// Note that this is `Unique::dangling()` if `capacity == 0` or `T` is zero-sized. <br>请注意，如果 `capacity == 0` 或 `T` 的大小为零，则为 `Unique::dangling()`。<br>
    /// In the former case, you must be careful. <br>在前一种情况下，您必须小心。<br>
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Gets the capacity of the allocation. <br>获取分配的容量。<br>
    ///
    /// This will always be `usize::MAX` if `T` is zero-sized. <br>如果 `T` 的大小为零，则它将始终为 `usize::MAX`。<br>
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if T::IS_ZST { usize::MAX } else { self.cap }
    }

    /// Returns a shared reference to the allocator backing this `RawVec`. <br>返回支持此 `RawVec` 的分配器的共享引用。<br>
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if T::IS_ZST || self.cap == 0 {
            None
        } else {
            // We have an allocated chunk of memory, so we can bypass runtime checks to get our current layout. <br>我们有一块已分配的内存，因此我们可以绕过运行时检查来获取当前的布局。<br>
            //
            unsafe {
                let layout = Layout::array::<T>(self.cap).unwrap_unchecked();
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Ensures that the buffer contains at least enough space to hold `len + additional` elements. <br>确保缓冲区至少包含足够的空间来容纳 `len + additional` 元素。<br>
    /// If it doesn't already have enough capacity, will reallocate enough space plus comfortable slack space to get amortized *O*(1) behavior. <br>如果还没有足够的容量，则将重新分配足够的空间以及舒适的松弛空间，以摊销 *O*(1) 行为。<br>
    ///
    /// Will limit this behavior if it would needlessly cause itself to panic. <br>如果会不必要地使其自身成为 panic，则将限制此行为。<br>
    ///
    /// If `len` exceeds `self.capacity()`, this may fail to actually allocate the requested space. <br>如果 `len` 超过 `self.capacity()`，则可能无法实际分配请求的空间。<br>
    /// This is not really unsafe, but the unsafe code *you* write that relies on the behavior of this function may break. <br>这并不是真的不安全，但是依赖于这个函数行为的不安全代码可能会被破坏。<br>
    ///
    /// This is ideal for implementing a bulk-push operation like `extend`. <br>这是实现 `extend` 之类的批量推送操作的理想选择。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity exceeds `isize::MAX` bytes. <br>如果新容量超过 `isize::MAX` 字节，就会出现 panics。<br>
    ///
    /// # Aborts
    ///
    /// Aborts on OOM. <br>在 OOM 上中止。<br>
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    pub fn reserve(&mut self, len: usize, additional: usize) {
        // Callers expect this function to be very cheap when there is already sufficient capacity. <br>当已经有足够的容量时，调用者希望这个函数非常便宜。<br>
        // Therefore, we move all the resizing and error-handling logic from grow_amortized and handle_reserve behind a call, while making sure that this function is likely to be inlined as just a comparison and a call if the comparison fails. <br>因此，我们将所有的调整大小和错误处理逻辑从 grow_amortized 和 handle_reserve 移到一个调用之后，同时确保如果比较失败，这个函数很可能被内联为一个比较和一个调用。<br>
        //
        //
        #[cold]
        fn do_reserve_and_handle<T, A: Allocator>(
            slf: &mut RawVec<T, A>,
            len: usize,
            additional: usize,
        ) {
            handle_reserve(slf.grow_amortized(len, additional));
        }

        if self.needs_to_grow(len, additional) {
            do_reserve_and_handle(self, len, additional);
        }
    }

    /// A specialized version of `reserve()` used only by the hot and oft-instantiated `Vec::push()`, which does its own capacity check. <br>`reserve()` 的专用版本，仅由 hot 且经常实例化的  `Vec::push()` 使用，它会进行自己的容量检查。<br>
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline(never)]
    pub fn reserve_for_push(&mut self, len: usize) {
        handle_reserve(self.grow_amortized(len, 1));
    }

    /// The same as `reserve`, but returns on errors instead of panicking or aborting. <br>与 `reserve` 相同，但在出错时返回，而不是 panic 或中止。<br>
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Ensures that the buffer contains at least enough space to hold `len + additional` elements. <br>确保缓冲区至少包含足够的空间来容纳 `len + additional` 元素。<br>
    /// If it doesn't already, will reallocate the minimum possible amount of memory necessary. <br>如果尚未分配，将重新分配所需的最小可能内存量。<br>
    /// Generally this will be exactly the amount of memory necessary, but in principle the allocator is free to give back more than we asked for. <br>通常，这恰好是必需的内存量，但是原则上分配器可以自由地提供比我们要求的更多的内存。<br>
    ///
    ///
    /// If `len` exceeds `self.capacity()`, this may fail to actually allocate the requested space. <br>如果 `len` 超过 `self.capacity()`，则可能无法实际分配请求的空间。<br>
    /// This is not really unsafe, but the unsafe code *you* write that relies on the behavior of this function may break. <br>这并不是真的不安全，但是依赖于这个函数行为的不安全代码可能会被破坏。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity exceeds `isize::MAX` bytes. <br>如果新容量超过 `isize::MAX` 字节，就会出现 panics。<br>
    ///
    /// # Aborts
    ///
    /// Aborts on OOM. <br>在 OOM 上中止。<br>
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// The same as `reserve_exact`, but returns on errors instead of panicking or aborting. <br>与 `reserve_exact` 相同，但在出错时返回，而不是 panic 或中止。<br>
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Shrinks the buffer down to the specified capacity. <br>将缓冲区缩小到指定的容量。<br>
    /// If the given amount is 0, actually completely deallocates. <br>如果给定的数量为 0，则实际上完全释放。<br>
    ///
    /// # Panics
    ///
    /// Panics if the given amount is *larger* than the current capacity. <br>如果给定数量大于当前容量，就会出现 panic。<br>
    ///
    /// # Aborts
    ///
    /// Aborts on OOM. <br>在 OOM 上中止。<br>
    #[cfg(not(no_global_oom_handling))]
    pub fn shrink_to_fit(&mut self, cap: usize) {
        handle_reserve(self.shrink(cap));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Returns if the buffer needs to grow to fulfill the needed extra capacity. <br>如果缓冲区需要增长才能满足所需的额外容量，则返回。<br>
    /// Mainly used to make inlining reserve-calls possible without inlining `grow`. <br>主要用于无需内联 `grow` 就可以进行内联预留调用。<br>
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn set_ptr_and_cap(&mut self, ptr: NonNull<[u8]>, cap: usize) {
        // Allocators currently return a `NonNull<[u8]>` whose length matches the size requested. <br>分配器当前返回一个 `NonNull<[u8]>`，其长度与请求的大小相匹配。<br>
        // If that ever changes, the capacity here should change to `ptr.len() / mem::size_of::<T>()`. <br>如果情况发生变化，此处的容量应更改为 `ptr.len() / mem::size_of::<T>()`。<br>
        //
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = cap;
    }

    // This method is usually instantiated many times. <br>此方法通常实例化很多次。<br> So we want it to be as small as possible, to improve compile times. <br>因此，我们希望它尽可能小，以缩短编译时间。<br>
    // But we also want as much of its contents to be statically computable as possible, to make the generated code run faster. <br>但是我们也希望它的尽可能多的内容是静态可计算的，以使生成的代码运行得更快。<br>
    // Therefore, this method is carefully written so that all of the code that depends on `T` is within it, while as much of the code that doesn't depend on `T` as possible is in functions that are non-generic over `T`. <br>因此，精心编写此方法，以便所有依赖 `T` 的代码都在其中，而尽可能多的不依赖 `T` 的代码都在非 `T` 泛型的函数中。<br>
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // This is ensured by the calling contexts. <br>这是通过调用上下文来确保的。<br>
        debug_assert!(additional > 0);

        if T::IS_ZST {
            // Since we return a capacity of `usize::MAX` when `elem_size` is <br>因为当 `elem_size` 为 X 时我们返回 `usize::MAX` 的容量<br>
            // 0, getting to here necessarily means the `RawVec` is overfull. <br>0，到达此处必定意味着 `RawVec` 已满。<br>
            return Err(CapacityOverflow.into());
        }

        // Nothing we can really do about these checks, sadly. <br>不幸的是，我们对这些检查无能为力。<br>
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // This guarantees exponential growth. <br>这保证了指数增长。<br>
        // The doubling cannot overflow because `cap <= isize::MAX` and the type of `cap` is `usize`. <br>倍增不会溢出，因为 `cap <= isize::MAX` 和 `cap` 的类型是 `usize`。<br>
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is non-generic over `T`. <br>`finish_grow` 是非泛型的，而不是 `T`。<br>
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr_and_cap(ptr, cap);
        Ok(())
    }

    // The constraints on this method are much the same as those on `grow_amortized`, but this method is usually instantiated less often so it's less critical. <br>此方法的约束与 `grow_amortized` 上的约束大致相同，但是此方法通常实例化的频率较低，因此不太重要。<br>
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if T::IS_ZST {
            // Since we return a capacity of `usize::MAX` when the type size is <br>由于我们在类型大小为时返回 `usize::MAX` 的容量<br>
            // 0, getting to here necessarily means the `RawVec` is overfull. <br>0，到达此处必定意味着 `RawVec` 已满。<br>
            return Err(CapacityOverflow.into());
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` is non-generic over `T`. <br>`finish_grow` 是非泛型的，而不是 `T`。<br>
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr_and_cap(ptr, cap);
        Ok(())
    }

    #[cfg(not(no_global_oom_handling))]
    fn shrink(&mut self, cap: usize) -> Result<(), TryReserveError> {
        assert!(cap <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };

        let ptr = unsafe {
            // `Layout::array` cannot overflow here because it would have overflowed earlier when capacity was larger. <br>`Layout::array` 在这里不能溢出，因为容量更大时，它会更早溢出。<br>
            //
            let new_layout = Layout::array::<T>(cap).unwrap_unchecked();
            self.alloc
                .shrink(ptr, layout, new_layout)
                .map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })?
        };
        self.set_ptr_and_cap(ptr, cap);
        Ok(())
    }
}

// This function is outside `RawVec` to minimize compile times. <br>该函数在 `RawVec` 外部，以最大程度地减少编译时间。<br> See the comment above `RawVec::grow_amortized` for details. <br>有关详细信息，请参见 `RawVec::grow_amortized` 上方的注释。<br>
// (The `A` parameter isn't significant, because the number of different `A` types seen in practice is much smaller than the number of `T` types.) <br>(`A` 参数并不重要，因为实际上看到的不同 `A` 类型的数量比 `T` 类型的数量小得多。)<br>
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Check for the error here to minimize the size of `RawVec::grow_*`. <br>在此处检查错误，以最小化 `RawVec::grow_*` 的大小。<br>
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // The allocator checks for alignment equality <br>分配器检查对齐是否相等<br>
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () }.into())
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Frees the memory owned by the `RawVec` *without* trying to drop its contents. <br>释放 `RawVec` 所拥有的内存，而无需尝试丢弃其内容。<br>
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central function for reserve error handling. <br>中央函数，用于保留错误处理。<br>
#[cfg(not(no_global_oom_handling))]
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result.map_err(|e| e.kind()) {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// We need to guarantee the following: <br>我们需要保证以下几点：<br>
// * We don't ever allocate `> isize::MAX` byte-size objects. <br>我们永远不会分配 `> isize::MAX` 字节大小的对象。<br>
// * We don't overflow `usize::MAX` and actually allocate too little. <br>我们不会溢出 `usize::MAX`，而实际上分配得太少。<br>
//
// On 64-bit we just need to check for overflow since trying to allocate `> isize::MAX` bytes will surely fail. <br>在 64 位上，我们只需要检查溢出，因为尝试分配 `> isize::MAX` 字节肯定会失败。<br>
// On 32-bit and 16-bit we need to add an extra guard for this in case we're running on a platform which can use all 4GB in user-space, e.g., PAE or x32. <br>在 32 位和 16 位上，我们需要为此添加一个额外的保护措施，以防我们运行在可以使用 user-space 中所有 4GB 的平台上，例如 PAE 或 x32。<br>
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow.into())
    } else {
        Ok(())
    }
}

// One central function responsible for reporting capacity overflows. <br>一个负责报告容量溢出的中央函数。<br>
// This'll ensure that the code generation related to these panics is minimal as there's only one location which panics rather than a bunch throughout the module. <br>这将确保与这些 panics 相关的代码生成最少，因为在整个模块中只有一个位置 panics 而不是一堆。<br>
//
#[cfg(not(no_global_oom_handling))]
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}
