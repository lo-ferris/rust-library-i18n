use crate::alloc::{Allocator, Global};
use core::mem::{self, ManuallyDrop};
use core::ptr;
use core::slice;

use super::Vec;

/// An iterator which uses a closure to determine if an element should be removed. <br>使用闭包确定是否应删除元素的迭代器。<br>
///
/// This struct is created by [`Vec::drain_filter`]. <br>该结构体由 [`Vec::drain_filter`] 创建。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// The index of the item that will be inspected by the next call to `next`. <br>`next` 的下一次调用将检查的项的索引。<br>
    pub(super) idx: usize,
    /// The number of items that have been drained (removed) thus far. <br>到目前为止已耗尽 (removed) 的项数。<br>
    pub(super) del: usize,
    /// The original length of `vec` prior to draining. <br>draining 之前 `vec` 的原始长度。<br>
    pub(super) old_len: usize,
    /// The filter test predicate. <br>过滤器测试谓词。<br>
    pub(super) pred: F,
    /// A flag that indicates a panic has occurred in the filter test predicate. <br>指示 panic 的标志已出现在过滤器测试谓词中。<br>
    /// This is used as a hint in the drop implementation to prevent consumption of the remainder of the `DrainFilter`. <br>这在丢弃实现中用作一个提示，以防止消耗 `DrainFilter` 的其余部分。<br>
    /// Any unprocessed items will be backshifted in the `vec`, but no further items will be dropped or tested by the filter predicate. <br>任何未处理的项目将在 `vec` 中后移，但过滤谓词不会丢弃或测试其他任何项目。<br>
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Returns a reference to the underlying allocator. <br>返回底层分配器的引用。<br>
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }

    /// Keep unyielded elements in the source `Vec`. <br>在源 `Vec` 中保留未屈服的元素。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// #![feature(drain_keep_rest)]
    ///
    /// let mut vec = vec!['a', 'b', 'c'];
    /// let mut drain = vec.drain_filter(|_| true);
    ///
    /// assert_eq!(drain.next().unwrap(), 'a');
    ///
    /// // This call keeps 'b' and 'c' in the vec. <br>这个调用将 'b' 和 'c' 保存在 vec 中。<br>
    /// drain.keep_rest();
    ///
    /// // If we wouldn't call `keep_rest()`, `vec` would be empty. <br>如果我们不调用 `keep_rest()`，`vec` 将为空。<br>
    /////
    /// assert_eq!(vec, ['b', 'c']);
    /// ```
    #[unstable(feature = "drain_keep_rest", issue = "101122")]
    pub fn keep_rest(self) {
        // At this moment layout looks like this: <br>此时布局如下所示:<br>
        //
        //  _____________________/-- old_len
        // /                     \
        // [kept] [yielded] [tail] \_______/ ^-- idx \-- del
        //
        // Normally `Drop` impl would drop [tail] (via .for_each(drop), ie still calling `pred`) <br>通常 `Drop` impl 会丢弃 [tail] (通过 .for_each(drop), ie still calling `pred`)<br>
        //
        // 1. Move [tail] after [kept] <br>在 [kept] 之后移动 [tail]<br>
        // 2. Update length of the original vec to `old_len - del` a. <br>将原始 vec 的长度更新为 `old_len - del` a.<br>
        // In case of ZST, this is the only thing we want to do <br>对于 ZST，这是我们唯一想做的事情<br>
        // 3.
        // Do *not* drop self, as everything is put in a consistent state already, there is nothing to do <br>不要*不要*丢弃自己，因为一切都已经处于一致状态，没有什么可做的<br>
        //
        let mut this = ManuallyDrop::new(self);

        unsafe {
            // ZSTs have no identity, so we don't need to move them around. <br>ZST 没有身份，所以我们不需要移动它们。<br>
            let needs_move = mem::size_of::<T>() != 0;

            if needs_move && this.idx < this.old_len && this.del > 0 {
                let ptr = this.vec.as_mut_ptr();
                let src = ptr.add(this.idx);
                let dst = src.sub(this.del);
                let tail_len = this.old_len - this.idx;
                src.copy_to(dst, tail_len);
            }

            let new_len = this.old_len - this.del;
            this.vec.set_len(new_len);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Update the index *after* the predicate is called. <br>在谓词被调用之后更新索引。<br>
                // If the index is updated prior and the predicate panics, the element at this index would be leaked. <br>如果索引先于谓词 panics 进行更新，则该索引处的元素将被泄漏。<br>
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // This is a pretty messed up state, and there isn't really an obviously right thing to do. <br>这是一个非常混乱的状态，实际上并没有一件明显正确的事情要做。<br>
                        // We don't want to keep trying to execute `pred`, so we just backshift all the unprocessed elements and tell the vec that they still exist. <br>我们不想继续尝试执行 `pred`，因此我们只回移了所有未处理的元素，并告诉 vec 它们仍然存在。<br>
                        //
                        // The backshift is required to prevent a double-drop of the last successfully drained item prior to a panic in the predicate. <br>需要回退以防止在谓词发生 panic 之前对最后一个成功排出的项进行双重丢弃。<br>
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Attempt to consume any remaining elements if the filter predicate has not yet panicked. <br>如果过滤谓词尚未 panic，请尝试消耗所有剩余的元素。<br>
        // We'll backshift any remaining elements whether we've already panicked or if the consumption here panics. <br>无论是否已经 panic 或这里的消耗量 panics，我们都会回退所有剩余的元素。<br>
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}
