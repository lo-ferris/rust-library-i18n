use core::cmp;
use core::iter::TrustedLen;
use core::ptr;

use crate::raw_vec::RawVec;

use super::{SpecExtend, Vec};

/// Another specialization trait for Vec::from_iter necessary to manually prioritize overlapping specializations see [`SpecFromIter`](super::SpecFromIter) for details. <br>手动确定重叠专业的优先级所必需的 Vec::from_iter 的另一个专业 trait，请参见 [`SpecFromIter`](super::SpecFromIter) 了解详细信息。<br>
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Unroll the first iteration, as the vector is going to be expanded on this iteration in every case when the iterable is not empty, but the loop in extend_desugared() is not going to see the vector being full in the few subsequent loop iterations. <br>展开第一个迭代，因为在每种情况下，当 iterable 不为空时，vector 都会在此迭代中进行扩展，但是 extend_desugared() 中的循环不会在随后的几次循环迭代中看到 vector 已满。<br>
        //
        // So we get better branch prediction. <br>所以我们得到了更好的分支预测。<br>
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let initial_capacity =
                    cmp::max(RawVec::<T>::MIN_NON_ZERO_CAP, lower.saturating_add(1));
                let mut vector = Vec::with_capacity(initial_capacity);
                unsafe {
                    // SAFETY: We requested capacity at least 1 <br>我们要求的容量至少为 1<br>
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // must delegate to spec_extend() since extend() itself delegates to spec_from for empty Vecs <br>必须委托给 spec_extend()，因为 extend() 本身委托给空空的 Vecs 的 spec_from<br>
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            // TrustedLen contract guarantees that `size_hint() == (_, None)` means that there are more than `usize::MAX` elements. <br>TrustedLen 契约保证 `size_hint() == (_, None)` 意味着有多个 `usize::MAX` 元素。<br>
            // Since the previous branch would eagerly panic if the capacity is too large (via `with_capacity`) we do the same here. <br>因为如果容量太大 (通过 `with_capacity`)，前一个分支会急切地使用 panic，所以我们在这里做同样的事情。<br>
            //
            //
            _ => panic!("capacity overflow"),
        };
        // reuse extend specialization for TrustedLen <br>重用 TrustedLen 的扩展专业化<br>
        vector.spec_extend(iterator);
        vector
    }
}
