// Set the length of the vec when the `SetLenOnDrop` value goes out of scope. <br>当 `SetLenOnDrop` 值离开作用域时，设置 vec 的长度。<br>
//
// The idea is: The length field in SetLenOnDrop is a local variable that the optimizer will see does not alias with any stores through the Vec's data pointer. <br>这个想法是: SetLenOnDrop 中的 length 字段是一个局部变量，优化器将看到该变量不会通过 Vec 的数据指针与任何存储空间产生别名。<br>
// This is a workaround for alias analysis issue #32155 <br>这是别名分析问题的解决方法 #32155<br>
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }

    #[inline]
    pub(super) fn current_len(&self) -> usize {
        self.local_len
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}
